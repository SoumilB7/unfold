# S9-A sparse-config experiment preparation

Source only; no experiment has run. The fixed plan selects Llama-7b and SDXL as two explicit witnesses, not production model-specific rules.

Llama proposes omitting hidden_act, hidden_size and num_attention_heads. The runner accepts each only when the actual sparse ParseContext class overlay supplies exactly its original value. SDXL proposes act_fn and norm_eps; each requires the actual source-resolved registered constructor's typed literal default to equal the original value. A missing/mismatched default is a typed experiment failure, not permission to substitute a guessed value. SourceBundle and class/constructor selection remain unchanged.

After admission, the runner calls config_to_ir and Diagram.to_html once per condition. Each condition retains its own failure, raw config, typed fact snapshots/proof summaries, exact ledger, prepared documents, default-premise events, pre/post-render IR, parameters, raw HTML and ordered SVG hashes. Local document tokens are deliberately not serialized. Both diagrams receive the same declared mount input before rendering; no post-render normalization is applied. Every cross-condition IR/fact leaf delta is retained. Only exact input omissions and validated same-value typed-fact provenance transitions receive automatic cause labels; other changes remain UNEXPLAINED and fail. Within-condition renderer mutation observations are retained separately; cross-condition comparisons gate both pre- and post-render IR.

Additional checks require equal parameter estimates, layer/stage address summaries, fact values/kinds/completeness, and every ordered SVG byte hash. Every omission needs an actual owner/fact-targeted absent-default premise. Metadata or presentation changes outside the narrow classifier will therefore return FAIL for explicit review, even if later found legitimate. This runner neither updates baselines nor claims browser approval or latency results.

Source/input/tool/dependency brackets are retained. Imports must originate in the supplied checkout. Publication, when explicitly requested, copies exact generated page bytes into a fresh directory and labels the diagnostic's actual PASS/FAIL. Existing pages are never overwritten.

Proposed reproduction (root owns execution after source review):

```sh
python3 /private/tmp/unfold-s9a-sparse-witness-preparation/run_sparse.py \
  --checkout /Users/soumil/Code/Projects/Understand/llmvisualizer/unfold-pkg/.claude/worktrees/verify-s9-a-ninth \
  --plan /private/tmp/unfold-s9a-sparse-witness-preparation/plan.json \
  --output /private/tmp/unfold-s9a-sparse-ninth \
  --publish-dir /Users/soumil/Code/Projects/Understand/llmvisualizer/z-docs/12-design/S9-schema/sparse-ninth
```

Prepared runner SHA-256: `7e88098b03c884297708df5a4260ff56f649067d164439181c58bd6f4cc6f32c`.
Plan SHA-256: `85c6e4a631c894e8327c9cc11a4c326877ead2740d5c3c8518e64e5c07751be5`.
