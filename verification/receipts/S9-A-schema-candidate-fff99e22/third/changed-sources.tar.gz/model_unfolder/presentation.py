"""Typed annotations, separate from fact authority and structural occurrences.

Factories validate actual evidence. Decoded records are display transport only;
consumers bind them to the current ledger, never requalify a serialized proof.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
from typing import Mapping

from .uncertainty import UnknownReason, UnknownReasonDisplay

CHIP_KINDS = frozenset({"unresolved", "class_default", "symbolic", "pending_design"})
_REFERENCE_FIELDS = {"owner", "fact_key", "status", "completeness", "value_status_hash", "claim_proof"}
_PROVEN = frozenset({"code_proven", "code_and_config", "config_declared", "class_default"})


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} requires nonempty text")


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _parameter_value(value, path):
    try:
        for step in path:
            if type(step) is int and not isinstance(value, (list, tuple)):
                raise TypeError("integer step requires sequence")
            if type(step) is str and not isinstance(value, Mapping):
                raise TypeError("string step requires mapping")
            value = value[step]
    except (TypeError, KeyError, IndexError) as exc:
        raise ValueError("symbolic parameter path is not present in the fact") from exc
    return value


@dataclass(frozen=True)
class ChipFactReference:
    """A portable snapshot, not a proof object."""

    _record: str

    def __post_init__(self):
        data = self.to_dict()
        if not isinstance(data, dict) or set(data) != _REFERENCE_FIELDS:
            raise ValueError("chip fact reference schema is closed")
        for key in ("owner", "fact_key", "status", "completeness"):
            _text(data[key], key)
        if not data["fact_key"].startswith(data["owner"] + "."):
            raise ValueError("chip fact reference must name its exact owner")
        digest = data["value_status_hash"]
        if not isinstance(digest, str) or len(digest) != 16 or any(c not in "0123456789abcdef" for c in digest):
            raise ValueError("chip reference requires the existing value/status hash")
        proof = data["claim_proof"]
        if proof is not None and (not isinstance(proof, dict) or proof.get("fact_id") != data["fact_key"]):
            raise ValueError("chip proof description must belong to its exact fact")

    @classmethod
    def from_fact(cls, fact):
        from .evidence.facts import EvidenceFact
        from .evidence.claim_evidence import validate_fact_claim
        from .evidence.receipts import value_status_hash
        if not isinstance(fact, EvidenceFact):
            raise TypeError("chip references originate from actual typed facts")
        proof = None
        if fact.claim_evidence is not None:
            validate_fact_claim(fact, fact.claim_evidence)
            proof = asdict(fact.claim_evidence.summary())
        return cls(_json({"owner": fact.owner, "fact_key": fact.ledger_key(),
                          "status": fact.status, "completeness": fact.completeness,
                          "value_status_hash": value_status_hash(fact.value, fact.status),
                          "claim_proof": proof}))

    @classmethod
    def from_dict(cls, record):
        return cls(_json(record))

    def to_dict(self):
        return json.loads(self._record)


@dataclass(frozen=True)
class SymbolicParameter:
    name: str
    fact_key: str
    value_path: tuple[str | int, ...]
    value: str | int | float

    def __post_init__(self):
        _text(self.name, "symbolic parameter name")
        _text(self.fact_key, "symbolic parameter fact")
        if not isinstance(self.value_path, tuple) or any(
                type(x) not in {str, int} or (type(x) is int and x < 0) for x in self.value_path):
            raise ValueError("symbolic value path uses exact keys/nonnegative indexes")
        if type(self.value) not in {str, int, float} or (
                type(self.value) is float and not math.isfinite(self.value)):
            raise ValueError("symbolic parameter requires a finite scalar")

    def to_dict(self):
        return {"name": self.name, "fact_key": self.fact_key,
                "value_path": list(self.value_path), "value": self.value}

    @classmethod
    def from_dict(cls, record):
        if not isinstance(record, dict) or set(record) != {"name", "fact_key", "value_path", "value"} or not isinstance(record["value_path"], list):
            raise ValueError("symbolic parameter schema is closed")
        return cls(record["name"], record["fact_key"], tuple(record["value_path"]), record["value"])


@dataclass(frozen=True)
class PresentationChip:
    chip_kind: str
    text: str
    owner: str
    references: tuple[ChipFactReference, ...]
    unknown_reason: UnknownReasonDisplay | None = None
    decision_ref: str | None = None
    parameters: tuple[SymbolicParameter, ...] = ()

    def __post_init__(self):
        if self.chip_kind not in CHIP_KINDS:
            raise ValueError("chip kind is closed and separate from evidence status")
        _text(self.text, "chip text")
        _text(self.owner, "chip owner")
        if not isinstance(self.references, tuple) or not self.references or any(
                not isinstance(ref, ChipFactReference) for ref in self.references):
            raise TypeError("chip requires typed exact fact references")
        refs = [ref.to_dict() for ref in self.references]
        keys = [ref["fact_key"] for ref in refs]
        if len(set(keys)) != len(keys) or any(ref["owner"] != self.owner for ref in refs):
            raise ValueError("chip fact references must be unique and belong to its owner")
        if not isinstance(self.parameters, tuple) or any(not isinstance(p, SymbolicParameter) for p in self.parameters):
            raise TypeError("symbolic parameters must be a typed tuple")
        if self.chip_kind == "unresolved":
            if not isinstance(self.unknown_reason, UnknownReasonDisplay):
                raise ValueError("unresolved chip requires typed reason transport")
            if any(ref["status"] not in {"unknown", "ambiguous", "oracle_missing"} for ref in refs):
                raise ValueError("unresolved annotation cannot demote a proven fact")
            investigation = self.unknown_reason.to_dict()["investigation"]
            if investigation is not None and investigation["claim_key"] not in keys:
                raise ValueError("chip investigation belongs to another fact")
        elif self.unknown_reason is not None:
            raise ValueError("only unresolved chips carry an unknown reason")
        if self.chip_kind == "class_default" and any(ref["status"] != "class_default" or ref["claim_proof"] is None for ref in refs):
            raise ValueError("class_default chip requires qualified class-default references")
        if self.chip_kind in {"pending_design", "symbolic"} and any(
                ref["status"] not in _PROVEN or ref["completeness"] != "complete" or
                ref["claim_proof"] is None for ref in refs):
            raise ValueError("pending/symbolic chips require complete qualified evidence")
        if self.chip_kind == "pending_design":
            _text(self.decision_ref, "pending design decision reference")
        elif self.decision_ref is not None:
            raise ValueError("only pending-design chips carry a decision reference")
        if self.chip_kind == "symbolic":
            if not self.parameters or len({p.name for p in self.parameters}) != len(self.parameters) or any(p.fact_key not in keys for p in self.parameters):
                raise ValueError("symbolic chips require exact distinct proven parameters")
            by_key = {ref["fact_key"]: ref for ref in refs}
            if any(by_key[param.fact_key]["claim_proof"].get("claim_kind") != "value" for param in self.parameters):
                raise ValueError("symbolic parameters require value-qualified evidence")
        elif self.parameters:
            raise ValueError("only symbolic chips carry symbolic parameters")

    @classmethod
    def from_facts(cls, chip_kind, text, owner, facts, *, unknown_reason=None,
                   decision_ref=None, parameters=()):
        facts = tuple(facts)
        references = tuple(ChipFactReference.from_fact(fact) for fact in facts)
        if unknown_reason is not None and not isinstance(unknown_reason, UnknownReason):
            raise TypeError("producer needs an authoritative UnknownReason, not decoded display data")
        if unknown_reason is not None and any(
                fact.unknown_reason != unknown_reason for fact in facts):
            raise ValueError("chip unknown reason must be the actual cited facts' reason")
        by_key = {fact.ledger_key(): fact for fact in facts}
        for param in parameters:
            if not isinstance(param, SymbolicParameter) or param.fact_key not in by_key:
                raise ValueError("symbolic parameter has no actual cited fact")
            value = _parameter_value(by_key[param.fact_key].value, param.value_path)
            if type(value) is not type(param.value) or value != param.value:
                raise ValueError("symbolic parameter differs from its actual fact")
        return cls(chip_kind, text, owner, references,
                   UnknownReasonDisplay.from_dict(unknown_reason.to_dict()) if unknown_reason else None,
                   decision_ref, tuple(parameters))

    def to_dict(self):
        return {"chip_kind": self.chip_kind, "text": self.text, "owner": self.owner,
                "references": [ref.to_dict() for ref in self.references],
                "unknown_reason": self.unknown_reason.to_dict() if self.unknown_reason else None,
                "decision_ref": self.decision_ref,
                "parameters": [param.to_dict() for param in self.parameters]}

    @classmethod
    def from_dict(cls, record):
        if not isinstance(record, dict) or set(record) != {
                "chip_kind", "text", "owner", "references", "unknown_reason", "decision_ref", "parameters"}:
            raise ValueError("presentation chip schema is closed")
        if not isinstance(record["references"], list) or not isinstance(record["parameters"], list):
            raise TypeError("chip references and parameters require lists")
        return cls(record["chip_kind"], record["text"], record["owner"],
                   tuple(ChipFactReference.from_dict(ref) for ref in record["references"]),
                   UnknownReasonDisplay.from_dict(record["unknown_reason"]) if record["unknown_reason"] is not None else None,
                   record["decision_ref"], tuple(SymbolicParameter.from_dict(p) for p in record["parameters"]))

    def bind(self, fact_rows):
        """Compare transport with current producer metadata; no evidence promotion."""
        for ref in self.references:
            data = ref.to_dict()
            row = fact_rows.get(data["fact_key"])
            if not isinstance(row, Mapping) or row.get("status") != data["status"] or row.get("presentation_reference") != data:
                raise ValueError("chip reference does not match the current producer ledger")
            if self.unknown_reason is not None and row.get("unknown_reason") != self.unknown_reason.to_dict():
                raise ValueError("chip unknown reason does not match the producer ledger")
        for param in self.parameters:
            actual = _parameter_value(fact_rows[param.fact_key].get("value"), param.value_path)
            if type(actual) is not type(param.value) or actual != param.value:
                raise ValueError("symbolic display parameter differs from the current ledger")


def chips_from_block(block):
    records = block.get("presentation_chips", [])
    if not isinstance(records, list):
        raise TypeError("presentation_chips must be a list")
    chips = tuple(PresentationChip.from_dict(record) for record in records)
    if chips:
        path = block.get("presentation_path")
        if not _valid_presentation_path(path):
            raise ValueError("chip-bearing card requires its exact producer JSON path")
        aliases = block.get("presentation_aliases", [])
        if not isinstance(aliases, list) or any(not _valid_presentation_path(alias) for alias in aliases):
            raise ValueError("presentation aliases require exact JSON paths")
        paths = [tuple(path), *(tuple(alias) for alias in aliases)]
        if len(set(paths)) != len(paths):
            raise ValueError("presentation canonical/alias paths must be unique")
    cited = block.get("source_fact_keys") or ()
    for chip in chips:
        if any(ref.to_dict()["fact_key"] not in cited for ref in chip.references):
            raise ValueError("chip references must be cited by this exact card")
    return chips


def _valid_presentation_path(path):
    return isinstance(path, list) and bool(path) and all(
        type(part) in {str, int} and
        (type(part) is not int or part >= 0) and
        (type(part) is not str or bool(part)) for part in path)
