"""Escaping and formatting helpers for renderer modules."""
from __future__ import annotations

from html import escape
from typing import Any


def _fmt_int(value: Any) -> str:
    if value is None:
        return "?"
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value)


def _num(value: Any) -> Any:
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def _html(value: Any) -> str:
    return escape(str(value), quote=False)


def _attr(value: Any) -> str:
    return escape(str(value), quote=True)


def facts_html(facts) -> str:
    """The one chips row every inspect card uses for its numeric/spec facts."""
    if not facts:
        return ""
    chips = "".join(f'<span class="uf-fact">{_html(f)}</span>' for f in facts if f)
    return f'<div class="uf-card-facts">{chips}</div>' if chips else ""


def _presentation_chip_html(chip) -> str:
    """One typed annotation; labels never determine kind or evidence status."""
    from ...presentation import PresentationChip
    if not isinstance(chip, PresentationChip):
        raise TypeError("chip renderer requires typed display metadata")
    label = chip.chip_kind.replace("_", " ") if chip.chip_kind == "pending_design" else chip.chip_kind
    extra = ""
    if chip.unknown_reason is not None:
        reason = chip.unknown_reason.to_dict()
        label += " · " + reason["reason_class"]
        extra = f' data-reason-class="{_attr(reason["reason_class"])}"'
    if chip.decision_ref is not None:
        label += " · " + chip.decision_ref
        extra += f' data-decision-ref="{_attr(chip.decision_ref)}"'
    return (f'<span class="uf-fact uf-chip-{chip.chip_kind}" '
            f'data-chip-kind="{chip.chip_kind}" data-chip-owner="{_attr(chip.owner)}"{extra}>'
            f'{_html(label)} · {_html(chip.text)}</span>')


def presentation_chip_html(chip) -> str:
    return _presentation_chip_html(chip)


def is_exact_chip_emission(fragment: str, chip) -> bool:
    """Bind receipts to returned bytes, including kind, owner and full text."""
    return fragment == _presentation_chip_html(chip)
