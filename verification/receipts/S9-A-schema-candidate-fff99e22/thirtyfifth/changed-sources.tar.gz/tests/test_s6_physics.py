"""S6 isolation, inventory, and positive-execution poison matrix."""
from __future__ import annotations

import dataclasses
import ast
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys

import pytest

from physics.execution_observation import (
    ExecutionRecipe, FunctionalOp, ModuleCall, ObservationResult, TensorArgument,
    observe_in_subprocess, _worker_exit_failure,
)
from physics.instance_inventory import (
    BuildRequest, Failure, InventoryResult, PackageVersion, ResolvedClass,
    SourceFile, _network_isolated_command, _prepare_network_attestation,
    _require_network_attestation, _write_network_attestation,
    inventory_in_subprocess,
)


ROOT = Path(__file__).resolve().parents[1]
PILOTS = ROOT / "verification" / "s6" / "pilots"
PILOT_SLUGS = {
    "llama-7b", "deepseek-v3", "qwen2-vl-7b-instruct",
    "stable-diffusion-3-5-large", "pixart-sigma-xl-2-1024-ms",
    "stable-diffusion-xl-base-1-0", "musicgen-small", "dbrx-base",
}


def _request(name: str, config=None, **kwargs) -> BuildRequest:
    return BuildRequest(
        config=config or {}, framework="custom",
        factory_module="test_support.s6_models", factory_qualname=name,
        timeout_seconds=kwargs.pop("timeout_seconds", 30),
        memory_limit_bytes=kwargs.pop("memory_limit_bytes", 8 * 1024**3),
        label=name, **kwargs)


def _recipe(name="synthetic", width=4) -> ExecutionRecipe:
    return ExecutionRecipe(
        recipe_id=name, input_modality="hidden_states", train_eval="eval",
        cache_state="disabled", encoder_decoder_mode="decoder",
        conditioning_present=False, dtype="float32",
        library_versions={"torch": importlib.metadata.version("torch")},
        tensor_arguments=(TensorArgument("x", (1, 2, width), "float32"),),
    )


def test_inventory_is_exact_typed_and_versioned():
    result = inventory_in_subprocess(_request("InventoryFixture", {"width": 4}))
    assert result.status == "ok", result.failure
    inv = result.inventory
    assert inv is not None
    assert inv.provenance.config_sha256 == __import__("hashlib").sha256(
        b'{"width":4}').hexdigest()
    assert inv.provenance.resolved_class.qualname == "InventoryFixture"
    assert {x.package for x in inv.provenance.packages} >= {"torch"}
    assert all(len(x.sha256) == 64 for x in inv.provenance.source_files)
    assert any(group.members == ("layers.0", "layers.1")
               for group in inv.repetition_groups)
    assert any(group.names == ("embed.weight", "head.weight")
               for group in inv.parameter_aliases)
    root = inv.modules[0]
    assert root.init_attributes["width"] == 4
    optional = next(row for row in root.guarded_none_children
                    if row["path"] == "optional")
    assert optional["value"] is None and optional["guards"]
    assert not any(row["path"] == "unconditional_none"
                   for row in root.guarded_none_children)


def test_constructor_cannot_rewrite_the_checkpoint_config_hash():
    config = {"nested": {"value": 7}}
    result = inventory_in_subprocess(_request("MutatingConfigModel", config))
    assert result.status == "ok", result.failure
    assert result.inventory is not None
    expected = hashlib.sha256(b'{"nested":{"value":7}}').hexdigest()
    assert result.inventory.provenance.config_sha256 == expected
    assert config == {"nested": {"value": 7}}


def test_constructor_network_attempt_is_typed_network_refused():
    result = inventory_in_subprocess(_request("NetworkModel"))
    assert result.status == "failed"
    assert result.failure and result.failure.kind == "NetworkRefused"
    assert "example.com" not in result.stdout  # no secret/request echo channel

    escaped = inventory_in_subprocess(_request("SubprocessNetworkModel"))
    assert escaped.status == "failed"
    assert escaped.failure and escaped.failure.kind == "NetworkRefused"
    assert "network client process refused" in escaped.failure.detail


def test_linux_os_sandbox_command_is_explicit_never_audit_hook_laundered(
        monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setattr("physics.instance_inventory.shutil.which",
                        lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr("physics.instance_inventory.os.getuid", lambda: 501)
    monkeypatch.setattr("physics.instance_inventory.os.getgid", lambda: 20)
    env = {"UNFOLD_LINUX_NETWORK_SANDBOX": "sudo-unshare",
           "PYTHONHASHSEED": "0", "PYTHONPATH": "/repo"}
    command = _network_isolated_command(["python", "worker.py"], env)
    assert command[:9] == [
        "/usr/bin/sudo", "-n", "/usr/bin/unshare", "--net",
        "--setgid", "20", "--setuid", "501", "--"]
    assert "/usr/bin/env" in command and "-i" in command
    assert command[-2:] == ["python", "worker.py"]
    assert "PYTHONPATH=/repo" in command
    assert env["UNFOLD_NETWORK_SANDBOX"] == (
        "linux-sudo-unshare-net+python-audit-hook")

    with pytest.raises(RuntimeError, match="leaves untrusted model code"):
        _network_isolated_command(
            ["python"], {"UNFOLD_LINUX_NETWORK_SANDBOX": "root-unshare"})

    # No opt-in is honestly recorded as audit-only, never as OS-isolated.
    env = {}
    assert _network_isolated_command(["python"], env) == ["python"]
    assert env["UNFOLD_NETWORK_SANDBOX"] == "python-audit-hook-only"


def test_linux_worker_attestation_is_nonce_bound_and_requires_a_new_namespace(
        monkeypatch, tmp_path):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setattr("physics.instance_inventory.os.readlink",
                        lambda _path: "net:[parent]")
    monkeypatch.setattr("physics.instance_inventory.os.getuid", lambda: 501)
    monkeypatch.setattr("physics.instance_inventory.os.getgid", lambda: 20)
    env = {"UNFOLD_LINUX_NETWORK_SANDBOX": "sudo-unshare"}
    expected = _prepare_network_attestation(tmp_path, env)
    assert expected is not None
    path, ack, nonce, parent, uid, gid = expected

    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_PATH", str(path))
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_NONCE", nonce)
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_PARENT_NETNS", parent)
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_UID", str(uid))
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_GID", str(gid))
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_ACK", str(ack))
    monkeypatch.setattr("physics.instance_inventory.os.readlink",
                        lambda _path: "net:[child]")
    monkeypatch.setattr("physics.instance_inventory.os.geteuid", lambda: uid)
    monkeypatch.setattr("physics.instance_inventory.os.getegid", lambda: gid)
    # The production parent creates this only after validating the receipt.
    # Pre-creating it lets this single-threaded unit exercise the worker half.
    ack.write_text("accepted")
    _write_network_attestation()
    _require_network_attestation(expected)

    row = {"schema_version": 1, "nonce": nonce, "parent_netns": parent,
           "child_netns": "net:[child]", "euid": uid, "egid": gid}
    row["nonce"] = "forged"
    path.write_text(json.dumps(row))
    with pytest.raises(RuntimeError, match="attestation is invalid"):
        _require_network_attestation(expected)

    row["nonce"] = nonce
    row["child_netns"] = parent
    path.write_text(json.dumps(row))
    with pytest.raises(RuntimeError, match="attestation is invalid"):
        _require_network_attestation(expected)

    row["child_netns"] = "net:[child]"
    row["euid"] = 0
    path.write_text(json.dumps(row))
    with pytest.raises(RuntimeError, match="attestation is invalid"):
        _require_network_attestation(expected)

    path.unlink()
    with pytest.raises(RuntimeError, match="attestation is missing"):
        _require_network_attestation(expected)


def test_linux_worker_attestation_is_published_by_atomic_replace(
        monkeypatch, tmp_path):
    path = tmp_path / "receipt.json"
    ack = tmp_path / "receipt.ack"
    nonce = "a" * 64
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_PATH", str(path))
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_NONCE", nonce)
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_PARENT_NETNS", "net:[parent]")
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_UID", "501")
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_GID", "20")
    monkeypatch.setenv("UNFOLD_NETWORK_ATTESTATION_ACK", str(ack))
    monkeypatch.setattr("physics.instance_inventory.os.readlink",
                        lambda _path: "net:[child]")
    monkeypatch.setattr("physics.instance_inventory.os.geteuid", lambda: 501)
    monkeypatch.setattr("physics.instance_inventory.os.getegid", lambda: 20)
    ack.write_text("accepted")
    calls = []
    real_replace = os.replace

    def replace(source, destination):
        calls.append((Path(source), Path(destination)))
        assert Path(source).parent == path.parent
        assert Path(source) != path
        assert not path.exists()
        return real_replace(source, destination)

    monkeypatch.setattr("physics.instance_inventory.os.replace", replace)
    _write_network_attestation()

    assert calls == [(tmp_path / f".receipt.json.{nonce}.tmp", path)]
    assert json.loads(path.read_text())["nonce"] == nonce
    assert not calls[0][0].exists()


@pytest.mark.parametrize("payload", ["[]", "null", "1", '"text"'])
def test_linux_worker_attestation_rejects_non_object_json(
        monkeypatch, tmp_path, payload):
    path = tmp_path / "receipt.json"
    ack = tmp_path / "receipt.ack"
    path.write_text(payload)
    with pytest.raises(RuntimeError, match="attestation is invalid"):
        _require_network_attestation(
            (path, ack, "nonce", "net:[parent]", 501, 20))


def test_constructor_timeout_is_typed_and_child_is_killed():
    result = inventory_in_subprocess(_request(
        "SlowModel", {"seconds": 5}, timeout_seconds=0.2))
    assert result.status == "failed"
    assert result.failure and result.failure.kind == "TimeoutExpired"


def test_constructor_output_is_drained_without_deadlock_and_capture_is_bounded():
    result = inventory_in_subprocess(_request(
        "NoisyModel", {"characters": 1024 * 1024}, timeout_seconds=10))
    assert result.status == "ok", result.failure
    assert 60_000 < len(result.stdout) <= 65_536


def test_constructor_memory_cap_is_typed():
    result = inventory_in_subprocess(_request(
        "MemoryModel", {"bytes": 3 * 1024**3, "chunk_bytes": 64 * 1024**2},
        memory_limit_bytes=1024**3, timeout_seconds=30))
    assert result.status == "failed"
    assert result.failure and result.failure.kind == "MemoryLimitExceeded"


def test_execution_records_module_order_function_ops_and_lazy_module():
    lazy = observe_in_subprocess(_request("LazyModel"), _recipe("lazy"))
    assert lazy.status == "ok", lazy.failure
    assert lazy.observation and [x.path for x in lazy.observation.module_calls][0] == ""
    assert [x.path for x in lazy.observation.lazy_observed] == ["cache"]
    assert {x.op for x in lazy.observation.functional_ops} >= {"add", "mul"}

    functional = observe_in_subprocess(_request("FunctionalModel"), _recipe())
    assert functional.status == "ok", functional.failure
    assert functional.observation
    assert {x.op for x in functional.observation.functional_ops} >= {
        "chunk", "cat", "layer_norm", "silu", "gelu", "add", "mul"}
    assert functional.observation.recipe.dtype == "float32"
    assert functional.observation.provenance.packages


def test_data_dependent_control_flow_is_unresolved_not_guessed():
    result = observe_in_subprocess(_request("DataDependentModel"), _recipe("dynamic"))
    assert result.status == "failed"
    assert result.failure and result.failure.kind == "ExecutionUnresolved"
    assert result.provenance is not None
    assert result.recipe == _recipe("dynamic")


def test_recipe_preserves_nested_tuple_and_mapping_arguments():
    recipe = ExecutionRecipe(
        recipe_id="nested", input_modality="vision", train_eval="eval",
        cache_state="disabled", encoder_decoder_mode="encoder",
        conditioning_present=True, dtype="float32",
        library_versions={"torch": importlib.metadata.version("torch")},
        tensor_arguments=(
            TensorArgument("pair.0", (1, 2), "float32"),
            TensorArgument("pair.1", (1, 2), "float32"),
            TensorArgument("nested.value", (1, 2), "float32"),
        ),
    )
    result = observe_in_subprocess(_request("TupleInputModel"), recipe)
    assert result.status == "ok", result.failure
    assert result.observation is not None
    assert [op.op for op in result.observation.functional_ops] == ["add", "add"]


def test_recipe_with_false_library_version_is_rejected():
    recipe = dataclasses.replace(_recipe("wrong-version"),
                                 library_versions={"torch": "0.invalid"})
    result = observe_in_subprocess(_request("FunctionalModel"), recipe)
    assert result.status == "failed"
    assert result.failure and result.failure.kind == "ExecutionFailed"
    assert "library version mismatch" in result.failure.detail


def test_missing_worker_result_is_not_laundered_as_memory_exhaustion():
    failure = _worker_exit_failure("worker exited 7 without a result")
    assert failure.kind == "WorkerFailed"
    assert failure.stage == "worker_exit"


def test_result_dtos_are_closed():
    failure = Failure("WorkerFailed", "x", "y")
    with pytest.raises(ValueError):
        InventoryResult("ok", failure=failure)
    with pytest.raises(ValueError):
        ObservationResult("failed")
    with pytest.raises(ValueError):
        dataclasses.replace(_recipe(), train_eval="sometimes")
    with pytest.raises(ValueError):
        BuildRequest({}, "custom", "x", "Y", build_flags={"trust_remote_code": True})
    with pytest.raises(ValueError):
        PackageVersion("", "1")
    with pytest.raises(ValueError):
        SourceFile("m", "m.py", "not-a-hash")
    with pytest.raises(ValueError):
        ModuleCall(-1, "", ResolvedClass("m", "C"))
    with pytest.raises(ValueError):
        FunctionalOp(0, "conventional_attention", "torch.guess")


def test_production_can_request_isolated_inventory_but_cannot_construct_in_parent():
    consumers = [*ROOT.glob("model_unfolder/adapters/**/*.py"),
                 *ROOT.glob("model_unfolder/renderers/**/*.py")]
    assert not [(path, line) for path in consumers
                for line in path.read_text().splitlines() if "physics" in line]
    production = list((ROOT / "model_unfolder").rglob("*.py"))
    # S8 is the authorized first consumer of S6. Its production boundary may
    # carry requests/results and call the isolated parent API, never import
    # the worker's construction or observation internals into an adapter.
    # S9-A consistency compares the returned immutable inventory DTO with
    # independent header shapes. Importing its type grants no worker API.
    public_boundary = {"BuildRequest", "Failure", "InventoryResult", "inventory_in_subprocess",
                       "FrameworkPrimitiveWitness", "AttributeLookupRequest", "PythonFunctionWitness",
                       "InstanceInventory"}
    # Owner-approved S8.1 replay only carries parent metadata/cache lifecycle.
    # It does not authorize worker construction or the cache implementation API.
    parent_cache_hooks = {"register_source_context", "cache_source_bundle",
                          "cache_prepared_document", "parse_cache_active", "run_cached_parse"}
    for path in production:
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                assert not any(alias.name == "physics" or alias.name.startswith("physics.")
                               for alias in node.names), path
            if isinstance(node, ast.ImportFrom) and (node.module or "").startswith("physics"):
                boundary = (public_boundary if node.module == "physics.instance_inventory" else
                            {"ExecutionRecipe", "ObservationResult", "TensorArgument", "observe_in_subprocess"}
                            if node.module == "physics.execution_observation" else
                            parent_cache_hooks if node.module == "physics.result_cache" else set())
                assert boundary and {alias.name for alias in node.names} <= boundary, path


def test_lookup_boundary_reexports_only_the_same_frozen_request_result_types():
    import dataclasses
    from physics import attribute_bindings, instance_inventory

    for name in ("AttributeLookupRequest", "PythonFunctionWitness"):
        public = getattr(instance_inventory, name)
        assert public is getattr(attribute_bindings, name)
        assert dataclasses.is_dataclass(public)
        assert public.__dataclass_params__.frozen


@pytest.mark.parametrize("statement", [
    "from physics.attribute_bindings import AttributeLookupRequest",
    "from physics.attribute_bindings import witness_attribute_bindings",
    "from physics.instance_inventory import inventory_model",
    "from physics.instance_inventory import witness_attribute_bindings",
    "from physics.result_cache import ResultCache",
    "from physics.result_cache import _Transaction",
    "from physics.result_cache import validate_dependencies",
    "from physics.result_cache import _closure",
    "from physics.result_cache import file_digest",
    "from physics.result_cache import source_cache_scope",
    "from physics.result_cache import *",
    "import physics.result_cache",
])
def test_parent_import_boundary_still_rejects_implementation_helpers(
        monkeypatch, tmp_path, statement):
    source = tmp_path / "model_unfolder" / "evidence" / "poison.py"
    source.parent.mkdir(parents=True)
    source.write_text(statement + "\n")
    monkeypatch.setitem(globals(), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_production_can_request_isolated_inventory_but_cannot_construct_in_parent()


@pytest.mark.parametrize("name", [
    "register_source_context", "cache_source_bundle", "cache_prepared_document",
    "parse_cache_active", "run_cached_parse",
])
def test_parent_cache_boundary_admits_only_the_named_replay_hooks(monkeypatch, tmp_path, name):
    source = tmp_path / "model_unfolder" / "evidence" / "replay.py"
    source.parent.mkdir(parents=True)
    source.write_text(f"from physics.result_cache import {name}\n")
    monkeypatch.setitem(globals(), "ROOT", tmp_path)
    test_production_can_request_isolated_inventory_but_cannot_construct_in_parent()


def test_physics_has_no_model_identity_branch():
    source = "\n".join((ROOT / "physics" / name).read_text()
                       for name in ("instance_inventory.py", "execution_observation.py"))
    for identity in ("llama", "deepseek", "qwen", "pixart", "sdxl", "musicgen", "dbrx"):
        assert identity not in source.lower()


def test_persisted_result_is_json_roundtrippable():
    result = inventory_in_subprocess(_request("InventoryFixture"))
    rebuilt = InventoryResult.from_dict(json.loads(json.dumps(result.to_dict())))
    assert rebuilt == result


def _artifact(slug: str, name: str):
    return json.loads((PILOTS / slug / name).read_text(encoding="utf-8"))


def test_all_eight_versioned_pilots_have_inventory_and_named_observations():
    assert {path.name for path in PILOTS.iterdir() if path.is_dir()} == PILOT_SLUGS
    for slug in PILOT_SLUGS:
        directory = PILOTS / slug
        request = _artifact(slug, "request.json")
        result = _artifact(slug, "inventory.json")
        rebuilt_inventory = InventoryResult.from_dict(result)
        assert json.loads(json.dumps(rebuilt_inventory.to_dict())) == result
        assert request["label"] == slug
        assert result["status"] == "ok", (slug, result.get("failure"))
        provenance = result["inventory"]["provenance"]
        assert len(provenance["config_sha256"]) == 64
        config_bytes = json.dumps(
            request["config"], sort_keys=True, separators=(",", ":"),
            ensure_ascii=True).encode("utf-8")
        assert provenance["config_sha256"] == hashlib.sha256(config_bytes).hexdigest()
        assert provenance["packages"] and provenance["source_files"]
        assert provenance["environment"]["network"] == (
            "macos-sandbox-exec+python-audit-hook")
        assert all(len(row["sha256"]) == 64 for row in provenance["source_files"])
        for source in provenance["source_files"]:
            installed = Path(importlib.import_module(source["module"]).__file__)
            assert installed.name == source["path"]
            assert hashlib.sha256(installed.read_bytes()).hexdigest() == source["sha256"]
        observations = sorted(directory.glob("observation-*.json"))
        assert observations, slug
        for path in observations:
            row = json.loads(path.read_text(encoding="utf-8"))
            rebuilt_observation = ObservationResult.from_dict(row)
            assert json.loads(json.dumps(rebuilt_observation.to_dict())) == row
            # Construction succeeded for every frozen pilot, so even a typed
            # execution failure retains its exact §1c construction provenance.
            assert row["provenance"] == provenance
            assert row["recipe"]
            if row.get("observation"):
                assert row["recipe"] == row["observation"]["recipe"]


def test_sd35_first_block_pins_the_measured_functional_relation_counts():
    row = _artifact(
        "stable-diffusion-3-5-large",
        "observation-transformer-block-0-bf16.json")
    assert row["status"] == "ok"
    counts: dict[str, int] = {}
    for operation in row["observation"]["functional_ops"]:
        counts[operation["op"]] = counts.get(operation["op"], 0) + 1
    assert counts["scaled_dot_product_attention"] == 1
    assert counts["add"] == 16
    assert counts["mul"] == 16


def test_pilot_outliers_remain_explicit_and_positive_subrecipes_stay_useful():
    qwen_full = _artifact(
        "qwen2-vl-7b-instruct", "observation-vision-tower-eval.json")
    qwen_local = _artifact(
        "qwen2-vl-7b-instruct", "observation-vision-mlp-block-0.json")
    assert qwen_full["status"] == "failed"
    assert qwen_full["failure"]["kind"] == "ExecutionUnresolved"
    assert qwen_local["status"] == "ok"
    assert qwen_local["observation"]["module_calls"]

    dbrx_full = _artifact("dbrx-base", "observation-text-eval-no-cache.json")
    dbrx_attention = _artifact(
        "dbrx-base", "observation-attention-block-0-bf16.json")
    assert dbrx_full["status"] == "failed"
    assert dbrx_full["failure"]["kind"] == "ExecutionFailed"
    assert dbrx_attention["status"] == "ok"
    assert any(row["op"] == "scaled_dot_product_attention"
               for row in dbrx_attention["observation"]["functional_ops"])


def test_inventory_records_runtime_factory_remap_and_guarded_none_child():
    pixart = _artifact("pixart-sigma-xl-2-1024-ms", "inventory.json")["inventory"]
    assert pixart["provenance"]["requested_factory"].endswith(".Transformer2DModel")
    assert pixart["provenance"]["resolved_class"]["qualname"] == (
        "PixArtTransformer2DModel")

    sd35 = _artifact("stable-diffusion-3-5-large", "inventory.json")["inventory"]
    block0 = next(row for row in sd35["modules"]
                  if row["path"] == "transformer_blocks.0")
    assert any(row["path"] == "transformer_blocks.0.attn2"
               and row["value"] is None
               and row["guards"]
               for row in block0["guarded_none_children"])


def test_pilot_manifest_is_exact_non_vacuous_and_hashes_every_artifact():
    manifest = json.loads((PILOTS / "manifest.json").read_text(encoding="utf-8"))
    assert set(manifest["pilots"]) == PILOT_SLUGS
    actual = {
        path.relative_to(PILOTS).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in PILOTS.glob("*/*.json")
    }
    assert manifest["artifacts"] == actual
    assert len(actual) == 27
