"""Static code-evidence tests."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model_unfolder.renderers.html.card_payload import expand_card_payloads
from model_unfolder import config_to_ir, inspect_model_code, unfold


LLAMA_TINY_CONFIG = {
    "architectures": ["LlamaForCausalLM"],
    "model_type": "llama",
    "_name_or_path": "meta-llama/Meta-Llama-3-8B",
    "vocab_size": 32000,
    "hidden_size": 64,
    "intermediate_size": 256,
    "num_hidden_layers": 2,
    "num_attention_heads": 4,
    "num_key_value_heads": 2,
    "max_position_embeddings": 128,
    "tie_word_embeddings": False,
    "hidden_act": "silu",
}


def test_static_code_evidence_detects_attention_ffn_and_cache(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class FakeMLP:
    def __init__(self, config):
        self.gate_proj = Linear()
        self.up_proj = Linear()
        self.down_proj = Linear()

class FakeAttention:
    def __init__(self, config):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.num_key_value_groups = config.num_attention_heads // config.num_key_value_heads

    def forward(self, hidden_states, past_key_value=None):
        if past_key_value is not None:
            key_states, value_states = past_key_value.update()
        return attention_interface()

class FakeDecoderLayer:
    def __init__(self, config):
        self.self_attn = FakeAttention(config)
        self.mlp = FakeMLP(config)
        self.input_layernorm = Norm()
        self.post_attention_layernorm = Norm()
""",
    )

    evidence = inspect_model_code(tmp_path)

    assert "split_qkv_attention" in evidence.components["attention"]
    assert "grouped_kv_attention" in evidence.components["attention"]
    assert "gated_dense_ffn" in evidence.components["ffn"]
    assert "kv_cache_update" in evidence.components["feature"]
    assert "decoder_layer" in evidence.components["topology"]


def test_static_code_evidence_detects_mla_and_moe(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class DeepseekLikeAttention:
    def __init__(self, config):
        self.q_lora_rank = config.q_lora_rank
        self.kv_lora_rank = config.kv_lora_rank
        self.q_a_proj = Linear()
        self.q_b_proj = Linear()
        self.kv_a_proj_with_mqa = Linear()
        self.kv_b_proj = Linear()
        self.o_proj = Linear()
        self.qk_nope_head_dim = config.qk_nope_head_dim
        self.qk_rope_head_dim = config.qk_rope_head_dim

    def forward(self, hidden_states, past_key_value=None):
        q_nope, q_pe = split(hidden_states)
        k_nope, k_pe = split(hidden_states)
        key_states, value_states = past_key_value.update()
        return attention_interface()

class SparseMoeBlock:
    def __init__(self, config):
        self.router = Router()
        self.experts = Experts()
        self.shared_experts = Experts()
        self.top_k = config.num_experts_per_tok
        self.num_experts = config.num_experts
""",
    )

    evidence = inspect_model_code(tmp_path)

    assert "mla" in evidence.components["attention"]
    assert "latent_kv_cache" in evidence.components["feature"]
    assert "mixture_of_experts" in evidence.components["ffn"]
    assert "shared_experts" in evidence.components["feature"]


def test_config_to_ir_can_attach_code_evidence_from_path(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class FakeAttention:
    def __init__(self, config):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.num_key_value_groups = 2

class FakeMLP:
    def __init__(self, config):
        self.gate_proj = Linear()
        self.up_proj = Linear()
        self.down_proj = Linear()
""",
    )

    ir = config_to_ir(LLAMA_TINY_CONFIG, inspect_code=True, code_source=str(tmp_path))

    assert "code_evidence" in ir.extras
    assert ir.extras["code_evidence"]["provenance"]["source"] == "path"
    assert "grouped_kv_attention" in ir.extras["code_evidence"]["components"]["attention"]

    diagram = unfold(LLAMA_TINY_CONFIG, inspect_code=True, code_source=str(tmp_path))
    html = diagram.to_html(standalone=True)

    assert "code_evidence" in diagram.to_ir()["extras"]
    assert "CODE EVIDENCE" in html
    assert "grouped K/V" in html
    assert "split QKV" in html
    assert "gated dense FFN" in html


def test_code_evidence_section_is_hidden_without_inspection():
    html = unfold(LLAMA_TINY_CONFIG).to_html(standalone=True)

    assert "CODE EVIDENCE" not in html


# ---------------------------------------------------------------------------
# Detectors for custom/quirky setups across families
# ---------------------------------------------------------------------------


def test_detects_per_layer_embedding_pathway(tmp_path):
    """Gemma 3n / Gemma 4-style Per-Layer Embeddings."""
    _write_modeling_file(
        tmp_path,
        """
class Gemma3nTextDecoderLayer:
    def __init__(self, config):
        self.self_attn = FakeAttention()
        self.mlp = FakeMLP()
        self.input_layernorm = Norm()
        self.post_attention_layernorm = Norm()
        self.pre_feedforward_layernorm = Norm()
        self.post_feedforward_layernorm = Norm()
        self.per_layer_input_gate = Linear()
        self.per_layer_projection = Linear()
        self.post_per_layer_input_norm = Norm()
        self.hidden_size_per_layer_input = config.hidden_size_per_layer_input
        self.altup = AltUp()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "per_layer_embedding_pathway" in ev.components["topology"]
    assert "double_ffn_norm" in ev.components["topology"]


def test_detects_altup_routing(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class Gemma3nTextAltUp:
    def __init__(self, config):
        self.modality_router = Linear()
        self.router_norm = Norm()
        self.prediction_coefs = Param()
        self.correction_coefs = Param()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "altup_routing" in ev.components["topology"]


def test_detects_cross_layer_kv_sharing(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class Gemma3nTextAttention:
    def __init__(self, config, layer_idx):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.is_kv_shared_layer = layer_idx >= config.first_kv_shared_layer
        self.kv_shared_layer_index = config.kv_shared_layer_index
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "cross_layer_kv_sharing" in ev.components["feature"]


def test_detects_attention_logit_softcap(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class Gemma2Attention:
    def __init__(self, config):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.attn_logit_softcapping = config.attn_logit_softcapping
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "attention_logit_softcap" in ev.components["feature"]


def test_detects_alibi_via_calls(tmp_path):
    """BLOOM/MPT/Falcon ALiBi: computed in model.forward, never stored as field."""
    _write_modeling_file(
        tmp_path,
        """
class BloomModel:
    def __init__(self, config):
        self.num_heads = config.num_attention_heads

    def forward(self, input_ids):
        alibi = build_alibi_tensor(self.num_heads, input_ids.shape[-1])
        return alibi
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "alibi_position_bias" in ev.components["feature"]


def test_detects_partial_rotary_via_config_refs(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class GPTNeoXAttention:
    def __init__(self, config):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.rotary_pct = config.rotary_pct
        self.rotary_ndims = int(config.rotary_pct * config.head_dim)
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "partial_rotary_embedding" in ev.components["feature"]


def test_detects_fine_grained_moe_routing_deepseek_style(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class DeepseekV3MoE:
    def __init__(self, config):
        self.experts = Experts()
        self.shared_experts = Experts()
        self.gate = Gate()
        self.top_k = config.num_experts_per_tok
        self.n_routed_experts = config.n_routed_experts
        self.routed_scaling_factor = config.routed_scaling_factor

    def forward(self, x):
        return route_tokens_to_experts(x, self.gate, self.experts)
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "mixture_of_experts" in ev.components["ffn"]
    assert "shared_experts" in ev.components["feature"]
    assert "fine_grained_expert_routing" in ev.components["feature"]


def test_detects_mla_with_decoupled_rope_heads(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class DeepseekV3Attention:
    def __init__(self, config):
        self.q_a_proj = Linear()
        self.q_b_proj = Linear()
        self.kv_a_proj_with_mqa = Linear()
        self.kv_b_proj = Linear()
        self.o_proj = Linear()
        self.qk_nope_head_dim = config.qk_nope_head_dim
        self.qk_rope_head_dim = config.qk_rope_head_dim
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "mla" in ev.components["attention"]
    assert "latent_kv_cache" in ev.components["feature"]
    assert "decoupled_rope_heads" in ev.components["feature"]


def test_detects_multi_token_prediction(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class DeepseekV3MTPLayer:
    def __init__(self, config):
        self.mtp_proj = Linear()
        self.mtp_norm = Norm()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "multi_token_prediction" in ev.components["topology"]


def test_detects_double_ffn_norm_gemma2_style(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class Gemma2DecoderLayer:
    def __init__(self, config):
        self.self_attn = FakeAttention()
        self.mlp = FakeMLP()
        self.input_layernorm = Norm()
        self.post_attention_layernorm = Norm()
        self.pre_feedforward_layernorm = Norm()
        self.post_feedforward_layernorm = Norm()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "double_ffn_norm" in ev.components["topology"]
    assert "decoder_layer" in ev.components["topology"]


def test_detects_falcon_parallel_residual_candidates(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class FalconDecoderLayer:
    def __init__(self, config):
        self.self_attention = FakeAttention()
        self.mlp = FakeMLP()
        self.ln_attn = Norm()
        self.ln_mlp = Norm()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "parallel_residual_candidates" in ev.components["topology"]


def test_detects_qk_norm_cohere_style(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class CohereAttention:
    def __init__(self, config):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.use_qk_norm = config.use_qk_norm
        self.q_norm = Norm()
        self.k_norm = Norm()
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "qk_norm" in ev.components["feature"]


def test_detects_nope_layer_interleaving(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class Llama4TextAttention:
    def __init__(self, config, layer_idx):
        self.q_proj = Linear()
        self.k_proj = Linear()
        self.v_proj = Linear()
        self.o_proj = Linear()
        self.use_rope = (layer_idx + 1) % config.no_rope_layer_interval != 0
        self.qk_norm = config.qk_norm
""",
    )
    ev = inspect_model_code(tmp_path)

    assert "nope_layer_interleaving" in ev.components["feature"]


# ---------------------------------------------------------------------------
# Validation cross-checks
# ---------------------------------------------------------------------------


def test_validate_warns_on_mla_in_code_but_not_in_ir(tmp_path):
    """If MLA-shaped attention is in the modeling file but the parsed IR
    has none, validation must emit a warning."""
    _write_modeling_file(
        tmp_path,
        """
class DeepseekV3Attention:
    def __init__(self, config):
        self.q_a_proj = Linear()
        self.q_b_proj = Linear()
        self.kv_a_proj_with_mqa = Linear()
        self.kv_b_proj = Linear()
        self.o_proj = Linear()
""",
    )

    # Llama IR (no MLA) + code evidence that says MLA → warning expected.
    ir = config_to_ir(LLAMA_TINY_CONFIG, inspect_code=True, code_source=str(tmp_path))

    assert any("MLA" in w for w in ir.warnings)


def test_validate_does_not_assign_whole_file_ple_to_an_unqualified_owner(tmp_path):
    _write_modeling_file(
        tmp_path,
        """
class GemmaLikeDecoderLayer:
    def __init__(self, config):
        self.self_attn = FakeAttention()
        self.mlp = FakeMLP()
        self.input_layernorm = Norm()
        self.post_attention_layernorm = Norm()
        self.per_layer_input_gate = Linear()
        self.per_layer_projection = Linear()
        self.hidden_size_per_layer_input = config.hidden_size_per_layer_input
""",
    )

    ir = config_to_ir(LLAMA_TINY_CONFIG, inspect_code=True, code_source=str(tmp_path))

    assert not any("Per-Layer Embedding" in w or "PLE" in w for w in ir.warnings)


def _write_modeling_file(tmp_path, body: str):
    path = tmp_path / "modeling_fake.py"
    path.write_text(body.strip() + "\n", encoding="utf-8")
    return path


def test_field_types_resolve_constructor_classmethod_factories():
    """``self.x = Klass._from_config(cfg)`` types the field as ``Klass`` (never
    the factory's method name) — the general delegated-construction signature
    behind the transformers ``*WithProjection`` wrappers.  ``AutoModel`` stays
    the honest address name; concrete resolution belongs to the qualified
    component rail, not the shared extractor."""
    import ast
    from model_unfolder.evidence.forward_ops import _field_types, _method

    tree = ast.parse(
        "class Wrapper:\n"
        "    def __init__(self, config):\n"
        "        self.inner = InnerTower._from_config(config)\n"
        "        self.other = OtherTower.from_config(config.sub_config)\n"
        "        self.auto = AutoModel.from_config(config.vision_config)\n"
        "        self.plain = PlainLayer(config)\n"
    )
    node = next(n for n in ast.walk(tree) if isinstance(n, ast.ClassDef))
    types = _field_types(_method(node, "__init__"))
    assert types["inner"] == "InnerTower"
    assert types["other"] == "OtherTower"
    assert types["auto"] == "AutoModel"
    assert types["plain"] == "PlainLayer"


_CHATGLM_SHAPED = """
import torch
import torch.nn as nn
import torch.nn.functional as F


def apply_rotary_pos_emb(x, rope_cache):
    return x


class CoreAttention(nn.Module):
    def __init__(self, config, layer_number):
        super().__init__()

    def forward(self, query_layer, key_layer, value_layer, attention_mask):
        scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        probs = F.softmax(scores, dim=-1)
        return torch.matmul(probs, value_layer)


class SelfAttention(nn.Module):
    def __init__(self, config, layer_number):
        super().__init__()
        self.query_key_value = nn.Linear(config.hidden_size, 3 * config.hidden_size)
        self.core_attention = CoreAttention(config, layer_number)
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, hidden_states, attention_mask, rotary_pos_emb):
        mixed = self.query_key_value(hidden_states)
        query_layer, key_layer, value_layer = mixed.split(3, dim=-1)
        query_layer = apply_rotary_pos_emb(query_layer, rotary_pos_emb)
        key_layer = apply_rotary_pos_emb(key_layer, rotary_pos_emb)
        context = self.core_attention(query_layer, key_layer, value_layer, attention_mask)
        return self.dense(context)


class MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.dense_h_to_4h = nn.Linear(config.hidden_size, config.ffn_hidden_size * 2)

        def swiglu(x):
            x = torch.chunk(x, 2, dim=-1)
            return F.silu(x[0]) * x[1]

        self.activation_func = swiglu
        self.dense_4h_to_h = nn.Linear(config.ffn_hidden_size, config.hidden_size)

    def forward(self, hidden_states):
        intermediate = self.dense_h_to_4h(hidden_states)
        intermediate = self.activation_func(intermediate)
        return self.dense_4h_to_h(intermediate)


class GLMBlock(nn.Module):
    def __init__(self, config, layer_number):
        super().__init__()
        self.input_layernorm = nn.LayerNorm(config.hidden_size)
        self.self_attention = SelfAttention(config, layer_number)
        self.post_attention_layernorm = nn.LayerNorm(config.hidden_size)
        self.mlp = MLP(config)

    def forward(self, hidden_states, attention_mask, rotary_pos_emb):
        out = self.input_layernorm(hidden_states)
        out = self.self_attention(out, attention_mask, rotary_pos_emb)
        hidden_states = hidden_states + out
        out = self.post_attention_layernorm(hidden_states)
        return hidden_states + self.mlp(out)
"""


def test_remote_code_declaration_reaches_the_hub_rail(monkeypatch, tmp_path):
    """A config that DECLARES auto_map (remote code) resolves its evidence from
    the repo's own .py files when nothing is installed — the address is the
    id, the DECLARATION is the config's, and offline failure stays honest."""
    f = tmp_path / "modeling_x.py"
    f.write_text(_CHATGLM_SHAPED)
    import model_unfolder.evidence.sources as S
    calls = {}

    def fake_hub(target, *, token=None):
        calls["hit"] = True
        return S.SourceBundle(source="hub", files=(str(f),),
                              component_files={"root": (str(f),)})
    monkeypatch.setattr(S, "_hub_bundle", fake_hub)
    cfg = {"model_type": "notinstalled_xyz", "auto_map": {"AutoModel": "modeling_x.X"},
           "_name_or_path": "some/repo"}
    bundle = S.resolve_source_files(cfg, source="local")
    assert calls.get("hit") and bundle.files
    # without the declaration, no hub attempt is made
    calls.clear()
    bundle = S.resolve_source_files({"model_type": "notinstalled_xyz"}, source="local")
    assert not calls.get("hit")


# ---------------------------------------------------------------------------
# UNIT 1 — SOURCE PARITY (run_77 R1/R2/R3): the loader stamps the address,
# unknown model_type falls through to the declared class, and the true
# refusal cause is never masked. One resolution context for ship AND audit.
# ---------------------------------------------------------------------------


def test_raw_json_loader_stamps_repo_id(monkeypatch, tmp_path):
    """The raw-JSON rung (remote-code / registry-predating repos) must stamp
    ``_repo_id`` so ``resolve_source_files`` can fetch the repo's own modeling
    source — without it every model on this rung parses evidence-blind."""
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(
        '{"model_type": "notinstalled_xyz", "hidden_size": 64, '
        '"num_hidden_layers": 2, "auto_map": {"AutoModel": "modeling_x.X"}}'
    )
    import model_unfolder.parser as P

    def fake_download(**kwargs):
        assert kwargs["repo_id"] == "some/remote-repo"
        return str(cfg_file)

    import huggingface_hub
    monkeypatch.setattr(huggingface_hub, "hf_hub_download", fake_download)
    cfg = P._load_raw_config_json("some/remote-repo", None)
    assert cfg["_repo_id"] == "some/remote-repo"
    # the stamp is exactly what the source resolver's id lookup prioritizes
    import model_unfolder.evidence.sources as S
    assert S._model_id(cfg) == "some/remote-repo"


def test_unknown_model_type_falls_through_to_declared_class():
    """A PRESENT-but-unregistered model_type (the rebrand pattern: kimi_k2
    running the installed DeepseekV3 class) must resolve source by the
    declared architecture, exactly as an ABSENT model_type already does."""
    import model_unfolder.evidence.sources as S
    cfg = {"model_type": "totally_unknown_rebrand_zz",
           "architectures": ["LlamaForCausalLM"]}
    bundle = S._installed_transformers_bundle(cfg)
    assert bundle.files, bundle.warnings
    assert any("modeling_llama" in f for f in bundle.files)
    assert bundle.component_architectures.get("root") == "LlamaForCausalLM"
    # absent architecture keeps the honest no-source warning
    empty = S._installed_transformers_bundle({"model_type": "totally_unknown_rebrand_zz"})
    assert not empty.files and empty.warnings


def test_source_directory_uses_installed_registry_not_a_project_identity_table(
        monkeypatch, tmp_path):
    """Source addressing follows the installed library's own registry.

    The project must not grow a model-type-to-directory table or guess parent
    packages by chopping role suffixes.
    """
    import model_unfolder.evidence.sources as S
    from transformers.models.auto import configuration_auto

    models_root = tmp_path / "models"
    declared = models_root / "registry_selected_module"
    declared.mkdir(parents=True)
    monkeypatch.setattr(
        configuration_auto, "model_type_to_module_name",
        lambda _declared_type: declared.name,
    )
    assert S._transformers_family_dir(
        models_root, "arbitrary_declared_type") == declared.name
    assert not hasattr(S, "MODEL_TYPE_TO_TRANSFORMERS_DIR")

    # If registry metadata names no installed module, an invented suffix-parent
    # must not be selected merely because that directory happens to exist.
    (models_root / "ambiguous").mkdir()
    monkeypatch.setattr(
        configuration_auto, "model_type_to_module_name",
        lambda _declared_type: "not_installed",
    )
    assert S._transformers_family_dir(models_root, "ambiguous_text") is None


def test_fileless_hub_warning_is_not_masked(monkeypatch):
    """When the remote-code hub lookup fails (offline/gated/id-less), its TRUE
    cause must surface beside the local fallback warning instead of being
    replaced by the generic 'no installed source' line."""
    import model_unfolder.evidence.sources as S

    def failing_hub(target, *, token=None):
        raise RuntimeError("simulated offline")

    monkeypatch.setattr(S, "_hub_bundle", failing_hub)
    cfg = {"model_type": "notinstalled_xyz",
           "auto_map": {"AutoModel": "modeling_x.X"}}
    bundle = S.resolve_source_files(cfg, source="local")
    assert not bundle.files
    assert any("remote-code source fetch failed" in w for w in bundle.warnings)


# ---------------------------------------------------------------------------
# QK-norm — code-first (the code decides the SHAPE and names its own gate)
# ---------------------------------------------------------------------------

def test_qk_norm_ships_for_config_silent_oracle_models():
    """The ship-path fix the 21-LLM sweep demanded: Qwen3/OLMo-2/Gemma-3 build
    q/k norms unconditionally with SILENT configs — the default parse (no
    inspect_code flag) must now carry the fact."""
    from transformers import AutoConfig
    for mt in ("qwen3", "olmo2", "gemma3_text"):
        ir = config_to_ir(AutoConfig.for_model(mt))
        assert ir.layers and all(l.attention.qk_norm for l in ir.layers), mt


def test_stablelm_qk_norm_uses_the_proven_repeated_per_head_protocol():
    """A repeated norm is code evidence only after its exact
    split -> homogeneous primitive map -> concat protocol is proven."""
    from transformers import AutoConfig
    # Use the checkpoint-shaped mapping at this boundary.  Mutating an
    # AutoConfig instance manufactures a class-side value with no checkpoint
    # provenance and must not be allowed to masquerade as user configuration.
    cfg = AutoConfig.for_model("stablelm").to_dict()
    assert all(l.attention.qk_norm is False for l in config_to_ir(cfg).layers)
    cfg["qk_layernorm"] = True
    assert all(l.attention.qk_norm is True for l in config_to_ir(cfg).layers)


def test_llama4_qk_schedule_survives_while_position_selector_stays_unknown():
    """The exact QK-norm reader proves its own per-layer gate. It cannot also
    certify the positional selector: U8 must prove that separately, so neither
    model-wide RoPE nor config-computed NoPE is projected yet."""
    from transformers import AutoConfig
    cfg = AutoConfig.for_model("llama4_text")
    ir = config_to_ir(cfg)
    qk = [bool(l.attention.qk_norm) for l in ir.layers]
    assert [i for i, enabled in enumerate(qk) if not enabled][:3] == [3, 7, 11]
    assert all(l.attention.no_rope is False for l in ir.layers)
    assert all(l.attention.rope is None for l in ir.layers)
    assert all(
        (l.attention.position_kind, l.attention.position_application)
        == ("unknown", "unknown")
        for l in ir.layers
    )


def test_qk_norm_stays_absent_for_mla_and_plain_oracle_models():
    from transformers import AutoConfig
    for mt in ("llama", "deepseek_v3", "gemma2", "gpt_neox", "bloom"):
        ir = config_to_ir(AutoConfig.for_model(mt))
        assert not any(l.attention.qk_norm for l in ir.layers), mt


_SHARED_ATTENTION_TOWER = '''
import torch
from torch import nn


class SharedAttention(nn.Module):
    """diffusers-Attention-shaped: lane norms gated on an __init__ PARAM."""

    def __init__(self, dim, heads=8, qk_norm=None):
        super().__init__()
        self.to_q = nn.Linear(dim, dim)
        self.to_k = nn.Linear(dim, dim)
        self.to_v = nn.Linear(dim, dim)
        if qk_norm is None:
            self.norm_q = None
            self.norm_k = None
        elif qk_norm == "rms_norm":
            self.norm_q = nn.RMSNorm(dim)
            self.norm_k = nn.RMSNorm(dim)

    def forward(self, x):
        q, k, v = self.to_q(x), self.to_k(x), self.to_v(x)
        if self.norm_q is not None:
            q = self.norm_q(q)
            k = self.norm_k(k)
        return torch.matmul(torch.matmul(q, k.transpose(-1, -2)).softmax(-1), v)


class NormedBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = SharedAttention(dim, qk_norm="rms_norm")
        self.ff = nn.Linear(dim, dim)

    def forward(self, x):
        return x + self.ff(self.attn(self.norm1(x)))


class PlainBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = SharedAttention(dim)
        self.ff = nn.Linear(dim, dim)

    def forward(self, x):
        return x + self.ff(self.attn(self.norm1(x)))
'''


def test_tower_lane_norms_read_the_construction_site_not_field_presence(tmp_path):
    """The HunyuanVideo-refiner fabrication: a SHARED attention class carries
    ``norm_q``/``norm_k`` fields for every caller — the per-lane tower fact
    must come from the value THIS block passes at its construction site
    (omitted kwarg ⇒ the class's own None default ⇒ no norm), not from bare
    field presence."""
    f = tmp_path / "modeling_shared_tower.py"
    f.write_text(_SHARED_ATTENTION_TOWER)
    from model_unfolder.evidence.transitive import build_registry
    from model_unfolder.everchanging import load_conformance_transitive
    from model_unfolder.evidence.vision import layer_facts_from_block

    registry = build_registry([str(f)])
    vocab = load_conformance_transitive()
    normed = layer_facts_from_block("NormedBlock", registry, vocab)
    plain = layer_facts_from_block("PlainBlock", registry, vocab)
    assert normed["q_norm"] is True and normed["k_norm"] is True
    assert plain["q_norm"] is False and plain["k_norm"] is False


def test_tower_ffn_projection_reads_the_callable_info_contract(tmp_path):
    """The tower reader consumes ``CallableInfo``, not ``ForwardOps``.

    Pin all supported storage forms through the real registry and shared
    ``layer_facts_from_block`` path.  The unused Linear on the fused MLP is a
    poison: constructor presence must not be counted as a live projection.
    """
    source = '''
import torch
from torch import nn

class Attention(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
    def forward(self, x):
        return self.q_proj(x) + self.k_proj(x) + self.v_proj(x)

class FusedMLP(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate_up_proj = nn.Linear(dim, 8 * dim)
        self.down_proj = nn.Linear(4 * dim, dim)
        self.unused_proj = nn.Linear(dim, dim)
    def forward(self, x):
        gate, up = self.gate_up_proj(x).chunk(2, dim=-1)
        return self.down_proj(torch.nn.functional.silu(gate) * up)

class SplitMLP(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate_proj = nn.Linear(dim, 4 * dim)
        self.up_proj = nn.Linear(dim, 4 * dim)
        self.down_proj = nn.Linear(4 * dim, dim)
    def forward(self, x):
        return self.down_proj(
            torch.nn.functional.silu(self.gate_proj(x)) * self.up_proj(x)
        )

class DenseMLP(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.fc1 = nn.Linear(dim, 4 * dim)
        self.fc2 = nn.Linear(4 * dim, dim)
    def forward(self, x):
        return self.fc2(torch.nn.functional.gelu(self.fc1(x)))

class FusedBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = Attention(dim)
        self.mlp = FusedMLP(dim)
    def forward(self, x):
        return self.mlp(self.attn(x))

class SplitBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = Attention(dim)
        self.mlp = SplitMLP(dim)
    def forward(self, x):
        return self.mlp(self.attn(x))

class DenseBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = Attention(dim)
        self.mlp = DenseMLP(dim)
    def forward(self, x):
        return self.mlp(self.attn(x))
'''
    path = tmp_path / "modeling_tower_ffn_storage.py"
    path.write_text(source)

    from model_unfolder.evidence.transitive import build_registry
    from model_unfolder.everchanging import load_conformance_transitive
    from model_unfolder.evidence.vision import layer_facts_from_block

    registry = build_registry([str(path)])
    vocab = load_conformance_transitive()
    assert registry["FusedMLP"].self_field_calls == {
        "gate_up_proj", "down_proj",
    }
    assert layer_facts_from_block(
        "FusedBlock", registry, vocab,
    )["ffn_projection_mode"] == "fused_gate_up"
    assert layer_facts_from_block(
        "SplitBlock", registry, vocab,
    )["ffn_projection_mode"] == "split"
    assert layer_facts_from_block(
        "DenseBlock", registry, vocab,
    )["ffn_projection_mode"] == "dense"


# ---------------------------------------------------------------------------
# Partial rotary — surfaced from every dialect, incl. code-only (S1b)
# ---------------------------------------------------------------------------

_CHATGLM_ROTARY_INIT = '''
import torch
from torch import nn


class RotaryEmbedding(nn.Module):
    def __init__(self, dim, original_impl=False):
        super().__init__()
        self.dim = dim

    def forward(self, x):
        return x


class XModel(nn.Module):
    def __init__(self, config):
        super().__init__()
        rotary_dim = (
            config.hidden_size // config.num_attention_heads
            if config.kv_channels is None else config.kv_channels
        )
        self.rotary_pos_emb = RotaryEmbedding(rotary_dim // 2, original_impl=True)

    def forward(self, x):
        return self.rotary_pos_emb(x)
'''

_CONFIG_DRIVEN_ROTARY_INIT = '''
from torch import nn


class YRotaryEmbedding(nn.Module):
    def __init__(self, config=None):
        super().__init__()
        self.config = config

    def forward(self, x):
        return x


class YModel(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.rotary_emb = YRotaryEmbedding(config=config)

    def forward(self, x):
        return self.rotary_emb(x)
'''


def test_partial_rotary_surfaces_in_drill_and_chips():
    """StableLM (partial_rotary_factor=0.25): the RoPE op states the real
    rot/pass split and the Partial RoPE chip appears; a full-rotary model
    stays chip-free."""
    from transformers import AutoConfig
    import model_unfolder as mu
    doc = mu.unfold(AutoConfig.for_model("stablelm"))
    html = doc.to_html()
    assert "rot 20 · pass 60 dims" in html          # 0.25 × 80
    assert "Partial RoPE" in html
    full = mu.unfold(AutoConfig.for_model("llama")).to_html()
    assert "Partial RoPE" not in full and "rot " not in full


def test_nested_rope_parameters_dialect_cannot_author_geometry_by_itself():
    """A nested fraction remains an operand candidate, not proof that this
    unresolved owner applies RoPE or of which head dimension it rotates."""
    import model_unfolder as mu
    cfg = {
        "model_type": "gpt_neox", "hidden_size": 96 * 8, "num_attention_heads": 8,
        "num_hidden_layers": 2, "vocab_size": 1000,
        "rope_scaling": {"rope_type": "default", "partial_rotary_factor": 0.25},
    }
    ir = mu.config_to_ir(cfg)
    assert ir.layers[0].attention.rope_dim is None
    assert ir.layers[0].attention.head_dim is None


def test_qk_norm_draws_real_ops_in_the_drill():
    """Her Eyes' lawfulness line: the drill may not omit an op its parent
    label advertises — a QK-norm model's attention drill draws Q Norm/K Norm
    on the lanes (projection → norm → RoPE); MLA latent norms never do."""
    from transformers import AutoConfig
    import model_unfolder as mu
    html = mu.unfold(AutoConfig.for_model("qwen3")).to_html()
    assert html.count("Query normalisation") >= 1
    assert html.count("Key normalisation") >= 1
    mla = mu.unfold(AutoConfig.for_model("deepseek_v3")).to_html()
    assert mla.count("Query normalisation") == 0
    assert mla.count("Key normalisation") == 0


# ---------------------------------------------------------------------------
# Code-derived FFN intermediate width (GPT-J/GPT-2/CodeGen n_inner=None -> 4*hidden)
# ---------------------------------------------------------------------------

def test_gptj_family_derives_the_ffn_width_end_to_end():
    """GPT-J/CodeGen/GPT-2 carry ``n_inner=None`` and compute 4×hidden — the
    parse must surface the real FFN width, not undercount it to zero."""
    from transformers import AutoConfig
    for mt, embd_field in (("gptj", "n_embd"), ("codegen", "n_embd"), ("gpt2", "n_embd")):
        cfg = AutoConfig.for_model(mt)
        cfg.n_inner = None
        ir = config_to_ir(cfg)
        hidden = getattr(cfg, "hidden_size", None) or getattr(cfg, embd_field)
        assert ir.layers[0].ffn.intermediate_size == 4 * hidden, mt
        fact = ir.extras["fact_provenance"]["decoder.ffn.intermediate_size"]
        assert fact["value"] == 4 * hidden
        assert fact["status"] == "code_and_config"


def test_declared_intermediate_size_is_qualified_by_the_exact_code_path():
    """Llama's declaration is retained because its exact FFN source consumes
    that occurrence — not merely because the plausible field is present."""
    from transformers import AutoConfig
    cfg = AutoConfig.for_model("llama")
    ir = config_to_ir(cfg)
    assert ir.layers[0].ffn.intermediate_size == cfg.intermediate_size
    fact = ir.extras["fact_provenance"]["decoder.ffn.intermediate_size"]
    assert fact["value"] == cfg.intermediate_size
    assert fact["status"] == "code_and_config"


# ---------------------------------------------------------------------------
# Norm-kind: code MATH outranks BOTH eps spellings (PhiMoE/Persimmon)
# ---------------------------------------------------------------------------

def test_norm_kind_math_outranks_the_rms_eps_spelling():
    """PhiMoE constructs ``nn.LayerNorm`` while carrying ``rms_norm_eps`` — the
    RMS eps spelling lies, the code math (torch-builtin LayerNorm) tells the
    truth.  T5 exposes rival encoder/decoder stages, so its epsilon spelling
    cannot stand in for an exact primitive and the diagram stays generic.
    Every unambiguous plain RMS/LN control is unchanged."""
    from transformers import AutoConfig
    expect = {"phimoe": "LayerNorm", "t5": "Wiring unresolved", "llama": "RMSNorm",
              "bloom": "LayerNorm", "gemma2": "RMSNorm", "qwen3": "RMSNorm"}
    for mt, want in expect.items():
        ir = config_to_ir(AutoConfig.for_model(mt))
        drawn = {b.get("label") for l in ir.layers for b in (l.blocks or [])
                 if isinstance(b, dict) and b.get("kind") == "norm"}
        assert drawn == {want}, f"{mt}: drew {drawn}, expected {want}"


def test_t5_two_stage_norm_stays_unknown_until_stage_selection_is_proven():
    """T5Model delegates to both encoder and decoder stacks.

    The exact address rail preserves both rivals; an epsilon field spelling
    must not pick a primitive or pretend one stage was selected.
    """
    from transformers import AutoConfig
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.decoder_norm import decoder_norm_kind_for_path
    cfg = AutoConfig.for_model("t5")
    context = ParseContext.build(cfg)
    result = decoder_norm_kind_for_path(
        context.program_index(), context.source_bundle, (),
        allow_root_stage=True)
    assert result.status == "ambiguous"
    ir = config_to_ir(cfg, parse_context=context)
    assert {layer.norm_kind for layer in ir.layers} == {"unknown"}


# ---------------------------------------------------------------------------
# Raw-JSON rung: config-class default hydration (identity-as-address at load)
# ---------------------------------------------------------------------------

def test_raw_json_hydration_fills_class_defaults_and_preserves_raw_and_stamps():
    from model_unfolder.parser import _hydrate_config_class_defaults as H
    raw = {"model_type": "gemma2", "num_hidden_layers": 4, "hidden_size": 256,
           "num_attention_heads": 8, "_repo_id": "stamp/keep"}
    h = H(raw)
    assert h.get("query_pre_attn_scalar") is not None      # class default materialized
    assert h["num_hidden_layers"] == 4                      # raw wins over any default
    assert h["_repo_id"] == "stamp/keep"                    # loader stamp survives
    assert h["model_type"] == "gemma2"


def test_raw_json_hydration_raw_value_overrides_a_class_default():
    from model_unfolder.parser import _hydrate_config_class_defaults as H
    over = {"model_type": "gemma2", "sliding_window": 999, "num_hidden_layers": 2,
            "hidden_size": 256, "num_attention_heads": 8}
    assert H(over)["sliding_window"] == 999


def test_raw_json_hydration_is_a_noop_for_unknown_or_typeless_configs():
    from model_unfolder.parser import _hydrate_config_class_defaults as H
    unk = {"model_type": "totally_unknown_xyz", "hidden_size": 128}
    assert H(unk) == unk
    assert H({"hidden_size": 128}) == {"hidden_size": 128}
    assert H("not a dict") == "not a dict"


# ---------------------------------------------------------------------------
# MoE router facts from code (GLM-4.5 sigmoid+bias; Phi sparsemixer)
# ---------------------------------------------------------------------------

_DSV3_SHAPED_ROUTER = '''
import torch
from torch import nn
import torch.nn.functional as F


class XTopkRouter(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.top_k = config.num_experts_per_tok
        self.n_group = config.n_group
        self.topk_group = config.topk_group
        self.weight = nn.Parameter(torch.empty((config.n_routed_experts, config.hidden_size)))
        self.register_buffer("e_score_correction_bias", torch.zeros((config.n_routed_experts)))

    def forward(self, hidden_states):
        return hidden_states


class XMoE(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.gate = XTopkRouter(config)
        self.experts = nn.ModuleList()

    def route_tokens_to_experts(self, hidden_states):
        router_logits = F.linear(hidden_states.type(torch.float32), self.gate.weight)
        router_logits = router_logits.sigmoid()
        router_logits_for_choice = router_logits + self.gate.e_score_correction_bias
        group_scores = router_logits_for_choice.view(-1, self.gate.n_group, 4).topk(2, dim=-1)[0].sum(-1)
        group_idx = torch.topk(group_scores, k=self.gate.topk_group, dim=-1)[1]
        group_mask = torch.zeros_like(group_scores)
        topk_indices = torch.topk(router_logits_for_choice, k=self.gate.top_k, dim=-1)[1]
        topk_weights = router_logits.gather(1, topk_indices)
        return topk_indices, topk_weights

    def forward(self, hidden_states):
        indices, weights = self.route_tokens_to_experts(hidden_states)
        return indices, weights
'''

_MIXTRAL_SHAPED_ROUTER = '''
import torch
from torch import nn


class XSparseMoeBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.gate = nn.Linear(config.hidden_size, config.num_local_experts, bias=False)
        self.top_k = config.num_experts_per_tok

    def forward(self, hidden_states):
        router_logits = self.gate(hidden_states)
        routing_weights = torch.nn.functional.softmax(router_logits, dim=1, dtype=torch.float)
        routing_weights, selected_experts = torch.topk(routing_weights, self.top_k, dim=-1)
        return selected_experts, routing_weights
'''

_SPARSEMIXER_SHAPED_ROUTER = '''
import torch
from torch import nn


def sparsemixer(scores, top_k, jitter_eps):
    threshold, selected = scores.max(dim=-1, keepdim=True)
    masked_scores = scores.masked_fill(scores < threshold, float("-inf"))
    masked_scores = torch.softmax(masked_scores, dim=-1)
    weights = masked_scores.gather(dim=-1, index=selected)
    remainder = torch.scatter(scores, -1, selected, float("-inf"))
    threshold_2, selected_2 = remainder.max(dim=-1, keepdim=True)
    masked_scores_2 = remainder.masked_fill(
        remainder < threshold_2, float("-inf"))
    masked_scores_2 = torch.softmax(masked_scores_2, dim=-1)
    weights_2 = masked_scores_2.gather(dim=-1, index=selected_2)
    return (
        torch.concat((weights, weights_2), dim=-1),
        torch.concat((selected, selected_2), dim=-1),
    )


class XPhiMoeBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.gate = nn.Linear(config.hidden_size, config.num_local_experts, bias=False)
        self.top_k = config.num_experts_per_tok

    def forward(self, hidden_states):
        router_logits = self.gate(hidden_states)
        routing_weights, selected_experts = sparsemixer(router_logits, self.top_k, jitter_eps=0.01)
        return selected_experts, routing_weights
'''

_GPTOSS_SHAPED_ROUTER = '''
import torch
from torch import nn
import torch.nn.functional as F


class XExperts(nn.Module):
    """Expert compute uses a sigmoid GLU — must NOT be read as router scoring."""
    def __init__(self, config):
        super().__init__()
        self.alpha = 1.702
        self.gate_up_proj = nn.Parameter(torch.empty(config.num_local_experts, config.hidden_size, 2))

    def forward(self, hidden_states, routing_weights):
        gate = hidden_states
        glu = gate * torch.sigmoid(gate * self.alpha)
        return glu * routing_weights


class XTopKRouter(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.top_k = config.num_experts_per_tok
        self.weight = nn.Parameter(torch.empty(config.num_local_experts, config.hidden_size))

    def forward(self, hidden_states):
        router_logits = F.linear(hidden_states, self.weight)
        router_top_value, router_indices = torch.topk(router_logits, self.top_k, dim=-1)
        router_scores = torch.nn.functional.softmax(router_top_value, dim=1)
        return router_indices, router_scores
'''


def _router_ev(tmp_path, src, implementation):
    from model_unfolder.evidence import program_index as pi
    from model_unfolder.evidence.router import (
        decoder_router_selection_for_path,
    )
    from model_unfolder.evidence.models import SourceBundle
    import hashlib
    src += f'''\n
class XExpertStorage(nn.Module):
    def __init__(self, config):
        self.count = config.num_local_experts
        self.width = config.intermediate_size
        self.hidden = config.hidden_size
        self.fused = nn.Parameter(torch.empty(
            self.count, 2 * self.width, self.hidden))
        self.down = nn.Parameter(torch.empty(
            self.count, self.hidden, self.width))
    def forward(self, hidden_states, routes, weights):
        out = torch.zeros_like(hidden_states)
        for expert in routes:
            gate, up = torch.nn.functional.linear(
                hidden_states, self.fused[expert]).chunk(2, dim=-1)
            mixed = torch.nn.functional.silu(gate) * up
            value = torch.nn.functional.linear(mixed, self.down[expert])
            out.index_add_(0, expert, value * weights)
        return out

class XRoutedCompute(nn.Module):
    def __init__(self, config):
        self.route = {implementation}(config)
        self.experts = XExpertStorage(config)
    def forward(self, hidden_states):
        indices, weights = self.route(hidden_states)
        return self.experts(hidden_states, indices, weights)

class Block(nn.Module):
    def __init__(self, config):
        self.compute = XRoutedCompute(config)
    def forward(self, hidden_states):
        return self.compute(hidden_states)

class Model(nn.Module):
    def __init__(self, config):
        self.layers = nn.ModuleList(
            [Block(config) for _ in range(config.num_hidden_layers)])
    def forward(self, hidden_states):
        for layer in self.layers:
            hidden_states = layer(hidden_states)
        return hidden_states

class Wrapper(nn.Module):
    base_model_prefix = "model"
    def __init__(self, config):
        self.model = Model(config)
'''
    f = tmp_path / f"modeling_{hashlib.md5(src.encode()).hexdigest()[:8]}.py"
    f.write_text(src)
    bundle = SourceBundle(
        source="local", files=(str(f),),
        component_files={"root": (str(f),)},
        component_architectures={"root": "Wrapper"},
        architecture="Wrapper")
    result = decoder_router_selection_for_path(
        pi.build_program_index(bundle), bundle, (), allow_root_stage=True)
    assert result.status == "resolved", result
    return result.value


def test_router_sigmoid_and_aux_free_bias_from_split_router_and_block(tmp_path):
    """DeepSeek-V3/GLM-4.5 shape: the bias buffer lives in the router class, the
    sigmoid + group + gather in the MoE block's route_tokens_to_experts — the
    exact reader follows the invoked block/helper path and proves sigmoid+bias."""
    ev = _router_ev(tmp_path, _DSV3_SHAPED_ROUTER, "XMoE")
    assert ev.scoring_fn == "sigmoid" and ev.bias_correction
    assert ev.selection_kind == "topk"


def test_router_plain_softmax_topk(tmp_path):
    ev = _router_ev(tmp_path, _MIXTRAL_SHAPED_ROUTER, "XSparseMoeBlock")
    assert ev.scoring_fn == "softmax"
    assert not ev.bias_correction and ev.selection_kind == "topk"


def test_router_sparsemixer_followed_into_the_free_function(tmp_path):
    """Phi shape: routing delegates to a module-level ``sparsemixer`` — the
    reader follows it one hop, reports sparsemixer + its softmax scoring."""
    ev = _router_ev(tmp_path, _SPARSEMIXER_SHAPED_ROUTER, "XPhiMoeBlock")
    assert ev.selection_kind == "sparse_mixer" and ev.scoring_fn == "softmax"
    assert not ev.bias_correction


def test_router_ignores_expert_activation_sigmoid(tmp_path):
    """gpt-oss shape: the EXPERT GLU uses ``torch.sigmoid(gate * alpha)`` — an
    activation, not routing.  Exact expert-storage ownership plus local
    score-to-selection dataflow resolves the router's softmax and prevents the
    expert sigmoid from leaking across that boundary."""
    ev = _router_ev(tmp_path, _GPTOSS_SHAPED_ROUTER, "XTopKRouter")
    assert ev.scoring_fn == "softmax", f"expert sigmoid leaked: {ev}"
    assert not ev.bias_correction and ev.selection_kind == "topk"


def test_router_none_for_dense_model(tmp_path):
    src = """
import torch
from torch import nn
class XMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.fc = nn.Linear(4, 4)
    def forward(self, x):
        return self.fc(x)
"""
    from model_unfolder.evidence import program_index as pi
    from model_unfolder.evidence.router import decoder_router_selection_for_path
    from model_unfolder.evidence.models import SourceBundle
    import hashlib
    src += """
class Block(nn.Module):
    def __init__(self, config): self.compute = XMLP(config)
    def forward(self, x): return self.compute(x)
class Model(nn.Module):
    def __init__(self, config):
        self.layers = nn.ModuleList([Block(config) for _ in range(config.num_hidden_layers)])
    def forward(self, x):
        for layer in self.layers: x = layer(x)
        return x
class Wrapper(nn.Module):
    base_model_prefix = "model"
    def __init__(self, config): self.model = Model(config)
"""
    f = tmp_path / f"dense_{hashlib.md5(src.encode()).hexdigest()[:8]}.py"
    f.write_text(src)
    bundle = SourceBundle(
        source="local", files=(str(f),),
        component_files={"root": (str(f),)},
        component_architectures={"root": "Wrapper"}, architecture="Wrapper")
    result = decoder_router_selection_for_path(
        pi.build_program_index(bundle), bundle, (), allow_root_stage=True)
    assert result.status == "failed"


def test_glm45_router_draws_sigmoid_bias_and_gather_from_code():
    """The headline S2 fix: GLM-4.5's config lacks scoring_func/topk_method but
    its code enacts DeepSeek-V3 routing — the drawn router must be sigmoid with
    a stored selection-only bias and raw-weight gather, not a plain softmax."""
    from transformers import AutoConfig
    import model_unfolder as mu
    html = mu.unfold(AutoConfig.for_model("glm4_moe")).to_html()
    assert "sigmoid" in html
    assert "Stored selection bias" in html   # exact selection-only bias card
    assert "load-balancing" not in html      # purpose/update policy is unproved
    assert "Gather weights" in html          # raw-weight gather step
    assert "softmax gating" not in html


def test_deepseek_v3_declared_and_code_agree_no_drift():
    """DSV3 declares scoring_func='sigmoid'+topk_method='noaux_tc' AND enacts
    them — code agrees with config, so no disagreement note is recorded."""
    import json
    from model_unfolder.sable import DEFAULT_CORPUS
    import model_unfolder as mu
    cfg = json.loads((DEFAULT_CORPUS / "deepseek-v3.json").read_text())["config"]
    routing = None
    for l in mu.config_to_ir(cfg).layers:
        if l.ffn.routing:
            routing = l.ffn.routing
    assert routing["scoring_func"] == "sigmoid" and routing.get("bias_correction")
    assert "_scoring_declared" not in routing      # config and code agree


def test_router_scoring_position_before_vs_after_topk(tmp_path):
    """The score transform's POSITION relative to top-k is a code fact: DSV3/GLM
    (softmax/sigmoid the full logits, THEN select) score before; gpt-oss/Granite
    (top-k the raw logits, THEN softmax the winners) score after.  Drives whether
    a scoring node is drawn before top-k — a node before top-k would misdraw
    gpt-oss."""
    before_shape = _DSV3_SHAPED_ROUTER                 # sigmoid() ... then torch.topk
    after_shape = _GPTOSS_SHAPED_ROUTER                # torch.topk ... then softmax
    assert _router_ev(tmp_path, before_shape, "XMoE").scoring_before_topk is True
    assert _router_ev(tmp_path, after_shape, "XTopKRouter").scoring_before_topk is False


def test_router_ignores_framework_container_aux_loss_softmax(tmp_path):
    """A ``*ForCausalLM`` wrapper that softmaxes router logits for the load-balance
    STAT (output_router_logits) must not be read as the selection scoring — the
    container is excluded, so a top-k-then-softmax block still resolves to
    scoring-after-topk, not an ambiguous None."""
    src = _GPTOSS_SHAPED_ROUTER + '''

class XForCausalLM(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.router = XTopKRouter(config)

    def forward(self, hidden_states):
        router_logits = hidden_states
        routing_weights = torch.nn.functional.softmax(router_logits, dim=-1)
        return routing_weights
'''
    ev = _router_ev(tmp_path, src, "XTopKRouter")
    assert ev.scoring_fn == "softmax" and ev.scoring_before_topk is False


def test_glm45_draws_the_sigmoid_scoring_node_before_topk():
    """Her Eyes lawfulness fix: GLM-4.5's router draws the sigmoid score
    transform as its OWN node between Linear (Gate) and Top-k, so the drill's
    'expert scores' has a visible origin."""
    from transformers import AutoConfig
    import model_unfolder as mu
    html = mu.unfold(AutoConfig.for_model("glm4_moe")).to_html()
    assert ">sigmoid<" in html                # a drawn node, not only a chip


# ---------------------------------------------------------------------------
# MoE-vs-dense layer SCHEDULE from construction evidence (code-authoritative)
# ---------------------------------------------------------------------------

_MOE_SCAFFOLD = '''
import torch
from torch import nn
from torch.nn import functional as F
from transformers.activations import ACT2FN


class XExperts(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.count = config.num_experts
        self.width = config.intermediate
        self.hidden = config.hidden_size
        self.fused = nn.Parameter(torch.empty(
            self.count, 2 * self.width, self.hidden))
        self.down = nn.Parameter(torch.empty(
            self.count, self.hidden, self.width))
        self.act = ACT2FN[config.hidden_act]

    def forward(self, x, routes, weights):
        output = torch.zeros_like(x)
        for index in routes:
            current = x[index]
            gate, up = F.linear(
                current, self.fused[index]).chunk(2, dim=-1)
            mixed = self.act(gate) * up
            projected = F.linear(mixed, self.down[index])
            output.index_add_(0, index, projected)
        return output


class XMoE(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.experts = XExperts(config)

    def forward(self, x):
        routes = torch.arange(self.experts.count)
        weights = torch.ones_like(routes)
        return self.experts(x, routes, weights)


class XMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.gate_proj = nn.Linear(config.hidden_size, config.intermediate_size)
        self.up_proj = nn.Linear(config.hidden_size, config.intermediate_size)
        self.down_proj = nn.Linear(config.intermediate_size, config.hidden_size)

    def forward(self, x):
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class XAttention(nn.Module):
    def __init__(self, config, layer_idx):
        super().__init__()
        self.q_proj = nn.Linear(config.hidden_size, config.hidden_size)
        self.k_proj = nn.Linear(config.hidden_size, config.hidden_size)
        self.v_proj = nn.Linear(config.hidden_size, config.hidden_size)
        self.o_proj = nn.Linear(config.hidden_size, config.hidden_size)

    def forward(self, hidden_states, past_key_values=None):
        return self.o_proj(self.v_proj(hidden_states))


class XDecoderLayer(nn.Module):
    def __init__(self, config, layer_idx):
        super().__init__()
        self.self_attn = XAttention(config, layer_idx)
        self.input_layernorm = nn.RMSNorm(config.hidden_size)
{ffn_ctor}

    def forward(self, hidden_states, past_key_values=None):
        return hidden_states + self.mlp(self.self_attn(self.input_layernorm(hidden_states)))


class XModel(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.layers = nn.ModuleList([
            XDecoderLayer(config, i) for i in range(config.num_hidden_layers)
        ])

    def forward(self, hidden_states):
        for layer in self.layers:
            hidden_states = layer(hidden_states)
        return hidden_states


class XForCausalLM(nn.Module):
    base_model_prefix = "model"

    def __init__(self, config):
        super().__init__()
        self.model = XModel(config)

    def forward(self, hidden_states):
        return self.model(hidden_states)
'''

# Gate forms — each substitutes the FFN-field construction block:
_CTOR_UNCONDITIONAL = "        self.mlp = XMoE(config)"
_CTOR_THRESHOLD = (
    "        if layer_idx >= config.first_k_dense_replace:\n"
    "            self.mlp = XMoE(config)\n"
    "        else:\n"
    "            self.mlp = XMLP(config)")
_CTOR_MEMBERSHIP_SELFFLAG = (
    "        self.is_moe_layer = layer_idx in config.moe_layers\n"
    "        if self.is_moe_layer:\n"
    "            self.mlp = XMoE(config)\n"
    "        else:\n"
    "            self.mlp = XMLP(config)")
_CTOR_EXCLUSION_AND = (
    "        if (layer_idx not in config.mlp_only_layers) and (config.num_experts > 0):\n"
    "            self.mlp = XMoE(config)\n"
    "        else:\n"
    "            self.mlp = XMLP(config)")
_CTOR_MODULO_AND = (
    "        if ((layer_idx + 1) % config.moe_layer_interval == 0) and (layer_idx >= config.moe_layer_start_index):\n"
    "            self.mlp = XMoE(config)\n"
    "        else:\n"
    "            self.mlp = XMLP(config)")
_CTOR_TERNARY = (
    "        self.mlp = XMoE(config) if layer_idx >= config.first_k_dense_replace else XMLP(config)")
_CTOR_DENSE = "        self.mlp = XMLP(config)"
# a MoE class MISLEADINGLY named MLP (gpt-oss shape) — must still read MoE
_CTOR_MISNAMED = "        self.mlp = XExperts(config)"   # XExperts builds experts → MoE despite call
# hybrid: two ffn fields (shared + moe) → ambiguous → None
_CTOR_MULTI = (
    "        self.shared_mlp = XMLP(config)\n"
    "        self.mlp = XMoE(config)")


def _sched(tmp_path, ctor, cfg):
    from model_unfolder.evidence.ffn_schedule import decoder_ffn_schedule_for_path
    from model_unfolder.evidence.models import SourceBundle
    from model_unfolder.evidence.program_index import build_program_index
    import hashlib
    f = tmp_path / f"modeling_{hashlib.md5(ctor.encode()).hexdigest()[:8]}.py"
    f.write_text(_MOE_SCAFFOLD.format(ffn_ctor=ctor))
    bundle = SourceBundle(
        source="local", files=(str(f),),
        component_files={"root": (str(f),)},
        component_architectures={"root": "XForCausalLM"},
        architecture="XForCausalLM")

    def select(path):
        current = cfg
        for part in path:
            if not isinstance(current, dict) or part not in current:
                return False, None, ""
            current = current[part]
        return True, current, "config_declared"

    result = decoder_ffn_schedule_for_path(
        build_program_index(bundle), bundle, (), allow_root_stage=True,
        config_selector=select)
    return ([item.state == "moe" for item in result.value.decisions]
            if result.status == "resolved" else None)


def test_moe_schedule_unconditional_all_moe(tmp_path):
    assert _sched(tmp_path, _CTOR_UNCONDITIONAL, {"num_hidden_layers": 4}) == [True]*4


def test_moe_schedule_threshold_dense_prefix(tmp_path):
    cfg = {"num_hidden_layers": 5, "first_k_dense_replace": 2}
    assert _sched(tmp_path, _CTOR_THRESHOLD, cfg) == [False, False, True, True, True]


def test_moe_schedule_membership_via_self_flag(tmp_path):
    """Llama-4 shape: self.is_moe_layer = layer_idx in config.moe_layers."""
    cfg = {"num_hidden_layers": 4, "moe_layers": [1, 3]}
    assert _sched(tmp_path, _CTOR_MEMBERSHIP_SELFFLAG, cfg) == [False, True, False, True]


def test_moe_schedule_exclusion_and_threshold(tmp_path):
    """Qwen shape: (layer_idx not in mlp_only_layers) and (num_experts > 0)."""
    cfg = {"num_hidden_layers": 4, "mlp_only_layers": [2], "num_experts": 8}
    assert _sched(tmp_path, _CTOR_EXCLUSION_AND, cfg) == [True, True, False, True]
    cfg0 = {"num_hidden_layers": 3, "mlp_only_layers": [], "num_experts": 0}
    assert _sched(tmp_path, _CTOR_EXCLUSION_AND, cfg0) == [False, False, False]


def test_moe_schedule_modulo_and_threshold(tmp_path):
    """Ernie shape: (layer_idx+1) % interval == 0 and layer_idx >= start."""
    cfg = {"num_hidden_layers": 6, "moe_layer_interval": 2, "moe_layer_start_index": 1}
    # (i+1)%2==0 → i in {1,3,5}; AND i>=1 → all of them
    assert _sched(tmp_path, _CTOR_MODULO_AND, cfg) == [False, True, False, True, False, True]


def test_moe_schedule_ternary(tmp_path):
    cfg = {"num_hidden_layers": 4, "first_k_dense_replace": 1}
    assert _sched(tmp_path, _CTOR_TERNARY, cfg) == [False, True, True, True]


def test_moe_schedule_dense_model_all_false(tmp_path):
    assert _sched(tmp_path, _CTOR_DENSE, {"num_hidden_layers": 3}) == [False]*3


def test_moe_schedule_detects_misnamed_moe_class(tmp_path):
    """gpt-oss shape: the MoE class is named like an MLP but builds experts —
    structural (name-independent) detection must still resolve MoE."""
    assert _sched(tmp_path, _CTOR_MISNAMED, {"num_hidden_layers": 2}) == [True]*2


def test_moe_schedule_ignores_an_uninvoked_dense_sibling(tmp_path):
    """A merely stored shared MLP cannot rival the exact invoked MoE field."""
    assert _sched(tmp_path, _CTOR_MULTI, {"num_hidden_layers": 4}) == [True] * 4


def test_moe_schedule_unresolvable_gate_returns_none(tmp_path):
    """A gate referencing an absent config field → None (never a wrong guess)."""
    cfg = {"num_hidden_layers": 4}   # first_k_dense_replace missing
    assert _sched(tmp_path, _CTOR_THRESHOLD, cfg) is None


def test_llama4_moe_schedule_now_drawn_moe_end_to_end():
    """A checkpoint-shaped Llama-4 declaration selects its exact MoE sites."""
    from transformers import AutoConfig
    import model_unfolder as mu
    # ``for_model`` alone is a class-created object, not a checkpoint.  Its
    # normalized ``moe_layers`` must not masquerade as checkpoint evidence;
    # serializing it models the actual config.json declaration consumed here.
    ir = mu.config_to_ir(AutoConfig.for_model("llama4_text").to_dict())
    moe = sum(1 for l in ir.layers if l.ffn.kind == "moe")
    assert moe == len(ir.layers) and moe > 0, f"only {moe}/{len(ir.layers)} MoE"


def test_ernie_moe_schedule_first_layer_dense_from_code():
    """The bug the sweep FOUND: Ernie's config path drew all-MoE; the code gate
    ((i+1)%interval==0 and i>=start=1) makes layer 0 dense."""
    from transformers import AutoConfig
    import model_unfolder as mu
    ir = mu.config_to_ir(AutoConfig.for_model("ernie4_5_moe").to_dict())
    kinds = [l.ffn.kind for l in ir.layers]
    assert kinds[0] == "dense" and kinds[1] == "moe"


def test_moe_schedule_working_families_unchanged():
    """The 12 agreeing families must stay MoE exactly as before (byte-stable):
    DeepSeek dense-prefix, Mixtral/Qwen3/gpt-oss all-MoE."""
    from transformers import AutoConfig
    import model_unfolder as mu
    ds = [l.ffn.kind for l in mu.config_to_ir(
        AutoConfig.for_model("deepseek_v3").to_dict()).layers]
    assert ds[:3] == ["dense"]*3 and all(k == "moe" for k in ds[3:])
    for mt in ("mixtral", "qwen3_moe", "gpt_oss"):
        ir = mu.config_to_ir(AutoConfig.for_model(mt).to_dict())
        assert all(l.ffn.kind == "moe" for l in ir.layers), mt


def test_moe_schedule_hybrid_returns_none_falls_back():
    """granitemoehybrid (Mamba-MoE) → code=None → config path (no crash)."""
    from transformers import AutoConfig
    import model_unfolder as mu
    ir = mu.config_to_ir(AutoConfig.for_model("granitemoehybrid"))  # must not raise
    assert ir.layers


# ---------------------------------------------------------------------------
# Per-layer SCHEDULE conformance lock (Group 1): the drawn per-layer type
# schedule must match the code's AUTHORITATIVE per-layer list — the net that
# would have caught the MoE interleave==1 inversion, locking sliding/NoPE/MoE
# against future re-derivation drift.
# ---------------------------------------------------------------------------

def test_sliding_schedule_matches_code_layer_types():
    """Every model declaring ``layer_types`` (the list the attention class reads
    as ``config.layer_types[layer_idx] == 'sliding_attention'``) must have its
    drawn per-layer sliding schedule EXACTLY match that list."""
    from transformers import AutoConfig
    import model_unfolder as mu
    for mt in ("gemma2", "gemma3_text", "cohere2", "gpt_oss", "qwen2", "qwen3"):
        cfg = AutoConfig.for_model(mt)
        lt = getattr(cfg, "layer_types", None)
        if not lt:
            continue
        drawn = [("slid" in str(l.attention.mask).lower())
                 for l in mu.config_to_ir(cfg).layers]
        code = [(x == "sliding_attention") for x in lt][:len(drawn)]
        assert drawn == code, f"{mt}: sliding schedule diverged from code layer_types"


def test_nope_schedule_declaration_does_not_project_without_selector_proof():
    """A config schedule is not proof of how the forward applies positions.

    Llama-4 exposes ``no_rope_layers``, but until U8 binds that declaration to
    the exact positional selector in source, U4 must preserve every layer as
    position-unknown rather than computing a plausible RoPE/NoPE schedule.
    """
    from transformers import AutoConfig
    import model_unfolder as mu
    for mt in ("llama4_text",):
        cfg = AutoConfig.for_model(mt)
        nrl = getattr(cfg, "no_rope_layers", None)
        if not isinstance(nrl, (list, tuple)):
            continue
        layers = mu.config_to_ir(cfg).layers
        assert layers
        assert all(layer.attention.no_rope is False for layer in layers)
        assert all(layer.attention.rope is None for layer in layers)
        assert all(
            (layer.attention.position_kind,
             layer.attention.position_application) == ("unknown", "unknown")
            for layer in layers
        )


def test_moe_schedule_matches_code_construction():
    """The drawn schedule equals the occurrence-exact construction schedule."""
    from transformers import AutoConfig
    import model_unfolder as mu
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.ffn_schedule import \
        decoder_ffn_schedule_for_path
    for mt in ("llama4_text", "deepseek_v3", "ernie4_5_moe"):
        cfg = AutoConfig.for_model(mt)
        document = cfg.to_dict()
        context = ParseContext.build(document)

        def select(path):
            current = document
            for part in path:
                if not isinstance(current, dict) or part not in current:
                    return False, None, ""
                current = current[part]
            return True, current, "config_declared"

        result = decoder_ffn_schedule_for_path(
            context.program_index(), context.source_bundle, (),
            allow_root_stage=True, config_selector=select)
        if result.status != "resolved":
            continue
        code = [item.state for item in result.value.decisions]
        drawn = [layer.ffn.kind for layer in mu.config_to_ir(document).layers]
        assert drawn == code[:len(drawn)], \
            f"{mt}: drawn FFN schedule != exact construction schedule"


def test_attention_sinks_spec_and_rendering_surface():
    """The exact-owner reader is pinned in test_attention_sinks; this control
    proves its positive fact remains an only-when-True rendered mechanism."""
    from model_unfolder.ir import AttentionSpec, _attention_to_dict
    from model_unfolder.adapters.transformer.blocks.attention import (
        attention_detail, attention_child_blocks)
    from model_unfolder.opgraph import attention_region

    plain = AttentionSpec(kind="gqa", num_heads=8, num_kv_heads=2, head_dim=64)
    assert "sinks" not in _attention_to_dict(plain)
    assert "sinks" not in attention_detail(plain)

    sunk = AttentionSpec(kind="gqa", num_heads=8, num_kv_heads=2, head_dim=64,
                         sinks=True)
    assert _attention_to_dict(sunk)["sinks"] is True
    d = attention_detail(sunk)
    assert d["sinks"] is True
    region = attention_region(d, 512)
    ids = {op.id for op in region.ops}
    # ONE spine box between scores and softmax — the sink logits are learned
    # PARAMETERS of the append op, never a side input node (side inputs made
    # the layout duplicate the downstream chain; U5 caught it twice)
    assert "sink_concat" in ids and "attention_sinks" not in ids
    assert any(e.src == "scaled_scores" and e.dst == "sink_concat"
               for e in region.edges)
    assert any(e.src == "sink_concat" and e.dst == "attn_softmax"
               for e in region.edges)
    assert not any(e.src == "scaled_scores" and e.dst == "attn_softmax"
                   for e in region.edges)
    card_ids = {c["id"] for c in attention_child_blocks(sunk, 512)}
    assert "sink_concat" in card_ids and "attention_sinks" not in card_ids


def test_unparsed_router_raises_ambiguity_not_softmax(tmp_path):
    """B4: config + code both silent on the score transform while source IS
    installed → the router block carries the ambiguous-evidence envelope (the
    BLOCKING net's food) and the card names no transform; resolved corpora
    (config-declared or code-read) carry no envelope."""
    import hashlib, json, pathlib
    from model_unfolder.adapters.transformer.parser import _moe_routing
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.models import SourceBundle

    # A MoE-ish source whose router class the extractor can't resolve (no
    # routing tokens at all) — scoring stays unread while source exists.
    src = '''
import torch.nn as nn
class OpaqueBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.self_attn = nn.Linear(config.hidden_size, config.hidden_size)
        self.mlp = nn.Linear(config.hidden_size, config.hidden_size)
    def forward(self, x, past_key_value=None):
        return self.mlp(self.self_attn(x))
'''
    f = tmp_path / f"modeling_{hashlib.md5(src.encode()).hexdigest()[:8]}.py"
    f.write_text(src)

    class _Cfg:
        num_experts = 8
        num_experts_per_tok = 2
    bundle = SourceBundle(
        source="local", files=(str(f),),
        component_files={"root": (str(f),)},
        component_architectures={"root": "OpaqueBlock"},
        architecture="OpaqueBlock")
    routing = _moe_routing(_Cfg(), ParseContext(bundle))
    assert routing and routing.get("evidence", {}).get("status") == "ambiguous"
    assert "scoring_func" not in routing

    # no source at all → oracle_missing territory, NO ambiguity stamp
    routing2 = _moe_routing(
        _Cfg(), ParseContext(SourceBundle(source="local", files=())))
    assert not (routing2 or {}).get("evidence")

    # blessed MoE fixtures stay envelope-free (config- or code-resolved)
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder import unfold
    for stem in ("deepseek-v3", "glm-4-5", "gpt-oss-20b"):
        fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / f"{stem}.json").read_text())
        d = unfold(fx["config"], inspect_code=True, code_source="local")
        js = d.to_json() if not callable(getattr(d, "to_json", None)) else d.to_json()
        blob = js if isinstance(js, str) else json.dumps(js)
        assert '"status": "ambiguous"' not in blob.replace("'", '"'), stem


def test_config_only_expert_counts_do_not_create_a_router_block(tmp_path):
    """The direct routing reader above retains its ambiguity control, but an
    expert count alone cannot create a MoE/router surface for that ambiguity
    to inhabit. U4-C must leave this exact opaque block source unresolved."""
    import hashlib
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.models import SourceBundle
    from model_unfolder.sable import _ambiguous_evidence_findings

    src = '''
import torch.nn as nn
class OpaqueBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.self_attn = nn.Linear(config.hidden_size, config.hidden_size)
        self.mlp = nn.Linear(config.hidden_size, config.hidden_size)
    def forward(self, x, past_key_value=None):
        return self.mlp(self.self_attn(x))
'''
    f = tmp_path / f"modeling_{hashlib.md5(src.encode()).hexdigest()[:8]}.py"
    f.write_text(src)
    cfg = {"model_type": "llama", "hidden_size": 256, "num_hidden_layers": 2,
           "num_attention_heads": 8, "num_key_value_heads": 8,
           "intermediate_size": 512, "vocab_size": 1000,
           "num_experts": 8, "num_experts_per_tok": 2}
    ctx = ParseContext(source_bundle=SourceBundle(source="local", files=(str(f),)),
                       source="local")
    from model_unfolder.parser import config_to_ir
    from model_unfolder.diagram import Diagram
    diagram = Diagram(config_to_ir(cfg, parse_context=ctx))
    findings = _ambiguous_evidence_findings(diagram.to_ir())
    assert not any("router" in x for x in findings), findings
    assert all(layer.ffn.kind is None for layer in diagram.ir.layers)


def test_companion_denoiser_notes_from_vocabulary():
    """A checkpoint key alone cannot assert a companion-denoiser mechanism."""
    import json, pathlib
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.adapters.diffusor.parser import parse as parse_diffusor

    fx = json.loads((pathlib.Path(DEFAULT_CORPUS)
                     / "wan2-2-t2v-a14b-diffusers.json").read_text())
    cfg = fx["config"]
    ir = parse_diffusor(cfg, context=ParseContext.build(cfg, source="local"))
    joined = " ".join(ir.notes or [])
    assert "transformer_2" not in joined and "0.875" not in joined

    twin_cfg = {"_class_name": "SomePipeline",
                "transformer": ["diffusers", "SomeTransformer2DModel"],
                "unconditional_transformer": ["diffusers", "SomeTransformer2DModel"],
                "num_layers": 2, "num_attention_heads": 8, "attention_head_dim": 64,
                "in_channels": 4, "joint_attention_dim": 2048}
    ir2 = parse_diffusor(twin_cfg)
    joined2 = " ".join(ir2.notes or [])
    assert "CFG twin" not in joined2 and "unconditional_transformer" not in joined2

    plain = {"_class_name": "SomePipeline",
             "transformer": ["diffusers", "SomeTransformer2DModel"],
             "num_layers": 2, "num_attention_heads": 8, "attention_head_dim": 64,
             "in_channels": 4, "joint_attention_dim": 2048}
    assert not [n for n in (parse_diffusor(plain).notes or [])
                if "companion" in n.lower() or "twin" in n.lower()]


def test_dit_attention_bias_declaration_does_not_prove_application():
    """A config value is a possible constructor operand, not proof that this
    exact denoiser attention applies biased projections."""
    import json, pathlib
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.adapters.diffusor.parser import parse as dparse
    fx = json.loads((pathlib.Path(DEFAULT_CORPUS)
                     / "pixart-sigma-xl-2-1024-ms.json").read_text())
    ir = dparse(fx["config"], context=ParseContext.build(fx["config"], source="local"))
    assert all(layer.attention.bias is None for layer in ir.layers)
    fx2 = json.loads((pathlib.Path(DEFAULT_CORPUS)
                      / "stable-diffusion-3-5-large.json").read_text())
    ir2 = dparse(fx2["config"], context=ParseContext.build(fx2["config"], source="local"))
    assert all(layer.attention.bias is None for layer in ir2.layers)


def test_dit_norm_kind_resolved_from_classes_when_config_silent():
    """A config ``norm_type`` cannot author or promote denoiser structure."""
    import copy, json, pathlib
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.adapters.diffusor.parser import parse as dparse

    for stem in ("stable-diffusion-3-5-large", "lumina-image-2-0"):
        fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / f"{stem}.json").read_text())
        cfg = fx["config"]
        rival = copy.deepcopy(cfg)
        rival["norm_type"] = "invented_config_norm"
        ir = dparse(cfg, context=ParseContext.build(cfg, source="local"))
        altered = dparse(rival, context=ParseContext.build(rival, source="local"))
        assert ir.layers == altered.layers
        assert ir.extras["render"] == altered.extras["render"]


def test_gemma2_softcaps_drawn_not_parked():
    """C1: attn_logit_softcapping becomes a REAL drawn node between QK^T and
    the softmax (+card), final_logit_softcapping reshapes the LM-head card;
    models without either stay byte-identical."""
    import json, pathlib
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder.parser import config_to_ir
    from model_unfolder.diagram import Diagram
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.opgraph import attention_region
    from model_unfolder.ir import AttentionSpec, _attention_to_dict
    from model_unfolder.adapters.transformer.blocks.attention import (
        attention_detail, attention_child_blocks)

    capped = AttentionSpec(kind="gqa", num_heads=8, num_kv_heads=4, head_dim=64,
                           logit_softcap=50.0)
    d = attention_detail(capped)
    assert d["logit_softcap"] == 50.0
    region = attention_region(d, 512)
    ids = {op.id for op in region.ops}
    assert "attn_softcap" in ids
    assert any(e.src == "scaled_scores" and e.dst == "attn_softcap" for e in region.edges)
    assert any(e.src == "attn_softcap" and e.dst == "attn_softmax" for e in region.edges)
    assert "attn_softcap" in {c["id"] for c in attention_child_blocks(capped, 512)}

    plain = AttentionSpec(kind="gqa", num_heads=8, num_kv_heads=4, head_dim=64)
    assert "logit_softcap" not in _attention_to_dict(plain)
    assert "attn_softcap" not in {op.id for op in attention_region(attention_detail(plain), 512).ops}

    # end-to-end on the gemma-2 fixture: node + LM-head softcap card present
    fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / "gemma-2-2b-it.json").read_text())
    cfg = fx["config"]
    diagram = Diagram(config_to_ir(cfg, parse_context=ParseContext.build(cfg, source="local")))
    ir = diagram.to_ir()
    attn = (ir.get("layers") or [{}])[0].get("attention") or {}
    assert attn.get("logit_softcap") == 50.0
    heads = [b for b in ((ir.get("extras") or {}).get("render") or {}).get("model_blocks", [])
             if b.get("id") == "lm_head"]
    assert heads and "softcap" in (heads[0].get("title") or "").lower()


def test_norm_placement_defaults_two_unknown_tiers():
    """B2 (U2 endpoint): placement has TWO unknown tiers.

    * source ABSENT (oracle_missing / zero evidence) → the pale
      "code-defined wiring" block — no fabricated pre-norm cells, no
      residual-tap claims (the tower_cell primitive on the main path);
    * source PRESENT but the reader abstained on the idiom → the
      conventional pre cell stays DRAWN (the op/nested-conformance oracle
      still checks its norms/residual ops against the readable forward())
      — recorded ambiguous + tagged asserted;
    * a proven placement (real source) carries no tag at all.

    Diffusion cell placement is now owned by U10's exact source projection and
    has its own tests; this remains the transformer two-tier regression."""
    from model_unfolder.adapters.transformer.parser import parse as parse_transformer
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.models import SourceBundle

    cfg = {"model_type": "llama", "hidden_size": 256, "num_hidden_layers": 2,
           "num_attention_heads": 8, "num_key_value_heads": 8,
           "intermediate_size": 512, "vocab_size": 1000}
    # Tier 1: no source at all → pale wiring block, nothing conventional.
    ctx = ParseContext(source_bundle=SourceBundle(source="local", files=()),
                       source="local")
    ir = parse_transformer(cfg, context=ctx)
    assert ir.layers[0].norm_placement == "unknown"
    ids = [b.get("id") for b in ir.layers[0].blocks if isinstance(b, dict)]
    assert "wiring_unresolved" in ids and "rms1" not in ids
    assert ctx.facts.records["decoder.layer.norm_placement"].status == "oracle_missing"

    # Tier 2/proven: real source (llama's topology reader proves pre) → the
    # concrete cell, no tag, code_proven ledger status.
    ctx2 = ParseContext.build(cfg, source="local")
    ir2 = parse_transformer(cfg, context=ctx2)
    assert ir2.layers[0].norm_placement == "pre"
    assert "norm_placement" not in (ir2.layers[0].ffn.asserted or ())
    assert ctx2.facts.records["decoder.layer.norm_placement"].status == "code_proven"


def test_asserted_facts_are_tagged_for_the_s4_blocking_ship_gate():
    """B5 (U2): the `asserted` tuple now carries ONLY the drawn conventions
    the doctrine keeps (sqrt(dim) scores, split storage, kept-pre placement) —
    everything else is either evidence-backed or a TYPED unknown, never a
    default presented as fact. mask specifically (strengthened by P2d): no
    architectures + no is_decoder, but the INSTALLED llama source
    unconditionally builds a causal mask — CODE-PROVEN causal now outranks
    the undeclared config (was a typed unknown before the reader existed);
    still no asserted tag either way."""
    import json, pathlib
    from model_unfolder import unfold
    from model_unfolder.sable import DEFAULT_CORPUS

    # bare llama-typed config WITHOUT architectures: decoder-ness undeclared
    # by CONFIG, but code-proven causal by the P2d reader — evidence-backed,
    # never a default presented as fact, no asserted tag.
    d = unfold({"model_type": "llama", "hidden_size": 256, "num_hidden_layers": 2,
                "num_attention_heads": 8, "num_key_value_heads": 8,
                "intermediate_size": 512, "vocab_size": 1000})
    ir = d.to_ir()
    attn = ir["layers"][0]["attention"]
    assert attn["mask"] == "causal"
    prov = (ir.get("extras") or {}).get("fact_provenance") or {}
    assert prov["decoder.attention.mask"]["status"] == "code_and_config"
    assert "mask" not in (attn.get("asserted") or [])
    # scores_scale NOT tagged: the B1 code read backs sqrt(dim) (source installed)
    assert "scores_scale" not in (attn.get("asserted") or [])

    # the SAME config with the real checkpoint's declaration draws causal
    # with no tag (config_declared, not asserted).
    d2 = unfold({"model_type": "llama", "architectures": ["LlamaForCausalLM"],
                 "hidden_size": 256, "num_hidden_layers": 2,
                 "num_attention_heads": 8, "num_key_value_heads": 8,
                 "intermediate_size": 512, "vocab_size": 1000})
    attn2 = d2.to_ir()["layers"][0]["attention"]
    assert attn2["mask"] == "causal"
    assert "mask" not in (attn2.get("asserted") or [])

    # a fully declared+code-backed model: FFN carries no asserted key at all
    fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / "llama-7b.json").read_text())
    ir2 = unfold(fx["config"], inspect_code=True, code_source="local").to_ir()
    assert "asserted" not in ir2["layers"][0]["ffn"]


def test_unet_ffn_activation_anchored_to_declared_blocks():
    """The production FFN graph comes from its exact constructed occurrence."""
    import json, pathlib, re
    from model_unfolder.sable import DEFAULT_CORPUS
    fx = json.loads((pathlib.Path(DEFAULT_CORPUS)
                     / "stable-diffusion-xl-base-1-0.json").read_text())
    cfg = fx["config"]
    # The production card cites the fact for its own constructed occurrence.
    from model_unfolder import unfold
    from model_unfolder.lint import _walk_blocks
    diagram = unfold(cfg, inspect_code=True, code_source="local")
    ir = diagram.to_ir()
    card = next(block for block in _walk_blocks(ir)
                if block.get("view") == "runtime_ffn")
    key = "root.denoiser.ffn_mechanisms"
    assert key in card["source_fact_keys"]
    fact = ir["extras"]["fact_provenance"][key]
    assert fact["status"] == "code_proven"
    value = fact["value"][card["source_instance_path"]]
    assert value["gated"] is True
    assert value["activation"] == "gelu"
    assert value["projection_mode"] == "fused_gate_up"
    assert all(card["detail"]["ffn"][name] == value[name] for name in value)

    operation_ids = {child["id"] for child in card["children"]
                     if child.get("role") == "operation"}
    namespace = card["detail"]["op_namespace"]
    assert operation_ids == {namespace + suffix for suffix in
                             ("gate_up_proj", "gate_up_split", "activation", "multiply", "down_proj")}
    own_svgs = [svg for svg in re.findall(r"<svg\b.*?</svg>", expand_card_payloads(diagram.to_html()), re.S)
                if operation_ids <= set(re.findall(r'data-id="([^"]+)"', svg))]
    assert own_svgs, "the cited FFN's operation nodes must be drawn together"
    assert all("GELU" in svg and "gelu-approximate" not in svg for svg in own_svgs)


def test_mla_kind_cross_check_both_directions(tmp_path):
    """U3: fact-conformance polices the attention KIND — a code-MLA drawn as
    GQA flags wrong_attention; drawn-MLA with no code MLA flags fabricated;
    agreeing models (DeepSeek drawn+code MLA, Llama neither) stay clean."""
    import json, pathlib
    from model_unfolder.sable import DEFAULT_CORPUS
    from model_unfolder.evidence.conformance import check_fact_conformance
    from model_unfolder import unfold

    for stem in ("deepseek-v3", "llama-7b"):
        fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / f"{stem}.json").read_text())
        d = unfold(fx["config"], inspect_code=True, code_source="local")
        probs = [p for p in check_fact_conformance(fx["config"], d.to_ir())
                 if "attention_kind" in (p.view or "")]
        assert not probs, (stem, [p.message for p in probs])

    # a code-MLA whose config hides the latent ranks: drawn GQA must flag
    fx = json.loads((pathlib.Path(DEFAULT_CORPUS) / "deepseek-v3.json").read_text())
    hidden = {k: v for k, v in fx["config"].items()
              if k not in ("kv_lora_rank", "q_lora_rank",
                           "qk_nope_head_dim", "qk_rope_head_dim")}
    d2 = unfold(hidden, inspect_code=True, code_source="local")
    kinds = {(l.get("attention") or {}).get("kind") for l in d2.to_ir()["layers"]}
    if "mla" not in kinds:                      # config path indeed drew GQA/MHA
        probs2 = check_fact_conformance(hidden, d2.to_ir())
        assert any(p.kind == "wrong_attention" and "attention_kind" in (p.view or "")
                   for p in probs2), [p.message for p in probs2]


def test_cross_attention_schedule_matches_declared_layers():
    """U8-F: source selection + Q/K/V lineage, never the list alone, owns it.

    The composite wrapper supplies an exact construction address and resolves.
    A bare component config without an architecture address cannot silently
    borrow the config list; once that same config supplies the exact class
    address, the identical source proof resolves.
    """
    from transformers import AutoConfig
    import model_unfolder as mu
    from model_unfolder.evidence.context import ParseContext
    from model_unfolder.evidence.qualification import qualification_findings
    wrapper = AutoConfig.for_model("mllama")
    declared = list(wrapper.text_config.cross_attention_layers)
    context = ParseContext.build(wrapper)
    ir = mu.config_to_ir(wrapper, parse_context=context)
    assert [i for i, layer in enumerate(ir.layers)
            if layer.attention.cross_attention] == declared
    fact = context.facts.typed[
        "decoder.attention.cross_attention_schedule"]
    assert fact.status == "code_and_config"
    assert [i for i, kind in enumerate(fact.value)
            if kind == "replacement_cross"] == declared
    assert qualification_findings(ir.to_dict()) == []

    bare = AutoConfig.for_model("mllama_text_model")
    ir = mu.config_to_ir(bare)
    assert not [layer for layer in ir.layers
                if layer.attention.cross_attention]

    addressed = bare.to_dict()
    addressed["architectures"] = ["MllamaTextModel"]
    ir = mu.config_to_ir(addressed)
    assert [i for i, layer in enumerate(ir.layers)
            if layer.attention.cross_attention] == declared


def test_hybrid_mixer_schedule_is_bound_to_qwen3_next_source_selection():
    """Qwen3-Next is a second real source shape on the exact U8-D rail.

    The config list supplies values only after the source proves the indexed
    construction and matching invocation for both candidate mechanisms.
    """
    from transformers import AutoConfig
    import model_unfolder as mu
    from model_unfolder.evidence.context import ParseContext
    for mt in ("qwen3_next",):
        cfg = AutoConfig.for_model(mt).to_dict()
        lt = list(cfg.get("layer_types") or [])
        if not lt:
            continue
        context = ParseContext.build(cfg)
        ir = mu.config_to_ir(cfg, parse_context=context)
        drawn = [l.attention.kind in ("gated_delta", "linear", "ssm", "rwkv")
                 for l in ir.layers]
        code = [x == "linear_attention" for x in lt][:len(drawn)]
        assert drawn == code, f"{mt}: mixer schedule diverged from layer_types"
        fact = context.facts.typed["decoder.attention.mixer_schedule"]
        assert fact.status in {"code_and_config", "class_default"}
        assert tuple(item == "gated_delta" for item in fact.value) == tuple(code)
        assert "layer_types" in fact.config_paths


def test_patch_ops_humanized_and_plumbing_collapsed():
    """Theme-L (all three Her Eyes DISLIKEs): a raw implementation CLASS NAME
    is never a drawn patch-op label (structure names the op; the class rides
    as provenance), and CONSECUTIVE reshape-kind plumbing collapses into one
    step whose card enumerates every move — the Tower-Census fallback rule."""
    from transformers import AutoConfig
    import model_unfolder as mu
    from model_unfolder.evidence.models import SourceOp
    from model_unfolder.evidence.vision import _collapse_plumbing_runs

    # collapse: 3 consecutive reshapes → 1 op, description enumerates in order
    ops = [SourceOp("conv", "Patch convolution", "X", "f.py", 1),
           SourceOp("reshape", "Flatten spatial grid", "X", "f.py", 2),
           SourceOp("reshape", "Transpose to tokens", "X", "f.py", 3),
           SourceOp("reshape", "Regroup patch tokens", "X", "f.py", 4),
           SourceOp("norm", "LayerNorm", "X", "f.py", 5)]
    got = _collapse_plumbing_runs(ops)
    assert [o.kind for o in got] == ["conv", "reshape", "norm"]
    assert "Flatten spatial grid → Transpose to tokens → Regroup patch tokens" \
        in got[1].description
    # single reshapes pass through untouched
    assert _collapse_plumbing_runs(ops[:2])[1].label == "Flatten spatial grid"

    # end-to-end: no camelCase class-name labels in any modality op list
    for mt in ("llama4", "gemma3", "qwen2_vl"):
        try:
            cfg = AutoConfig.for_model(mt)
        except Exception:
            continue
        ir = mu.unfold(cfg, inspect_code=True, code_source="local").to_ir()
        mods = ((ir.get("extras") or {}).get("modalities") or {}).get("inputs") or {}
        for name in ("vision", "video"):
            for op in ((mods.get(name) or {}).get("embedding") or {}).get("ops") or []:
                label = op["label"]
                assert not (label[:1].isupper() and any(c.islower() for c in label)
                            and any(c.isupper() for c in label[1:])
                            and " " not in label and label not in ("LayerNorm", "RMSNorm")), \
                    f"{mt}/{name}: class-name-like label {label!r}"
