"""One immutable source-resolution context shared by one model parse.

Architectural parsing used to resolve the same Transformers/Diffusers source in
each detector independently, and Sable resolved it again for every conformance
net.  Besides wasted work, that made a name-blind parse impossible: scrubbing
``model_type`` also removed the address needed to rediscover source.

``ParseContext`` separates those phases.  Identity may be used once to locate
the source bundle; every architectural detector then consumes that already
resolved bundle.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any

from .config_access import ConfigAccessLedger
from .identity_roles import identity_address
from .models import SourceBundle
from .sources import resolve_source_files


# The provenance tiers a structural fact can carry (U2, CONFIG_ABLATION_CENSUS):
# a fact either has evidence (which channel) or is an honest unknown — an
# ``asserted`` entry is a default presented as fact, the class the census net
# drives to zero.
FACT_STATUSES = frozenset({
    "code_proven",      # read from the modeling source (AST)
    "config_declared",  # the checkpoint's own config declaration
    "class_default",    # the installed config CLASS default (hydration channel)
    "code_and_config",  # code proves the mechanism + names the deciding config
                        # field; the config supplies WHICH value (U2 P2c —
                        # the ACT2FN[config.hidden_act] dispatch idiom)
    "derived",          # computed from other evidenced facts
    "ambiguous",        # source present but the mechanism did not resolve
    "oracle_missing",   # no source to read — honest absence
    "asserted",         # a default presented as fact (census target: zero)
    "unknown",          # honestly undecided; renders pale
})


@dataclass(frozen=True)
class FactRecord:
    """One structural fact's value + the evidence tier that backs it."""

    value: Any
    status: str
    source: str | None = None  # reader name / config field / file:line


# U2-R5: an ambient handle to the parse's fact ledger, so deep readers (a
# modality projector's width consumption) can record a typed fact WITHOUT the
# modality build protocol threading ``context`` — mirrors the config-access
# ambient ledger, and activates in the SAME ``config_to_ir`` scope so the two
# ledgers can never desynchronize.  ``None`` outside a parse (a no-op).
_active_facts: ContextVar = ContextVar("model_unfolder_active_facts", default=None)


def active_facts():
    """The fact ledger of the parse currently running, or ``None``."""
    return _active_facts.get()


@contextmanager
def capture_facts(ledger):
    """Route ambient fact records to ``ledger`` for the enclosed parse."""
    token = _active_facts.set(ledger)
    try:
        yield ledger
    finally:
        _active_facts.reset(token)


@dataclass
class FactLedger:
    """Call-local per-fact provenance for one parse (U2 P0).

    Owners are stable dotted paths ("decoder.attention", "decoder.ffn",
    "decoder.layer", "head"); facts are the spec field names. The ledger is
    ADDITIVE bookkeeping: it never changes what the parser decides, it records
    which channel decided it — the projection-audit and census nets read it.
    """

    records: dict[str, FactRecord] = field(default_factory=dict)
    # H1: typed EvidenceFact instances, keyed like ``records``.  Populated only
    # through :meth:`record_typed`, which derives the legacy row FROM the typed
    # fact — one author, so the two views cannot diverge for typed keys.
    typed: dict[str, Any] = field(default_factory=dict)

    def record(self, owner: str, fact: str, value: Any, status: str,
               source: str | None = None) -> None:
        if status not in FACT_STATUSES:
            raise ValueError(f"unknown fact status {status!r}")
        key = f"{owner}.{fact}"
        self.records[key] = FactRecord(value, status, source)
        # A later legacy author replaces the entire fact, including its old
        # typed proof/unknown metadata. Never retain a proof for the old value.
        self.typed.pop(key, None)

    def record_typed(self, fact: Any) -> None:
        """Record one :class:`~.facts.EvidenceFact`; the serialized legacy row
        is derived from it (H1.1 — the typed object is the single author).

        §16.4: the write is validated against the closed fact registry
        (key/owner/status/value-type/negative-completeness) before it is
        recorded, so a typed write cannot bypass the registry by choosing a
        different representation."""
        from .facts import EvidenceFact
        if not isinstance(fact, EvidenceFact):
            raise TypeError(f"record_typed wants an EvidenceFact, got {type(fact)!r}")
        from .registry import validate_typed_write
        problems = validate_typed_write(fact)
        if problems:
            raise ValueError(
                "typed write violates the fact registry (H2): " + "; ".join(problems))
        key = fact.ledger_key()
        self.typed[key] = fact
        self.records[key] = fact.to_record()

    def typed_records(self) -> dict[str, Any]:
        """Every fact as an :class:`~.facts.EvidenceFact`: natively-typed keys
        as recorded; legacy rows lifted on demand (H1 representability)."""
        from .facts import EvidenceFact
        out = dict(self.typed)
        for key, rec in self.records.items():
            if key not in out:
                out[key] = EvidenceFact.from_record(key, rec)
        return out

    def strength(self, key: str) -> int:
        """I-5 resolver over this ledger: a derived fact is as strong as its
        weakest premise, recursively; absent premises and cycles resolve to 0."""
        from .facts import resolve_strength
        return resolve_strength(key, self.typed_records())

    def asserted(self) -> tuple[str, ...]:
        return tuple(sorted(k for k, r in self.records.items()
                            if r.status == "asserted"))

    def to_dict(self) -> dict[str, dict]:
        from ..presentation import ChipFactReference
        typed = self.typed_records()
        result = {}
        for key, rec in sorted(self.records.items()):
            fact = typed[key]
            result[key] = {
                "value": rec.value, "status": rec.status,
                **({"source": rec.source} if rec.source else {}),
                "presentation_reference": ChipFactReference.from_fact(fact).to_dict(),
                **({"unknown_reason": fact.unknown_reason.to_dict()}
                   if fact.unknown_reason is not None else {}),
            }
        return result


@dataclass
class ParseContext:
    """Call-local evidence state for one parse/conformance run."""

    source_bundle: SourceBundle
    source: str = "local"
    # The ambient OWNERSHIP namespace of this parse in the pipeline's global
    # component tree: "root" for a top-level parse, "root.text_encoder" /
    # "root.text_encoder_2" / … for a recursively-parsed diffusion encoder
    # slot (composes for deeper nesting).  Every owned fact/consumption this
    # parse authors is namespaced under it, so a sub-component's modality
    # (mistral3-as-text-encoder's vision) is owned by root.text_encoder.vision,
    # never falsely attributed to the pipeline's top-level root.vision.
    component_namespace: str = "root"
    # Later evidence units cache component-qualified AST registries here.  The
    # cache is call-local: no model or concurrent render can contaminate it.
    registries: dict[tuple[str, tuple[str, ...]], dict] = field(default_factory=dict)
    # U2: per-fact provenance, filled at the parser's decision points.
    facts: FactLedger = field(default_factory=FactLedger)
    # U1 (§20.4.2): the call-local config-access ledger LIVES here; the
    # capture ContextVar only routes nested calls to this context's ledger and
    # is never a second truth store.  Compat bare-name views derive from it.
    config_access: ConfigAccessLedger = field(default_factory=ConfigAccessLedger)
    # U10-F4: receipts emitted by an actual non-render structural consumer
    # (currently the diffusion typed-spec projector).  They remain call-local;
    # Sable admits and context-stamps only the receipts carried by the same
    # ParseContext that produced the IR being checked.
    projection_receipts: list[Any] = field(default_factory=list)
    # U2-R1 (§5.1): the prepared document for each component owner, keyed by the
    # EXACT owner ("root", "root.text_encoder", …).  A parser or renderer reads
    # its document's provenance from here rather than re-preparing (which was the
    # double-hydration bug) or guessing the owner from a module name.
    prepared_documents: dict = field(default_factory=dict)
    # U2 retired the global ``projection_receipts_available`` boolean: receipt
    # coverage is now owner/mechanism-SCOPED (evidence/receipts.py
    # RECEIPTED_SCOPES, published as ir.extras.config_access.projection_coverage)
    # and joined at render time, so a scope migrates without a parse-time flag.
    # U2 class_default tier: the installed config CLASS's own defaults,
    # resolved ONCE at context build (identity-as-ADDRESS — the same rail
    # source resolution uses; the class is code evidence and the parse stays
    # name-blind because detectors consume this resolved dict exactly like
    # they consume the resolved source bundle). ``None`` when the
    # model_type is absent/unregistered.
    class_defaults: dict | None = None
    # The same code-derived config-class defaults, qualified by their exact
    # document path and resolved from the ORIGINAL document once.  A
    # name-blind replay reuses this address result instead of consulting the
    # scrubbed identity again; sibling text/vision/audio configs can never
    # borrow one another's defaults.
    class_defaults_by_path: dict[tuple[str, ...], dict] = field(
        default_factory=dict)
    # U2 mask family: the config's decoder-ness DECLARATION (is_decoder /
    # architectures[] role suffix / decoder-only wrapper / composite decoder
    # slot), resolved once here so the name-blind guard's scrubbed parse
    # consumes the same declaration instead of re-deriving it from the
    # scrubbed dict. ``None`` ⇒ nothing declares decoder-ness.
    declared_decoderness: str | None = None
    # U3: parser and conformance consume the SAME owner-qualified reader
    # result.  The key includes the exact selected config path, so a wrapper's
    # decoder result cannot be reused for its vision/audio/text sibling.
    reader_results: dict[tuple[str, tuple[str, ...]], Any] = field(
        default_factory=dict)
    selected_config_paths: dict[str, tuple[str, ...]] = field(
        default_factory=dict)
    # The retained immutable observation snapshot for this parse. Readers may
    # close additional source addresses monotonically; adoption preserves all
    # prior observations and invalidates only derived current-index ownership.
    _program_index: Any = None
    # One-time S8 scratch demonstration capability. No product/config field
    # selects an override; the static bundle and isolated builder must agree.
    source_overrides: tuple[Any, ...] = ()
    # Independent checkpoint evidence supplied by the header reader. This
    # channel is separate from config hydration and from recipe observations.
    checkpoint_headers: tuple[Any, ...] = ()
    construction_inventory: Any = None
    # U9-A: the ONE exact root/nested-component ownership inventory derived
    # from this context's ProgramIndex.  It is address evidence only and stays
    # lazy until a modality reader asks for it.
    _component_inventory: Any = None

    def __post_init__(self):
        from physics.result_cache import register_source_context
        register_source_context(self)

    def program_index(self):
        """Return this parse's retained immutable source-closure snapshot.

        The initial bundle is assembled lazily. An explicit monotone adoption
        may retain a reader's larger closure; prior snapshots remain immutable.
        """
        if self._program_index is None:
            from .program_index import build_program_index
            self._program_index = build_program_index(self.source_bundle)
        return self._program_index

    def adopt_program_index(self, index):
        """Retain a reader's exact extension without replacing old evidence.

        Every observation tuple must preserve its previous prefix. A source
        address cannot acquire different bytes, even under another ownership
        identity. Reader results, facts and receipts retain their authored
        snapshots; only the derived current-index component inventory expires.
        """
        from dataclasses import fields
        from .program_index import ProgramIndex
        if not isinstance(index, ProgramIndex):
            raise TypeError("retained source closure requires a ProgramIndex")
        previous = self.program_index()
        if index is previous:
            return
        if index.bundle_source != previous.bundle_source:
            raise ValueError("retained source closure must use the same bundle")
        for observation_field in fields(ProgramIndex):
            if observation_field.name in {"bundle_source", "fingerprint"}:
                continue
            before, after = getattr(previous, observation_field.name), getattr(index, observation_field.name)
            if not isinstance(after, tuple) or after[:len(before)] != before:
                raise ValueError("retained source closure changed prior " + observation_field.name)
        contents = {}
        source_ids = [node.source_id for node in index.source_nodes]
        source_ids.extend(row.source for row in index.parse_failures)
        for source in source_ids:
            prior = contents.setdefault(source.canonical_path, source.content_fingerprint)
            if prior != source.content_fingerprint:
                raise ValueError("retained source closure changed bytes at " + source.canonical_path)
        self._program_index = index
        self._component_inventory = None

    def component_inventory(self):
        """Ownership derived from the retained index; refreshed on adoption."""
        if self._component_inventory is None:
            from .component_inventory import resolve_component_inventory
            self._component_inventory = resolve_component_inventory(
                self.program_index(), self.source_bundle)
        return self._component_inventory

    def cached_reader_result(self, reader: str, config_path, factory):
        if not isinstance(reader, str) or not reader:
            raise ValueError("a cached reader requires a stable non-empty name")
        path = tuple(config_path)
        if any(not isinstance(part, str) or not part for part in path):
            raise TypeError("cached reader config paths are tuple[str, ...]")
        key = (reader, path)
        if key in self.reader_results:
            from .config_access import current_prepared_document
            from .reader_result import ReaderResult
            prepared = current_prepared_document.get()
            cached = self.reader_results[key]
            if prepared is not None and isinstance(cached, ReaderResult):
                from .reader_claims import reader_claim_scope_matches, reader_requires_claim_scope
                if reader_requires_claim_scope(cached) and not reader_claim_scope_matches(
                        cached, self.program_index(), prepared):
                    # Rerun the actual producer under this invocation boundary;
                    # a stale/unbound return must never gain post-hoc authority.
                    self.reader_results[key] = factory()
        if key not in self.reader_results:
            self.reader_results[key] = factory()
        return self.reader_results[key]

    @classmethod
    def build(
        cls,
        target: Any,
        *,
        source: str = "local",
        token: Any = None,
    ) -> "ParseContext":
        from .decoderness import declared_decoderness
        defaults_by_path = _installed_config_defaults_by_path(target)
        return cls(
            source_bundle=resolve_source_files(target, source=source, token=token),
            source=source,
            class_defaults=defaults_by_path.get(()),
            class_defaults_by_path=defaults_by_path,
            declared_decoderness=declared_decoderness(target),
        )


@identity_address
def _installed_config_defaults(target: Any) -> dict | None:
    """The config CLASS overlay for this exact checkpoint document.

    This must use the same preparation primitive as the parser boundary.  A
    stock ``AutoConfig.for_model(model_type)`` instance is *not* the class
    overlay for a checkpoint: derived defaults can depend on values the
    checkpoint supplied (for example Llama's ``head_dim`` depends on its
    hidden width and head count).  Building an empty stock config therefore
    fabricated dimensions for small/custom checkpoints.

    The returned mapping contains only class-supplied or class-normalized
    candidates.  Checkpoint declarations stay in their original document and
    are arbitrated separately; this preserves the Falcon ``multi_query`` law.
    Never executes model code.
    """
    if not isinstance(target, dict) or not target.get("model_type"):
        return None
    from .document import prepare_document
    prepared = prepare_document(target, merge=False)
    if prepared.failure is not None:
        return None
    return dict(prepared.class_overlay)


def _installed_config_defaults_by_path(
    target: Any,
) -> dict[tuple[str, ...], dict]:
    """Resolve config-class address metadata once for every declared scope."""
    out: dict[tuple[str, ...], dict] = {}
    active: set[int] = set()

    def walk(value: Any, path: tuple[str, ...], depth: int) -> None:
        identity = id(value)
        if depth > 5 or identity in active:
            return
        active.add(identity)
        defaults = _installed_config_defaults(value)
        if isinstance(defaults, dict):
            out[path] = defaults
        if isinstance(value, dict):
            children = value.items()
        elif hasattr(value, "to_dict"):
            try:
                children = value.to_dict().items()
            except (TypeError, ValueError, AttributeError):
                children = ()
        else:
            children = ()
        for key, child in children:
            if isinstance(child, dict) or hasattr(child, "to_dict"):
                walk(child, (*path, str(key)), depth + 1)
        active.remove(identity)

    walk(target, (), 0)
    return out


__all__ = ["ParseContext", "FactLedger", "FactRecord", "FACT_STATUSES"]


# U2-R9: ONE slot-context builder (moved from the diffusor adapter —
# the transformer composite conditioning slot needs the identical
# derive-from-the-enclosing-resolution behavior; the name-blind law
# depends on it: a sub-parse must never re-resolve source/identity
# from its own, possibly scrubbed, sub-config).
def slot_parse_context(root_context, slot: str, *,
                       namespace: str | None = None,
                       document: Any = None,
                       binding: Any = None):
    """A ParseContext for one pipeline SLOT (text_encoder / text_encoder_2 / …),
    derived from the root's ALREADY-RESOLVED bundle.  The sub-parse must not
    re-resolve source from its own sub-config: the pipeline resolution already
    qualified this component's files, and a fresh resolve from the sub-config
    alone silently degrades whenever that sub-config loses its address (the
    name-blind harness scrubs it; a minimal frozen config never had it).
    None when the root carries no files for the slot — the caller then builds
    its own context exactly as before."""
    if root_context is None:
        return None
    from .models import SourceBundle
    bundle = getattr(root_context, "source_bundle", None)
    all_files = getattr(bundle, "component_files", {}) or {}
    if not all_files.get(slot):
        return None
    # Graft the slot's whole QUALIFIED SUBTREE, re-rooted: the slot itself
    # becomes "root" and inner delegations keep their relative paths
    # (``text_encoder.text_config`` → ``text_config``), so a wrapper encoder's
    # delegated stack (Mistral3 → Mistral) stays resolvable in the sub-parse.
    prefix = slot + "."
    def _reroot(mapping: dict) -> dict:
        out = {}
        for key, value in (mapping or {}).items():
            if key == slot:
                out["root"] = value
            elif key.startswith(prefix):
                out[key[len(prefix):]] = value
        return out
    component_files = {k: tuple(v) for k, v in _reroot(all_files).items()}
    supporting_files = {
        k: tuple(v) for k, v in _reroot(
            getattr(bundle, "supporting_files", {}) or {}).items()
    }
    files: list[str] = []
    for group in component_files.values():
        files.extend(f for f in group if f not in files)
    component_model_types = _reroot(getattr(bundle, "component_model_types", {}) or {})
    component_architectures = _reroot(getattr(bundle, "component_architectures", {}) or {})
    sub_bundle = SourceBundle(
        source=bundle.source,
        files=tuple(files),
        model_type=component_model_types.get("root"),
        architecture=component_architectures.get("root"),
        component_files=component_files,
        supporting_files=supporting_files,
        component_model_types=component_model_types,
        component_architectures=component_architectures,
    )
    # U2: the slot context must carry the SAME pre-resolved declaration
    # channels ParseContext.build gives a standalone parse (class defaults;
    # decoder-ness), or embedded ≠ standalone (the parity net's law). They
    # derive from the BUNDLE's own per-component records — resolved once at
    # root resolution, so a scrubbed (name-blind) sub-config cannot change
    # them, exactly like the pre-resolved source files.
    from .decoderness import declared_decoderness
    _slot_identity = {
        "model_type": component_model_types.get("root"),
        "architectures": ([component_architectures.get("root")]
                          if component_architectures.get("root") else None),
    }
    # A class overlay must be derived from THIS slot's checkpoint values.  The
    # old identity-only hydration (``{model_type, architectures}``) recreated
    # stock dimensions for embedded/custom encoders even after the root path
    # had been fixed.  When the caller does not possess the slot document, no
    # overlay is safer than a fabricated one; source/address resolution remains
    # available through the pre-resolved bundle either way.
    # Reuse the exact class overlay resolved from the ORIGINAL root document.
    # A name-blind replay deliberately scrubs the child ``model_type``; asking
    # the scrubbed child to resolve its config class again would lose valid
    # class-default operands (for example T5 ``d_kv``) and make architecture
    # depend on an identity value whose address was already resolved.  The
    # exact DocumentBinding is the join authority—never a loose path or the
    # slot spelling alone.  It self-verifies object identity, and the final
    # address segment must be this exact source-bundle component.  A
    # standalone/direct caller without that bound root-path evidence retains
    # the ordinary local preparation path.
    _document_path: tuple[str, ...] = ()
    if binding is not None:
        from .document import DocumentBinding
        if not isinstance(binding, DocumentBinding):
            raise TypeError("slot context binding must be a DocumentBinding")
        if binding.prepared.document is not document:
            raise ValueError(
                "slot context binding does not describe the supplied document")
        _document_path = tuple(binding.document_path)
        if not _document_path or _document_path[-1] != slot:
            raise ValueError(
                "slot context binding path does not end at the requested slot")
    _root_defaults = (
        getattr(root_context, "class_defaults_by_path", None) or {})
    _slot_defaults = (
        dict(_root_defaults[_document_path])
        if _document_path and _document_path in _root_defaults
        else _installed_config_defaults(document))
    return ParseContext(
        source_bundle=sub_bundle, source=root_context.source,
        # Ownership namespace: this slot's facts are owned under
        # root.<slot> in the pipeline's global tree (composes for nesting),
        # even though its SOURCE subtree is re-rooted for resolution above.
        component_namespace=(namespace or (
            f"{getattr(root_context, 'component_namespace', 'root')}.{slot}")),
        class_defaults=_slot_defaults,
        class_defaults_by_path=(
            {(): _slot_defaults} if isinstance(_slot_defaults, dict) else {}),
        declared_decoderness=declared_decoderness(_slot_identity),
    )


# The ambient parse context: set by orchestrators (config_to_ir, the
# name-blind harness) so deeply-embedded slot walks can derive their
# sub-contexts from the ENCLOSING resolution without threading a
# parameter through every modality builder signature.
from contextvars import ContextVar
active_parse_context: ContextVar = ContextVar(
    "model_unfolder_active_parse_context", default=None)
