"""Source discovery for static Hugging Face modeling-code inspection."""
from __future__ import annotations

import dataclasses
import functools
import os
import re
from pathlib import Path
from typing import Any

from physics.result_cache import cache_source_bundle
from .models import SourceBundle, SourceImportRoot


@cache_source_bundle
def resolve_source_files(target: Any, *, source: str = "local", token: Any = None) -> SourceBundle:
    """Resolve Python modeling files without executing model code.

    Parameters
    ----------
    target
        Config dict/object, model id, or local file/directory path.
    source
        ``"local"`` uses the installed ``transformers`` package, ``"path"``
        treats ``target`` as a file/directory, ``"hub"`` downloads only source
        files from the Hub, and ``"auto"`` tries local before Hub.
    """
    if source not in {"local", "path", "hub", "auto"}:
        raise ValueError("source must be one of: local, path, hub, auto")

    path_bundle = _path_bundle(target)
    if path_bundle is not None:
        return path_bundle

    if source in {"local", "auto"}:
        local = _installed_transformers_bundle(target)
        if local.files:
            return local
        # Diffusion DiT/UNet code lives in `diffusers`, not `transformers` — resolve
        # the modeling file by the config's `_class_name` (FluxTransformer2DModel, …).
        diff = _installed_diffusers_bundle(target)
        if diff is not None and diff.files:
            return diff
        if source == "local":
            # Supporting-tower classes that ship INSIDE diffusers but outside
            # models/ (Kolors' ChatGLMModel in pipelines/kolors/text_encoder.py)
            # — found by the config's own ``architectures`` declaration.
            arch_bundle = _installed_diffusers_arch_bundle(target)
            if arch_bundle is not None and arch_bundle.files:
                return arch_bundle
            # REMOTE-CODE repos carry their own modeling source, and the config
            # DECLARES that fact (auto_map).  That source is evidence exactly
            # like an in-tree file — fetch the repo's .py files (cached by the
            # hub client; offline after first resolve).  Without this, every
            # trust_remote_code family (ChatGLM, ...) parsed evidence-blind:
            # no RoPE box, split-drawn fused FFNs, pale encoder towers.
            if _declares_remote_code(target):
                try:
                    hub = _hub_bundle(target, token=token)
                except Exception as exc:      # offline / gated — honest fallback
                    hub = SourceBundle(
                        source="hub", model_type=_model_type(target),
                        architecture=_architecture(target), model_id=_model_id(target),
                        warnings=(f"remote-code source fetch failed: {exc}",))
                if hub.files:
                    return hub
                if hub.warnings:
                    # A fileless hub bundle still knows the TRUE refusal cause
                    # ("fetch failed: …" / "needs a model id") — surface it
                    # beside the local fallback's warning instead of letting
                    # the generic "no installed source" line mask it.
                    fallback = diff if (diff is not None and diff.warnings) else local
                    return dataclasses.replace(
                        fallback,
                        warnings=tuple(fallback.warnings) + tuple(hub.warnings),
                    )
            return diff if (diff is not None and diff.warnings) else local

    if source in {"hub", "auto"}:
        return _hub_bundle(target, token=token)

    return SourceBundle(
        source=source,
        model_type=_model_type(target),
        architecture=_architecture(target),
        model_id=_model_id(target),
        warnings=("No source files found.",),
    )


def _path_bundle(target: Any) -> SourceBundle | None:
    if not isinstance(target, (str, os.PathLike)):
        return None
    path = Path(target)
    if not path.exists():
        return None
    if path.is_file():
        files = (str(path),) if path.suffix == ".py" else ()
    else:
        files = tuple(str(p) for p in sorted(path.rglob("*.py")) if p.is_file())
    return SourceBundle(
        source="path", files=files, model_id=str(path),
        warnings=() if files else ("No Python files found.",),
        component_files={"root": files} if files else {},
    )


def _installed_transformers_bundle(target: Any) -> SourceBundle:
    model_type = _model_type(target)
    architecture = _architecture(target) or _string_value(target, "_class_name")
    model_id = _model_id(target)

    try:
        import transformers
    except ImportError:
        return SourceBundle(
            source="local",
            model_type=model_type,
            architecture=architecture,
            model_id=model_id,
            warnings=("transformers is not installed; cannot inspect local modeling source.",),
        )

    package_file = getattr(transformers, "__file__", None)
    if not package_file:
        return SourceBundle(
            source="local",
            model_type=model_type,
            architecture=architecture,
            model_id=model_id,
            warnings=(
                "transformers has no filesystem package path; cannot inspect "
                "local modeling source.",
            ),
        )
    models_root = Path(package_file).resolve().parent / "models"
    if not model_type:
        # Exact architecture/class identity is a legitimate source ADDRESS. It
        # does not assert a structural fact: find the installed file that
        # literally defines that class, then let AST evidence decide structure.
        # This covers component configs that omit model_type but retain
        # ``architectures``/``_class_name`` (common in frozen pipeline fixtures).
        file = _transformers_file_for_class(str(models_root), architecture or "")
        if file:
            files = (file,)
            supporting = _transformers_supporting_files(Path(file).parent)
            return SourceBundle(
                source="local", files=files, architecture=architecture,
                model_id=model_id, component_files={"root": files},
                supporting_files={"root": supporting} if supporting else {},
                component_architectures={"root": architecture} if architecture else {},
            )
        return SourceBundle(
            source="local", architecture=architecture, model_id=model_id,
            warnings=("Could not infer model_type or exact installed model class for source lookup.",),
        )
    files: list[str] = []
    warnings: list[str] = []
    seen_files: set[str] = set()
    component_files: dict[str, tuple[str, ...]] = {}
    supporting_files: dict[str, tuple[str, ...]] = {}
    component_model_types: dict[str, str] = {}
    component_architectures: dict[str, str] = {}

    # Composite HF configs delegate real computation to nested component configs:
    # ``AutoModel.from_config(config.vision_config)`` and a separate text model are
    # common.  Looking up only the root wrapper makes the oracle appear present
    # while omitting the classes that actually perform the work.  Walk every
    # nested ``*_config`` structurally and gather its installed modeling source.
    for component, cfg in _component_configs(target):
        component_type = _own_model_type(cfg)
        if component == "root" and not component_type:
            component_type = model_type
        if not component_type:
            warnings.append(f"Could not infer model_type for Transformers component {component!r}.")
            continue
        component_model_types[component] = component_type
        component_architecture = (
            (_own_architecture(cfg) or _auto_model_architecture(component_type))
            if component == "root"
            else (_auto_model_architecture(component_type) or _own_architecture(cfg))
        )
        family_dir = _transformers_family_dir(models_root, component_type)
        if family_dir is None:
            warnings.append(
                f"No installed Transformers source directory for component {component!r} "
                f"(model_type={component_type!r})."
            )
            continue
        modeling_files = tuple(sorted((models_root / family_dir).glob("modeling*.py")))
        if not component_architecture:
            # component-only model_type: the source's config_class declaration
            component_architecture = _architecture_from_config_class(
                modeling_files, component_type)
        if component_architecture:
            component_architectures[component] = component_architecture
        if not modeling_files:
            warnings.append(
                f"No modeling*.py files found for component {component!r} "
                f"(model_type={component_type!r})."
            )
        component_paths = tuple(str(path) for path in modeling_files)
        if component_paths:
            component_files[component] = component_paths
        support_paths = _transformers_supporting_files(models_root / family_dir)
        if support_paths:
            supporting_files[component] = support_paths
        for path in component_paths:
            value = path
            if value not in seen_files:
                seen_files.add(value)
                files.append(value)

    if not files and architecture:
        # A PRESENT-but-unregistered model_type (the rebrand pattern:
        # ``kimi_k2`` running the installed ``DeepseekV3ForCausalLM``) must
        # fall through to the same class-address lookup an ABSENT model_type
        # already gets above — unknown is not evidence of absence. The class
        # name only locates the file; AST evidence still decides structure.
        class_file = _transformers_file_for_class(str(models_root), architecture)
        if class_file:
            class_files = (class_file,)
            supporting = _transformers_supporting_files(Path(class_file).parent)
            return SourceBundle(
                source="local",
                files=class_files,
                model_type=model_type,
                architecture=architecture,
                model_id=model_id,
                warnings=tuple(warnings),
                component_files={"root": class_files},
                supporting_files={"root": supporting} if supporting else {},
                component_architectures={"root": architecture},
            )

    return SourceBundle(
        source="local",
        files=tuple(files),
        model_type=model_type,
        architecture=architecture,
        model_id=model_id,
        warnings=tuple(warnings) if warnings else (() if files else (
            f"No modeling*.py files found for model_type={model_type!r}.",
        )),
        component_files=component_files,
        supporting_files=supporting_files,
        component_model_types=component_model_types,
        component_architectures=component_architectures,
    )


def _transformers_supporting_files(family_dir: Path) -> tuple[str, ...]:
    """Exact support sources, kept off legacy modeling-file surfaces.

    Configuration sources are always part of the component's address closure.
    A framework source is added only when this exact installed modeling source
    imports its closed interface.  This is source-address plumbing, not a
    mechanism claim: readers still have to resolve the import, registry entry,
    selected callable and its dataflow before any architecture fact exists.
    """
    paths = [path for path in sorted(family_dir.glob("configuration*.py"))
             if path.is_file()]
    framework_rope = family_dir.parent.parent / "modeling_rope_utils.py"
    if framework_rope.is_file():
        imported = False
        for modeling in sorted(family_dir.glob("modeling*.py")):
            try:
                source = modeling.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if re.search(
                    r"^from\s+\.{2,}modeling_rope_utils\s+import\s+",
                    source, re.M):
                imported = True
                break
        if imported:
            paths.append(framework_rope)
    framework_activations = family_dir.parent.parent / "activations.py"
    if framework_activations.is_file():
        for modeling in sorted(family_dir.glob("modeling*.py")):
            try:
                source = modeling.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if re.search(
                    r"^from\s+(?:\.{2,}activations|transformers\.activations)\s+import\s+.*\b(?:ACT2FN|get_activation)\b",
                    source, re.M):
                # Address closure only: the reader must prove the exact key,
                # registry instantiation protocol and selected callable body.
                paths.append(framework_activations)
                break
    framework_config = family_dir.parent.parent / "configuration_utils.py"
    if framework_config.is_file():
        imported = False
        for configuration in sorted(family_dir.glob("configuration*.py")):
            try:
                source = configuration.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if re.search(
                    r"^from\s+\.{2,}configuration_utils\s+import\s+",
                    source, re.M):
                imported = True
                break
        if imported:
            paths.append(framework_config)
    framework_auto = family_dir.parent / "auto" / "modeling_auto.py"
    if framework_auto.is_file():
        imported = False
        for modeling in sorted(family_dir.glob("modeling*.py")):
            try:
                source = modeling.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if re.search(
                    r"^\s*from\s+\.{2,}auto(?:\.modeling_auto)?\s+import\s+AutoModel",
                    source, re.M):
                imported = True
                break
        if imported:
            paths.append(framework_auto)
    return tuple(str(path) for path in dict.fromkeys(paths))


@functools.lru_cache(maxsize=128)
def _transformers_file_for_class(models_root: str, class_name: str) -> str | None:
    if not class_name:
        return None
    pattern = re.compile(rf"^class\s+{re.escape(class_name)}\b", re.M)
    matches: list[str] = []
    for path in sorted(Path(models_root).rglob("modeling*.py")):
        try:
            source = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if pattern.search(source):
            matches.append(str(path))
    return matches[0] if len(matches) == 1 else None


def _component_configs(target: Any):
    """Yield ``(qualified_path, config)`` for root and nested component configs.

    Hugging Face's composite-config contract has TWO spellings, and both are
    followed here without mistaking arbitrary dictionaries (rope scaling,
    quantization settings, generation options) for model components:

    * fields named ``*_config`` — traversed unconditionally (the suffix IS the
      declaration), and
    * bare slot names from the ``composite_slots`` vocabulary (MusicGen's
      ``text_encoder``/``audio_encoder``/``decoder``, EncoderDecoderModel's
      ``encoder``/``decoder``) — traversed only when the child itself declares
      a ``model_type`` (the evidence, since the name alone is ambiguous).

    Object identity guards recursive/shared config objects.
    """
    from ..everchanging import load_composite_slots
    slot_names = set((load_composite_slots().get("slots") or {}))
    seen: set[int] = set()

    def walk(value: Any, path: str):
        if value is None or isinstance(value, (str, bytes, int, float, bool)):
            return
        identity = id(value)
        if identity in seen:
            return
        seen.add(identity)
        yield path, value
        items = value.items() if isinstance(value, dict) else vars(value).items() \
            if hasattr(value, "__dict__") else ()
        for name, child in items:
            if child is None:
                continue
            if str(name).endswith("_config") or (
                str(name) in slot_names and _own_model_type(child)
            ):
                child_path = str(name) if path == "root" else f"{path}.{name}"
                yield from walk(child, child_path)

    yield from walk(target, "root")


def _own_model_type(target: Any) -> str | None:
    """Return only this config object's model type, never a nested fallback."""
    value = _get_value(target, "model_type")
    return str(value) if value else None


def _own_architecture(target: Any) -> str | None:
    arches = _get_value(target, "architectures")
    if arches:
        try:
            return str(arches[0])
        except (TypeError, IndexError):
            return str(arches)
    return None


def _auto_model_architecture(model_type: str) -> str | None:
    """The installed Transformers AutoModel mapping, read without model import.

    Composite component configs commonly omit ``architectures``.  The static
    mapping is the authoritative config-type -> concrete model class relation
    used by ``AutoModel.from_config`` itself, and lets conformance start from the
    exact delegated model instead of every class sharing its source file.
    """
    try:
        from transformers.models.auto.modeling_auto import MODEL_MAPPING_NAMES
    except (ImportError, AttributeError):
        return None
    value = MODEL_MAPPING_NAMES.get(model_type)
    if isinstance(value, (tuple, list)):
        value = value[0] if value else None
    return str(value) if value else None


def _transformers_family_dir(models_root: Path, model_type: str) -> str | None:
    """Resolve a config type through installed Transformers metadata.

    ``model_type_to_module_name`` is the same registry-backed normalization the
    library uses to import its config module. We accept its answer only when the
    installed directory exists. There is no project-owned type/family table and
    no suffix guessing; an unknown type remains unresolved and may still use an
    exact declared-class lookup later in the source ladder.
    """
    try:
        from transformers.models.auto.configuration_auto import (
            model_type_to_module_name,
        )
        declared_dir = model_type_to_module_name(model_type)
    except (ImportError, AttributeError, KeyError, TypeError, ValueError):
        declared_dir = None
    if declared_dir and (models_root / declared_dir).exists():
        return str(declared_dir)
    return _direct_transformers_family_dir(models_root, model_type)


from functools import lru_cache


@lru_cache(maxsize=64)
def _installed_diffusers_model_class_file(arch: str) -> str | None:
    """Resolve one declared class to its exact installed Diffusers model file.

    This is address evidence, not a class-name classifier: every spelling is
    treated identically and succeeds only when an exact class definition exists
    under the installed library's ``models/`` tree.
    """
    if not isinstance(arch, str) or not arch:
        return None
    # Locating a top-level installed package does not execute its initializer.
    # The original class-definition scan below remains the address authority.
    import importlib.util
    import sys
    try:
        loaded = sys.modules.get("diffusers")
        package_file = getattr(loaded, "__file__", None) if loaded is not None else None
        if loaded is None:
            spec = importlib.util.find_spec("diffusers")
            package_file = spec.origin if spec is not None else None
    except (ImportError, ValueError):
        return None
    if not package_file:
        return None
    models_root = Path(package_file).resolve().parent / "models"
    if not models_root.exists():
        return None
    pat = re.compile(rf"^class {re.escape(arch)}\b", re.M)
    for path in sorted(models_root.rglob("*.py")):
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if pat.search(text):
            return str(path)
    return None


@lru_cache(maxsize=64)
def _diffusers_class_file(arch: str) -> str | None:
    """Path of the installed diffusers file defining ``class <arch>`` — searched
    across models/ AND pipelines/ (supporting encoders live under pipelines)."""
    try:
        import diffusers
    except (ImportError, ValueError):
        # Test/frozen environments may provide a deliberately minimal
        # ``transformers`` module with no import spec.  Diffusers' optional
        # dependency probe then raises ValueError from find_spec(); that means
        # the diffusers address channel is unavailable, not that parsing the
        # already-loaded transformer config should fail.
        return None
    model_file = _installed_diffusers_model_class_file(arch)
    if model_file is not None:
        return model_file
    root = Path(diffusers.__file__).resolve().parent
    pat = re.compile(rf"^class {re.escape(arch)}\b", re.M)
    for sub in ("pipelines",):
        base = root / sub
        if not base.exists():
            continue
        for f in sorted(base.rglob("*.py")):
            try:
                text = f.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if pat.search(text):
                return str(f)
    return None


def _installed_diffusers_arch_bundle(target: Any) -> SourceBundle | None:
    """Resolve a component by its DECLARED ``architectures`` inside the installed
    diffusers tree — the in-tree twin of the remote-code rail for supporting
    towers diffusers vendored (Kolors ChatGLMModel)."""
    arch = _architecture(target)
    if not arch:
        return None
    path = _diffusers_class_file(arch)
    if path is None:
        return None
    import_root = _source_import_root(path, "diffusers")
    return SourceBundle(
        source="local",
        files=(path,),
        model_type=_model_type(target),
        architecture=arch,
        model_id=_model_id(target),
        component_files={"root": (path,)},
        import_roots={"root": (import_root,)} if import_root else {},
        component_architectures={"root": arch},
    )


def _source_import_root(path: str, package: str) -> SourceImportRoot | None:
    """Return the exact installed package directory containing ``path``.

    Package identity is source-address metadata.  This helper never searches
    for a model/class and never infers a mechanism; it merely closes a path
    already selected by the source resolver against the named installed
    package directory.
    """
    resolved = Path(path).resolve()
    matches = [index for index, part in enumerate(resolved.parts)
               if part == package]
    if not matches:
        return None
    root = Path(*resolved.parts[:matches[-1] + 1])
    try:
        resolved.relative_to(root)
    except ValueError:
        return None
    return SourceImportRoot(package, str(root))


def _installed_diffusers_bundle(target: Any) -> SourceBundle | None:
    """Resolve a diffusion model's modeling file in the installed ``diffusers``.

    Diffusion configs name their class in ``_class_name`` (e.g.
    ``FluxTransformer2DModel``); the file that defines it also defines the
    transformer block, whose norm/attention instantiations are what we read.
    Returns ``None`` when the target isn't a diffusion class or diffusers is
    absent (so the caller falls back to the transformers bundle)."""
    cls = _string_value(target, "_class_name")
    class_file = _installed_diffusers_model_class_file(cls)
    if class_file is None:
        return None
    model_id = _model_id(target)
    for f in (Path(class_file),):
        try:
            text = f.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if re.search(rf"^class {re.escape(cls)}\b", text, re.M):
            component_files = {"root": (str(f),)}
            supporting_files: dict[str, tuple[str, ...]] = {}
            import_roots: dict[str, tuple[SourceImportRoot, ...]] = {}
            root_import = _source_import_root(str(f), "diffusers")
            if root_import is not None:
                import_roots["root"] = (root_import,)
            component_model_types: dict = {}
            component_architectures = {"root": cls}
            files = [str(f)]
            # A pipeline's fetched text-encoder configs (text_encoder /
            # text_encoder_2 / …) are real delegated TRANSFORMERS components.
            # Each goes through the SAME composite resolver a standalone
            # transformers config gets — so a wrapper encoder (Mistral3, a
            # Qwen-VL pressed into prompt duty) also qualifies its own nested
            # text/vision components, prefixed under the pipeline slot
            # (``text_encoder.text_config`` → modeling_mistral.py).  Without
            # this an encoder drill is either silently skipped by nested
            # conformance or diffed against the denoiser's own forward().
            pipeline_components: list[str] = []
            for enc_name, enc_cfg, _enc_type in _pipeline_text_encoder_components(target):
                pipeline_components.append(enc_name)
                enc_bundle = _installed_transformers_bundle(enc_cfg)
                for sub_key, sub_files in (enc_bundle.component_files or {}).items():
                    key = enc_name if sub_key == "root" else f"{enc_name}.{sub_key}"
                    component_files[key] = tuple(sub_files)
                    files.extend(p for p in sub_files if p not in files)
                for sub_key, sub_files in (
                        enc_bundle.supporting_files or {}).items():
                    key = enc_name if sub_key == "root" else f"{enc_name}.{sub_key}"
                    supporting_files[key] = tuple(sub_files)
                for sub_key, value in (enc_bundle.component_model_types or {}).items():
                    key = enc_name if sub_key == "root" else f"{enc_name}.{sub_key}"
                    component_model_types[key] = value
                for sub_key, value in (enc_bundle.component_architectures or {}).items():
                    key = enc_name if sub_key == "root" else f"{enc_name}.{sub_key}"
                    component_architectures[key] = value
            companion_components: list[str] = []
            for slot, _companion_cfg, companion_arch in \
                    _pipeline_companion_denoiser_components(target):
                companion_path = _diffusers_class_file(companion_arch)
                if companion_path is None:
                    continue
                companion_components.append(slot)
                component_files[slot] = (companion_path,)
                component_architectures[slot] = companion_arch
                if companion_path not in files:
                    files.append(companion_path)
                companion_root = _source_import_root(
                    companion_path, "diffusers")
                if companion_root is not None:
                    import_roots[slot] = (companion_root,)
            return SourceBundle(source="local", files=tuple(files),
                                architecture=cls, model_id=model_id,
                                component_files=component_files,
                                supporting_files=supporting_files,
                                import_roots=import_roots,
                                component_model_types=component_model_types,
                                component_architectures=component_architectures,
                                pipeline_components=tuple(pipeline_components),
                                companion_components=tuple(companion_components))
    return SourceBundle(
        source="local", architecture=cls, model_id=model_id,
        warnings=(f"No installed diffusers modeling file defines {cls!r}.",),
    )


def _pipeline_text_encoder_components(target: Any):
    """Yield ``(component_name, config, model_type)`` for fetched pipeline
    text-encoder configs.  The list-of-names form (configs not fetched) has
    nothing to qualify and yields nothing."""
    raw = _get_value(target, "_text_encoder_configs")
    if not isinstance(raw, dict):
        return
    for name, cfg in raw.items():
        if not isinstance(cfg, dict):
            continue
        # ANY declared address qualifies the slot — model_type, architectures,
        # or the diffusers-style ``_class_name`` (a minimal frozen sub-config
        # may carry only the class declaration; the composite resolver handles
        # every one of these forms).
        model_type = _own_model_type(cfg)
        if model_type or _architecture(cfg) or _string_value(cfg, "_class_name"):
            yield str(name), cfg, model_type or ""


def _pipeline_companion_denoiser_components(target: Any):
    """Yield exact loader-established companion denoiser addresses only."""
    raw = _get_value(target, "_companion_denoiser_configs")
    if not isinstance(raw, dict):
        return
    for slot, cfg in sorted(raw.items()):
        if not isinstance(slot, str) or not slot or not isinstance(cfg, dict):
            continue
        architecture = _architecture(cfg) or _string_value(cfg, "_class_name")
        if architecture:
            yield slot, cfg, architecture


def _direct_transformers_family_dir(models_root: Path, model_type: str) -> str | None:
    """Conservative fallback for library versions without registry metadata."""
    normalized = model_type.replace("-", "_")
    for candidate in dict.fromkeys((model_type, normalized)):
        if candidate and (models_root / candidate).exists():
            return candidate
    return None


def _declares_remote_code(target: Any) -> bool:
    """True when the config itself declares that its modeling code lives in the
    repo (``auto_map`` — the trust_remote_code marker).  A config-declared fact,
    never a name heuristic; nested component configs count (a pipeline whose
    text encoder is remote-code)."""
    if _get_value(target, "auto_map"):
        return True
    for key in ("text_config", "_text_encoder_configs"):
        nested = _get_value(target, key)
        if isinstance(nested, dict):
            if nested.get("auto_map"):
                return True
            if any(isinstance(v, dict) and v.get("auto_map") for v in nested.values()):
                return True
    return False


def _architecture_from_config_class(modeling_files, component_type: str) -> str | None:
    """Component architecture read from the SOURCE's own ownership declaration.

    AutoModel registers only composite entries, so a component-only model_type
    (``qwen2_5_omni_text``) has no MODEL_MAPPING row.  The modeling file still
    states which class consumes the component's config: ``config_class =
    Qwen2_5OmniTextConfig`` on the class body.  Among declarers, the one some
    other class CONSTRUCTS is the concrete model (bases are only inherited) —
    a structural pick, never a name pattern."""
    try:
        from transformers.models.auto.configuration_auto import CONFIG_MAPPING_NAMES
    except ImportError:
        return None
    config_cls = CONFIG_MAPPING_NAMES.get(component_type)
    if not config_cls:
        return None
    import ast
    owners: list[str] = []
    constructed: set[str] = set()
    for path in modeling_files:
        try:
            tree = ast.parse(Path(path).read_text(encoding="utf-8"))
        except (OSError, SyntaxError, UnicodeDecodeError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                name = getattr(node.func, "id", None)
                if name:
                    constructed.add(name)
            if not isinstance(node, ast.ClassDef):
                continue
            for st in node.body:
                # legacy spelling: config_class = XConfig
                if (isinstance(st, ast.Assign) and len(st.targets) == 1
                        and isinstance(st.targets[0], ast.Name)
                        and st.targets[0].id == "config_class"
                        and isinstance(st.value, ast.Name)
                        and st.value.id == config_cls):
                    owners.append(node.name)
                # modern spelling: a class-body annotation `config: XConfig`
                if (isinstance(st, ast.AnnAssign)
                        and isinstance(st.target, ast.Name)
                        and st.target.id in ("config", "config_class")
                        and isinstance(st.annotation, ast.Name)
                        and st.annotation.id == config_cls):
                    owners.append(node.name)
    live = [o for o in owners if o in constructed]
    if len(live) == 1:
        return live[0]
    return owners[0] if len(owners) == 1 else None


def _hub_bundle(target: Any, *, token: Any = None) -> SourceBundle:
    model_id = _model_id(target)
    if not model_id:
        return SourceBundle(source="hub", warnings=("Hub source lookup needs a model id.",))
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        return SourceBundle(
            source="hub",
            model_type=_model_type(target),
            architecture=_architecture(target),
            model_id=model_id,
            warnings=("huggingface_hub is not installed; cannot download source files.",),
        )

    kwargs = {
        "repo_id": model_id,
        "allow_patterns": ["*.py", "**/*.py", "config.json"],
        "ignore_patterns": ["*.bin", "*.safetensors", "*.pt", "*.gguf", "*.onnx"],
    }
    clean_token = _clean_token(token)
    if clean_token is not None:
        kwargs["token"] = clean_token
    # Cache-first: the hub client caches every snapshot, so an offline/gated
    # session with the repo already on disk must still get its evidence. Fall
    # to the network only when the cached snapshot carries no .py files (a
    # config-only cache from an earlier hf_hub_download is common).
    files: tuple[str, ...] = ()
    try:
        root = Path(snapshot_download(**kwargs, local_files_only=True))
        files = tuple(str(p) for p in sorted(root.rglob("*.py")) if p.is_file())
    except Exception:
        files = ()
    if not files:
        root = Path(snapshot_download(**kwargs))
        files = tuple(str(p) for p in sorted(root.rglob("*.py")) if p.is_file())
    return SourceBundle(
        source="hub",
        files=files,
        model_type=_model_type(target),
        architecture=_architecture(target),
        model_id=model_id,
        warnings=() if files else (f"No Python source files found in Hub repo {model_id!r}.",),
        component_files={"root": files} if files else {},
    )


def _model_type(target: Any) -> str | None:
    value = _get_value(target, "model_type")
    if value:
        return str(value)
    text_config = _get_value(target, "text_config")
    if text_config is not None:
        value = _get_value(text_config, "model_type")
        if value:
            return str(value)
    return None


def _architecture(target: Any) -> str | None:
    arches = _get_value(target, "architectures")
    if arches:
        try:
            return str(arches[0])
        except (TypeError, IndexError):
            return str(arches)
    return None


def _model_id(target: Any) -> str | None:
    if isinstance(target, str) and not Path(target).exists():
        return target
    return (
        # the loader's own provenance stamp — authoritative over _name_or_path,
        # which exporters bake as a LOCAL path ("models/kolors")
        _string_value(target, "_repo_id")
        or _string_value(target, "_name_or_path")
        or _string_value(target, "name_or_path")
        or _string_value(target, "model_id")
        or _string_value(target, "repo_id")
    )


def _get_value(target: Any, name: str, default=None):
    if isinstance(target, dict):
        return target.get(name, default)
    return getattr(target, name, default)


def _string_value(target: Any, name: str) -> str | None:
    value = _get_value(target, name)
    return str(value) if value else None


def _clean_token(token: Any):
    if isinstance(token, str):
        token = token.strip()
        return token or None
    return token
