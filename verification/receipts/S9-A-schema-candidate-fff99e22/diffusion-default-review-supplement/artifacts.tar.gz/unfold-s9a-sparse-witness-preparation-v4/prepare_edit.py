from pathlib import Path
import hashlib, ast, json
old=Path('/private/tmp/unfold-s9a-sparse-witness-preparation/run_sparse.py')
assert hashlib.sha256(old.read_bytes()).hexdigest()=='076d0640dc56ed4ec4cea955dc2a1028240101d62137d9a5607379827b40c2b9'
s=old.read_text()
a=s.index('def proof_operands(');b=s.index('\ndef field_rules',a)
s=s[:a]+'''def proof_operands(fact, root, reader_operand, ConfigValueClaimProof, ReaderProjectionClaimProof):
    """Observe finite original proof operands, including non-checkpoint defaults.

    Uses the original witness's existing operand derivation; never interprets
    arbitrary witness fields or calls a new source reader/model/render pass.
    Unsupported proof types retain only their actual checkpoint projection.
    """
    proof = fact.claim_evidence
    if proof is None or getattr(proof, 'prepared_document', None) is not root:
        return []
    observed = []
    if type(proof) is ConfigValueClaimProof:
        paths = [tuple(event.config_path.split('.')) for event in proof.events
                 if event.component == 'root' and not event.document_path]
    elif type(proof) is ReaderProjectionClaimProof:
        from model_unfolder.evidence.attention import (
            AttentionMechanismClaimWitness, attention_claim_operands)
        from model_unfolder.evidence.attention_geometry import AttentionGeometryClaimWitness
        from model_unfolder.evidence.class_default_value import ModelHiddenSizeDefaultClaimWitness
        projection = proof.projection()  # checks exact original invocation/document binding
        witness = proof.reader_result.claim_witness
        if type(witness) is AttentionMechanismClaimWitness and fact.key in {'mechanism', 'head_geometry'}:
            _bound, observed = attention_claim_operands(witness.binding, root)
            paths = []
        elif type(witness) is AttentionGeometryClaimWitness:
            _bound, observed = attention_claim_operands(witness.mechanism, root, witness.geometry)
            paths = []
        elif type(witness) is ModelHiddenSizeDefaultClaimWitness:
            require(witness.document is root, 'scalar default proof has another prepared document')
            declaration = witness.default.declaration
            operand = reader_operand(root, declaration.path)
            require(operand.source_kind == 'class_default' and operand.checkpoint_path is None
                    and canonical(operand.value) == canonical(declaration.value)
                    and canonical(projection.value) == canonical(declaration.value),
                    'original scalar default declaration differs from its actual operand')
            observed, paths = [operand], []
        else:
            paths = list(projection.config_paths)
    else:
        return []
    result = [plain(dataclasses.asdict(value)) for value in observed]
    for path in paths:
        value = reader_operand(root, path)
        record = plain(dataclasses.asdict(value))
        if record not in result:
            result.append(record)
    return result


def proof_scope(fact, root, ReaderProjectionClaimProof):
    proof = fact.claim_evidence
    if proof is None or getattr(proof, 'prepared_document', None) is not root:
        return {'root_bound': False, 'qualification': 'not_proved'}
    scope = {'root_bound': True, 'qualification': 'validated_original_proof',
             'proof_kind': proof.proof_kind}
    if type(proof) is ReaderProjectionClaimProof:
        proof.projection()
        witness = proof.reader_result.claim_witness
        scope['witness_type'] = type(witness).__module__ + '.' + type(witness).__qualname__
        scope['required_spans'] = [span_record(span) for span in proof._required_spans]
    return scope


def exact_default_source_transition(old, new, old_scope, new_scope, linked):
    """The one finite config-value -> source-default VALUE proof migration."""
    symbol = 'model_unfolder.evidence.class_default_value.model_hidden_size_class_default'
    old_proof, new_proof = old['claim_proof'], new['claim_proof']
    if not linked or not old_scope['root_bound'] or not new_scope['root_bound'] \\
            or new_scope.get('witness_type') != 'model_unfolder.evidence.class_default_value.ModelHiddenSizeDefaultClaimWitness' \\
            or old['claim_kind'] != new['claim_kind'] or new['claim_kind'] != 'value' \\
            or not old_proof or not new_proof or old_proof['proof_kind'] != 'config_resolution' \\
            or new_proof['proof_kind'] != 'retained_reader_projection' \\
            or old['source_spans'] or new['claim_readers'] != [symbol] \\
            or new_proof['reader_symbols'] != [symbol]:
        return False
    required = {(span['component'] or 'root', span['file'], span['line'])
                for span in new_scope['required_spans']}
    cited = {(span['component'], span['file'], span['line']) for span in new['source_spans']}
    return bool(required) and cited == required and all(
        span['class_name'] is None and span['method'] is None for span in new['source_spans'])


def diagnose_deltas(rows):
    """Name metadata debts without admitting a whole branch or masking changes."""
    branches = {
        'config_access': 'config access accounting changed; exact event/default provenance comparison remains required',
        'config_audit': 'derived config audit changed; obligations are not discarded',
        'config_consumed': 'checkpoint consumption census changed; defaults are not checkpoint occurrences',
        'fact_provenance': 'fact authority metadata changed; only exact per-fact rules are admitted',
        'render': 'presentation metadata/addressing changed; drawing equality is checked separately',
    }
    for delta in rows:
        path = delta['path']
        branch = next((part for part in path[:3] if part in branches), None)
        delta['diagnostic_cause'] = (delta['cause'] if delta['cause'] != 'UNEXPLAINED' else
            branches.get(branch, 'unexplained value/structure or unsupported metadata delta'))
        delta['admitted'] = delta['cause'] != 'UNEXPLAINED'
    return rows

''' +s[b:]
s=s.replace("                        write(folder / 'original-proof-operands.json', operands)","""                        write(folder / 'original-proof-operands.json', operands)
                        proof_scopes = {key: proof_scope(fact, root_document, ReaderProjectionClaimProof)
                                        for key, fact in facts.items()}
                        write(folder / 'original-proof-scopes.json', proof_scopes)""")
s=s.replace("'operands': operands, 'root_seal': root_seal,","'operands': operands, 'proof_scopes': proof_scopes, 'root_seal': root_seal,")
s=s.replace("root_bound = bool(a['operands'][key] and b['operands'][key])","root_bound = a['proof_scopes'][key]['root_bound'] and b['proof_scopes'][key]['root_bound']")
needle="""                    label = 'exact root proof/default operand binding: ' + key"""
insert="""                    if same and status_ok and linked and proof_ok:
                        omitted_paths = {binding['operand'] for binding in linked}
                        if new['config_paths'] == [path for path in old['config_paths'] if path not in omitted_paths]:
                            allowed.update(tuple(delta['path']) for delta in changes(old, new)
                                           if delta['path'][:1] == ['config_paths'])
                        if exact_default_source_transition(old, new, a['proof_scopes'][key], b['proof_scopes'][key], linked):
                            # Original proof validation and exact source-span equality bind this
                            # finite authority transition. Other source/reader/index deltas remain red.
                            fields = {'source_spans', 'claim_readers', 'claim_proof'}
                            allowed.update(tuple(delta['path']) for delta in changes(old, new)
                                           if delta['path'] and delta['path'][0] in fields)
"""+needle
assert needle in s;s=s.replace(needle,insert)
needle="""                    if ('status',) in allowed:
                        row_allowed.add(('status',))"""
replacement=needle+"""
                    if exact_default_source_transition(old, new, a['proof_scopes'][key], b['proof_scopes'][key], linked):
                        if old_row['source'] in old['claim_readers'] and new_row['source'] in new['claim_readers']:
                            row_allowed.add(('source',))"""
s=s.replace(needle,replacement)
s=s.replace("deltas = changes(a['pre'], b['pre'], replacements=replacements)","deltas = diagnose_deltas(changes(a['pre'], b['pre'], replacements=replacements))")
s=s.replace("fact_deltas = changes(a['facts'], b['facts'], replacements=replacements)","fact_deltas = diagnose_deltas(changes(a['facts'], b['facts'], replacements=replacements))")
s=s.replace("post_deltas = changes(a['post'], b['post'], replacements=replacements)","post_deltas = diagnose_deltas(changes(a['post'], b['post'], replacements=replacements))")
needle="""                row['comparisons'] = {'every_omission_has_actual_default_premise': all(default_uses.values()),"""
replacement="""                row['unqualified_positive_facts'] = {
                    condition: [key for key, fact in capture['facts'].items()
                                if fact['claim_kind'] is not None and fact['claim_proof'] is None
                                and fact['status'] in {'code_proven', 'code_and_config', 'class_default', 'config_declared'}]
                    for condition, capture in captured.items()}
                row['proof_completeness_scope'] = 'Parity is not qualification: every listed declaration-only positive remains an open proof obligation.'
"""+needle
assert needle in s;s=s.replace(needle,replacement)
p=Path('/private/tmp/unfold-s9a-sparse-witness-preparation-v4/run_sparse.py');ast.parse(s);p.write_text(s)
print(hashlib.sha256(p.read_bytes()).hexdigest())
