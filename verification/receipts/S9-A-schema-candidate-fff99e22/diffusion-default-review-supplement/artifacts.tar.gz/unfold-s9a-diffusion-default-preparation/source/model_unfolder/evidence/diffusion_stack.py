"""U10-B — occurrence-exact diffusion repeated-stack inventory.

This boundary replaces the *address/execution* responsibility of the legacy
whole-file ``secondary_stacks_from_files`` reader.  It consumes only the one
ProgramIndex, a resolved D0 component root, B2 container addresses, the exact
OwnerGraph, and positively addressed calls from the owner's forward.

One :class:`DiffusionStackOccurrence` is one exact container construction
address joined to one exact symbolic element occurrence.  A comprehension is
therefore one template occurrence, never ``N`` fabricated layers.  Reusing the
same block class in two containers remains two occurrences.  Calling the same
container twice remains one occurrence with two exact executions.

This module deliberately does *not* infer ``main``, ``secondary``, ``refiner``,
``text``, ``latent``, ``Transformer`` or any other architectural role.  Exact
call argument bindings are carried so a later dataflow reader can prove such a
role.  Container source order and call source locations are retained separately;
neither is called execution order.  Config paths are cited only through B2's
already-exact count observation, and no config value is read here.

The U3 execution substrate remains open-world, so a positive inventory is a
``ReaderResult.incomplete`` value.  It is useful positive evidence, never a
claim that no additional dynamically-executed stack exists.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from .call_arguments import (
    CallBindingResolution,
    bind_addressed_invocation,
    bind_repeated_child_call,
)
from .component_owner import ComponentRootResolution, OwnerOccurrenceId
from .container_inventory import (
    ContainerAddress,
    ContainerInventory,
    ContainerRival,
    resolve_container_inventory,
)
from .config_guard import ExactConfigGuardResolver
from .reader_claims import retained_claim_reader
from .execution_flow import (
    AddressedInvocation,
    RepeatedInvocationTemplate,
    UnresolvedInvocation,
    resolve_addressed_invocations,
)
from .program_index import (
    CallObservation,
    ContainerElementsRecord,
    ExprNode,
    LoopObservation,
    ProgramIndex,
    SourceSpan,
    SymbolId,
)
from .reader_result import ReaderFailure, ReaderProvenance, ReaderResult
from .repeated_child import RepeatedChildProof


def _span_key(span: SourceSpan | None) -> tuple:
    if span is None:
        return ("", -1, -1, -1, -1)
    return (span.source.canonical_path, span.line, span.col,
            span.end_line or span.line, span.end_col or span.col)


def _within(inner: SourceSpan | None, outer: SourceSpan | None) -> bool:
    if inner is None or outer is None or inner.source != outer.source:
        return False
    inner_end = (inner.end_line or inner.line, inner.end_col or inner.col)
    outer_end = (outer.end_line or outer.line, outer.end_col or outer.col)
    return ((inner.line, inner.col) >= (outer.line, outer.col)
            and inner_end <= outer_end)


def _self_field(expr: ExprNode | None) -> str | None:
    if expr is None:
        return None
    if expr.kind == "attribute" and expr.children:
        base = expr.children[0]
        if base.kind == "name" and base.name == "self":
            return expr.name
    if expr.kind == "subscript" and expr.children:
        return _self_field(expr.children[0])
    return None


def _target_names(expr: ExprNode | None) -> tuple[str, ...]:
    if expr is None:
        return ()
    if expr.kind == "name" and expr.name:
        return (expr.name,)
    if expr.kind in {"tuple", "list"}:
        return tuple(name for child in expr.children
                     for name in _target_names(child))
    return ()


def _iteration_field(loop: LoopObservation, call: CallObservation) -> str | None:
    """The exact container field binding ``call``'s loop-local callee.

    This is only an evidence-address helper.  It accepts direct/sliced
    ``self.x`` and ``enumerate(self.x)`` syntax already observed by ProgramIndex;
    it never assigns a role to ``x``.
    """
    if loop.kind != "for" or loop.iterable is None or loop.target is None \
            or call.callee.kind != "name" \
            or call.callee.name not in _target_names(loop.target) \
            or not _within(call.span, loop.body_span) \
            or tuple(call.guard[:len(loop.guard)]) != tuple(loop.guard):
        return None
    iterable = loop.iterable
    if iterable.kind == "call" and len(iterable.children) >= 2:
        callee = iterable.children[0]
        if callee.kind != "name" or callee.name != "enumerate":
            return None
        iterable = iterable.children[1]
    if iterable.kind == "subscript" and iterable.children:
        iterable = iterable.children[0]
    return _self_field(iterable)


@dataclass(frozen=True)
class StackExecution:
    """One exact call of one exact symbolic container element occurrence."""

    kind: str  # repeated_template | owner_graph_template | literal_index
    owner_occurrence: OwnerOccurrenceId
    block_occurrence: OwnerOccurrenceId
    block_symbol: SymbolId
    call: CallObservation
    binding: CallBindingResolution
    template: RepeatedInvocationTemplate | None = None
    addressed: AddressedInvocation | None = None
    unresolved_source: UnresolvedInvocation | None = None
    spans: tuple[SourceSpan, ...] = ()

    def __post_init__(self) -> None:
        if self.kind not in {
                "repeated_template", "owner_graph_template", "literal_index"}:
            raise ValueError("unknown stack execution kind")
        if not isinstance(self.owner_occurrence, OwnerOccurrenceId) \
                or not isinstance(self.block_occurrence, OwnerOccurrenceId) \
                or not isinstance(self.block_symbol, SymbolId):
            raise TypeError("stack execution addresses exact owner/block occurrences")
        if self.block_occurrence.root != self.owner_occurrence.root \
                or self.block_occurrence.sites[:-1] != self.owner_occurrence.sites:
            raise ValueError("a stack block is an immediate child of its owner")
        if not isinstance(self.call, CallObservation) or self.call.span is None:
            raise TypeError("a stack execution carries an exact call")
        if not isinstance(self.binding, CallBindingResolution) \
                or self.binding.call != self.call \
                or self.binding.callee_occurrence != self.block_occurrence:
            raise ValueError("call bindings belong to this exact execution")
        if self.binding.status not in {"resolved", "partial"} \
                or self.binding.callee_symbol != self.block_symbol:
            raise ValueError("a stack execution requires an addressed callable")
        if self.kind == "repeated_template":
            if not isinstance(self.template, RepeatedInvocationTemplate) \
                    or self.addressed is not None \
                    or self.unresolved_source is not None \
                    or self.template.call != self.call \
                    or self.template.caller_occurrence != self.owner_occurrence:
                raise ValueError("a repeated execution round-trips to its template")
            site = self.template.element_template
            if self.block_occurrence.sites[-1] != site.site_id \
                    or len(site.candidates) != 1 \
                    or site.candidates[0].symbol != self.block_symbol:
                raise ValueError("template candidate closes the exact block occurrence")
        elif self.kind == "owner_graph_template":
            if not isinstance(self.addressed, AddressedInvocation) \
                    or not isinstance(self.unresolved_source, UnresolvedInvocation) \
                    or self.template is not None \
                    or self.addressed.call != self.call \
                    or self.unresolved_source.call != self.call \
                    or self.addressed.caller_occurrence != self.owner_occurrence \
                    or self.unresolved_source.caller_occurrence != self.owner_occurrence \
                    or self.addressed.callee_owner_occurrence != self.block_occurrence:
                raise ValueError("a graph-joined template closes its original call")
        elif not isinstance(self.addressed, AddressedInvocation) \
                or self.unresolved_source is not None \
                or self.template is not None \
                or self.addressed.call != self.call \
                or self.addressed.caller_occurrence != self.owner_occurrence \
                or self.addressed.callee_owner_occurrence != self.block_occurrence:
            raise ValueError("an indexed execution round-trips to its addressed call")
        required = {self.call.span}
        if self.kind == "repeated_template":
            required.add(self.template.element_template.span)
        else:
            required.update(self.addressed.provenance_spans)
        if None in required or not required <= set(self.spans) \
                or any(not isinstance(span, SourceSpan) for span in self.spans):
            raise ValueError("execution provenance closes every decisive site")


@dataclass(frozen=True)
class ConfigSelectedStackVariant:
    """One guarded container rival selected by exact config/code evidence."""

    rival: ContainerRival
    selected_record: ContainerElementsRecord
    selected_branch: int
    premises: tuple[tuple[tuple[str, ...], str, object], ...]
    spans: tuple[SourceSpan, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.rival, ContainerRival) \
                or not isinstance(
                    self.selected_record, ContainerElementsRecord) \
                or self.selected_record not in self.rival.records:
            raise ValueError("a selected stack variant retains its exact rival")
        if self.selected_branch < 0 \
                or self.selected_branch >= len(self.rival.records) \
                or self.rival.records[self.selected_branch] \
                != self.selected_record:
            raise ValueError("the selected branch is the exact rival ordinal")
        if any(
                not isinstance(path, tuple) or not path
                or any(not isinstance(part, str) or not part for part in path)
                or kind not in {"config_declared", "class_default"}
                for path, kind, _value in self.premises):
            raise ValueError("a config-selected variant retains typed premises")
        premise_keys = tuple((path, kind) for path, kind, _value
                             in self.premises)
        if len(premise_keys) != len(set(premise_keys)):
            raise ValueError("variant premises are path-and-source unique")
        if not self.spans or any(not isinstance(span, SourceSpan)
                                 for span in self.spans) \
                or not set(record.span for record in self.rival.records
                           if record.span is not None) <= set(self.spans):
            raise ValueError("a selected variant retains exact decisive spans")


@dataclass(frozen=True)
class DiffusionStackOccurrence:
    """One exact container address joined to one exact block occurrence."""

    component_root: OwnerOccurrenceId
    owner_occurrence: OwnerOccurrenceId
    owner_symbol: SymbolId
    container: ContainerAddress
    block_occurrence: OwnerOccurrenceId
    block_symbol: SymbolId
    executions: tuple[StackExecution, ...]
    owner_route: tuple = ()  # exact AddressedInvocation | StackExecution hops
    selection: ConfigSelectedStackVariant | None = None

    def __post_init__(self) -> None:
        if not all(isinstance(item, OwnerOccurrenceId) for item in (
                self.component_root, self.owner_occurrence,
                self.block_occurrence)):
            raise TypeError("stack occurrences are exact-occurrence qualified")
        if not isinstance(self.owner_symbol, SymbolId) \
                or not isinstance(self.block_symbol, SymbolId) \
                or not isinstance(self.container, ContainerAddress):
            raise TypeError("stack occurrence retains exact symbols and container")
        if self.container.owner_occurrence != self.owner_occurrence:
            raise ValueError("the stack container belongs to the exact owner")
        if self.container.record.owner != self.owner_symbol:
            raise ValueError("the stack owner symbol owns the container record")
        if self.selection is not None and (
                not isinstance(self.selection, ConfigSelectedStackVariant)
                or self.selection.rival.owner_occurrence
                != self.owner_occurrence
                or self.selection.selected_record != self.container.record):
            raise ValueError("stack selection closes this exact container rival")
        if self.component_root.sites:
            raise ValueError("the component root has an empty occurrence chain")
        if self.owner_occurrence.root != self.component_root.root \
                or self.block_occurrence.root != self.component_root.root \
                or self.block_occurrence.sites[:-1] != self.owner_occurrence.sites:
            raise ValueError("stack owner and block descend from the component root")
        if self.block_occurrence.sites[-1] not in tuple(
                site.site_id for site in self.container.element_sites):
            raise ValueError("the exact block is constructed in the cited container")
        if not self.executions or any(
                not isinstance(item, StackExecution)
                or item.owner_occurrence != self.owner_occurrence
                or item.block_occurrence != self.block_occurrence
                or item.block_symbol != self.block_symbol
                for item in self.executions):
            raise ValueError("a stack occurrence carries its exact executions")
        calls = tuple(item.call.span for item in self.executions)
        if calls != tuple(sorted(calls, key=_span_key)) \
                or len(calls) != len(set(calls)):
            raise ValueError("stack execution sites are unique and source ordered")
        current = self.component_root
        for hop in self.owner_route:
            if isinstance(hop, AddressedInvocation):
                caller = hop.caller_occurrence
                callee = hop.callee_owner_occurrence
            elif isinstance(hop, StackExecution):
                caller = hop.owner_occurrence
                callee = hop.block_occurrence
            else:
                raise TypeError("owner routes carry exact invocation hops")
            if caller != current:
                raise ValueError("owner route is one exact invocation chain")
            current = callee
        if current != self.owner_occurrence:
            raise ValueError("owner route terminates at the exact container owner")

    @property
    def count_expression(self) -> ExprNode | None:
        return self.container.count_expression

    @property
    def count_config_path(self):
        return self.container.count_config_path


@dataclass(frozen=True)
class UnresolvedStackCandidate:
    """A container-related execution address U10-B refuses to guess."""

    owner_occurrence: OwnerOccurrenceId
    field: str
    reason: str
    evidence: tuple
    spans: tuple[SourceSpan, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.owner_occurrence, OwnerOccurrenceId):
            raise TypeError("unresolved stack candidates are owner-qualified")
        if not self.field or not self.reason or not self.evidence:
            raise ValueError("an unresolved candidate names field, reason and evidence")
        if any(not isinstance(item, (ContainerAddress, ContainerRival,
                                     UnresolvedInvocation))
               for item in self.evidence):
            raise TypeError("unresolved evidence stays on authoritative DTOs")
        for item in self.evidence:
            evidence_owner = (item.owner_occurrence
                              if isinstance(item, (ContainerAddress, ContainerRival))
                              else item.caller_occurrence)
            if evidence_owner != self.owner_occurrence:
                raise ValueError("unresolved evidence belongs to the exact owner")
        if any(not isinstance(span, SourceSpan) for span in self.spans):
            raise TypeError("unresolved provenance spans are typed")


@dataclass(frozen=True)
class DiffusionStackInventory:
    """Every positively addressed repeated-stack occurrence found from root."""

    component_root: OwnerOccurrenceId
    stacks: tuple[DiffusionStackOccurrence, ...] = ()
    unresolved: tuple[UnresolvedStackCandidate, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.component_root, OwnerOccurrenceId):
            raise TypeError("a diffusion stack inventory is component-root qualified")
        if any(not isinstance(item, DiffusionStackOccurrence)
               or item.component_root != self.component_root for item in self.stacks):
            raise ValueError("every stack belongs to this exact component root")
        identities = tuple((item.owner_occurrence, item.container.record,
                            item.block_occurrence) for item in self.stacks)
        if len(identities) != len(set(identities)):
            raise ValueError("stack construction occurrences are unique")
        if any(not isinstance(item, UnresolvedStackCandidate)
               or item.owner_occurrence.root != self.component_root.root
               for item in self.unresolved):
            raise ValueError("every unresolved candidate belongs to this component")


def _matching_child(root, owner, field, site, symbol):
    node = root.graph.node_for(owner)
    matches = tuple(child for child in (node.children if node else ())
                    if child.via_field == field
                    and child.via_site == site
                    and child.symbol == symbol
                    and root.graph.node_for(child.occurrence) is child)
    return matches[0] if len(matches) == 1 else None


def _stack_from_template(index, root, owner, owner_symbol, route, template):
    site = template.element_template
    if len(site.candidates) != 1 or site.candidates[0].symbol is None:
        return None
    symbol = site.candidates[0].symbol
    child = _matching_child(
        root, owner, template.container.field, site.site_id, symbol)
    if child is None:
        return None
    proof = RepeatedChildProof(
        owner, template, child.occurrence, child.symbol)
    binding = bind_repeated_child_call(index, root, proof)
    if binding.status not in {"resolved", "partial"}:
        return None
    spans = tuple(dict.fromkeys(
        span for span in (template.call.span, site.span,
                          template.container.record.span)
        if isinstance(span, SourceSpan)))
    execution = StackExecution(
        "repeated_template", owner, child.occurrence, child.symbol,
        template.call, binding, template=template, spans=spans)
    return DiffusionStackOccurrence(
        root.graph.root.occurrence, owner, owner_symbol, template.container,
        child.occurrence, child.symbol, (execution,), route)


def _stack_from_indexed(index, root, owner, owner_symbol, route, inventory,
                        invocation):
    field = _self_field(invocation.call.callee)
    if field is None:
        return None
    container = next((item for item in inventory.containers
                      if item.field == field), None)
    if container is None or not invocation.callee_owner_occurrence.sites:
        return None
    site = invocation.callee_owner_occurrence.sites[-1]
    if site not in tuple(element.site_id for element in container.element_sites):
        return None
    node = root.graph.node_for(invocation.callee_owner_occurrence)
    if node is None:
        return None
    binding = bind_addressed_invocation(index, root, invocation)
    if binding.status not in {"resolved", "partial"}:
        return None
    spans = tuple(dict.fromkeys(
        span for span in (*invocation.provenance_spans,
                          invocation.call.span, container.record.span)
        if isinstance(span, SourceSpan)))
    execution = StackExecution(
        "literal_index", owner, invocation.callee_owner_occurrence,
        node.symbol, invocation.call, binding,
        addressed=invocation, spans=spans)
    return DiffusionStackOccurrence(
        root.graph.root.occurrence, owner, owner_symbol, container,
        invocation.callee_owner_occurrence, node.symbol, (execution,), route)


def _stack_from_graph_joined_unresolved(
        index, root, owner, owner_symbol, route, inventory, unresolved):
    """Reconcile one alias-unresolved template with D0 at the exact site.

    The execution resolver already proved the loop-local call, but cannot emit
    a template when ProgramIndex deliberately leaves an import alias's candidate
    symbol empty.  This join is legal only for one B2 container, one element
    site, and one authoritative D0 child at that same field/site.  The original
    unresolved observation remains carried as provenance.
    """
    if unresolved.reason != "heterogeneous_or_unresolved_container_elements":
        return None
    field = _related_field(
        index, unresolved.call.enclosing_callable, inventory, unresolved)
    candidates = tuple(item for item in inventory.containers
                       if item.field == field)
    if field is None or len(candidates) != 1:
        return None
    container = candidates[0]
    if len(container.element_sites) != 1:
        return None
    element = container.element_sites[0]
    node = root.graph.node_for(owner)
    children = tuple(child for child in (node.children if node else ())
                     if child.via_field == field
                     and child.via_site == element.site_id
                     and root.graph.node_for(child.occurrence) is child)
    if len(children) != 1:
        return None
    child = children[0]
    spans = tuple(dict.fromkeys(
        span for span in (unresolved.call.span, element.span,
                          container.record.span)
        if isinstance(span, SourceSpan)))
    addressed = AddressedInvocation(
        unresolved.call_site, owner, child.occurrence, unresolved.call,
        unresolved.guard, spans)
    binding = bind_addressed_invocation(index, root, addressed)
    if binding.status not in {"resolved", "partial"}:
        return None
    execution = StackExecution(
        "owner_graph_template", owner, child.occurrence, child.symbol,
        unresolved.call, binding, addressed=addressed,
        unresolved_source=unresolved, spans=spans)
    return DiffusionStackOccurrence(
        root.graph.root.occurrence, owner, owner_symbol, container,
        child.occurrence, child.symbol, (execution,), route)


def _related_field(index, callable_symbol, inventory, unresolved):
    fields = {item.field for item in inventory.containers} \
        | {item.field for item in inventory.rivals}
    direct = _self_field(unresolved.call.callee)
    if direct in fields:
        return direct
    for loop in index.loops_in(callable_symbol):
        field = _iteration_field(loop, unresolved.call)
        if field in fields:
            return field
    return None


def _unresolved_candidate(owner, field, reason, evidence):
    spans = []
    for item in evidence:
        if isinstance(item, ContainerAddress):
            spans.extend((item.record.span,))
        elif isinstance(item, ContainerRival):
            spans.extend(record.span for record in item.records)
        elif isinstance(item, UnresolvedInvocation):
            spans.extend((item.call.span,))
    return UnresolvedStackCandidate(
        owner, field, reason, tuple(evidence),
        tuple(dict.fromkeys(span for span in spans
                            if isinstance(span, SourceSpan))))


def _has_symbolic_repetition(candidate) -> bool:
    if isinstance(candidate, ContainerAddress):
        return candidate.count_expression is not None
    return any(record.count is not None for record in candidate.records)


def _merge_stacks(rows):
    grouped = {}
    for row in rows:
        key = (row.owner_occurrence, row.container.record,
               row.block_occurrence)
        grouped.setdefault(key, []).append(row)
    out = []
    for values in grouped.values():
        first = values[0]
        executions = tuple(sorted(
            (execution for value in values for execution in value.executions),
            key=lambda item: _span_key(item.call.span)))
        out.append(DiffusionStackOccurrence(
            first.component_root, first.owner_occurrence, first.owner_symbol,
            first.container, first.block_occurrence, first.block_symbol,
            executions, first.owner_route, first.selection))
    return tuple(sorted(out, key=lambda item: (
        tuple(_span_key(hop.call.span) for hop in item.owner_route),
        item.container.source_order,
        _span_key(item.executions[0].call.span),
        item.block_symbol.source.canonical_path,
        item.block_symbol.qualified_name)))


def _select_guarded_rivals(index, node, inventory, config_guard_selector):
    """Select only an exhaustively decided exact container rival partition."""
    if config_guard_selector is None or not inventory.rivals:
        return inventory, {}
    selected = []
    unresolved = []
    selections = {}
    for rival in inventory.rivals:
        decisions = []
        resolvers = []
        for record in rival.records:
            if not record.elements:
                decisions.append(None)
                resolvers.append(None)
                continue
            guards = tuple(dict.fromkeys(site.guard for site in record.elements))
            if len(guards) != 1:
                decisions.append(None)
                resolvers.append(None)
                continue
            resolver = ExactConfigGuardResolver(
                index, node, config_guard_selector)
            decisions.append(resolver.enabled(
                guards[0], record.enclosing_callable))
            resolvers.append(resolver)
        true_rows = tuple(i for i, value in enumerate(decisions)
                          if value is True)
        if len(true_rows) != 1 or any(value is None for value in decisions) \
                or any(value is not False for i, value in enumerate(decisions)
                       if i != true_rows[0]):
            unresolved.append(rival)
            continue
        branch = true_rows[0]
        record = rival.records[branch]
        resolver = resolvers[branch]
        premises = []
        conflicting = False
        for source_value in resolver.source_values:
            key = source_value[:2]
            previous = next((item for item in premises
                             if item[:2] == key), None)
            if previous is None:
                premises.append(source_value)
            elif previous[2] != source_value[2]:
                conflicting = True
                break
        premises = tuple(premises)
        if conflicting:
            unresolved.append(rival)
            continue
        if len(premises) != len(tuple(dict.fromkeys(resolver.source_kinds))):
            unresolved.append(rival)
            continue
        spans = tuple(dict.fromkeys((
            *(item.span for item in rival.records if item.span is not None),
            *(site.span for item in rival.records for site in item.elements
              if site.span is not None),
            *resolver.spans,
        )))
        if not spans:
            unresolved.append(rival)
            continue
        address = ContainerAddress(
            rival.owner_occurrence, record, rival.source_order)
        selection = ConfigSelectedStackVariant(
            rival, record, branch, premises, spans)
        selected.append(address)
        selections[record] = selection
    containers = tuple(sorted((*inventory.containers, *selected),
                              key=lambda item: item.source_order))
    rivals = tuple(unresolved)
    if not containers and not rivals:
        return ContainerInventory(
            "absent", inventory.owner_occurrence, inventory.owner_symbol), {}
    return ContainerInventory(
        "resolved", inventory.owner_occurrence, inventory.owner_symbol,
        containers, rivals), selections


@dataclass(frozen=True)
class DiffusionOperandRead:
    path: tuple[str, ...]
    selected: object
    guarded: bool


def capture_diffusion_selector(selector, reads, *, guarded):
    if selector is None:
        return None
    def select(path):
        from .document import _snapshot
        selected = selector(path)
        # Keep ordinary nested values as they were at this read. Typed default
        # DTOs remain the original constructor evidence under their own checks.
        reads.append(DiffusionOperandRead(tuple(path), _snapshot(selected), guarded))
        return selected
    return select


def validate_diffusion_dependency(result, index, document, witness_type, *, detail):
    """Authenticate one actual upstream call, then reconcile its entire input chain."""
    from .reader_claims import reader_claim_scope_matches, retained_reader_attempt
    if type(result.claim_witness) is not witness_type \
            or not reader_claim_scope_matches(result, index, document):
        raise ValueError(detail)
    # Scope identity alone does not validate a custom selector. Authenticate
    # the original callable too, then visit its retained deciding inputs.
    symbol, actual_index, actual_document, _owner = retained_reader_attempt(result)
    if symbol != witness_type.reader_symbol or actual_index is not index \
            or actual_document is not document:
        raise ValueError(detail)
    result.claim_witness.validate_inputs(document)


def registered_diffusion_default(index, root, document, path):
    """An omitted exact root formal, supplied by its registered literal default.

    The constructor registration is re-derived from the exact current index.
    A prepared overlay alone is never sufficient, and either present document
    channel (including explicit null) prevents this default route.
    """
    from .config_registration import RegisteredConstructorDefaultValue, read_registered_constructor_config
    from .receipts import value_status_hash
    path = tuple(path)
    if len(path) != 1 or document.failure is not None \
            or path[0] in document.checkpoint or path[0] in document.document:
        return None
    registration = read_registered_constructor_config(index, root)
    if registration.status != "resolved":
        return None
    matches = tuple(parameter for parameter in registration.value.parameters
                    if parameter.name == path[0] and parameter.has_default
                    and parameter.default is not None and parameter.default.kind == "constant")
    if len(matches) != 1:
        return None
    parameter = matches[0]
    if any(item.name == parameter.name and item.context in {"store", "del"}
           for item in index.identifiers_in(registration.value.constructor.symbol)):
        return None  # A rewritten formal is no longer the literal default operand.
    value = parameter.default.const_value
    if path[0] in document.class_overlay and value_status_hash(
            document.class_overlay[path[0]], "operand") != value_status_hash(value, "operand"):
        return None
    return RegisteredConstructorDefaultValue(value, path, parameter, registration.value)


@dataclass(frozen=True)
class DiffusionResolvedOperand:
    source_path: tuple[str, ...]
    value: object
    source_kind: str
    checkpoint_path: tuple[str, ...] | None
    default_evidence: object = None


def declared_diffusion_operand(document, path, *, index=None, root=None):
    """Exact checkpoint first, otherwise an independently proved constructor default."""
    from .reader_claims import reader_operand
    value = document.checkpoint
    for segment in path:
        if not isinstance(value, dict) or segment not in value:
            if index is None or root is None:
                return None
            default = registered_diffusion_default(index, root, document, path)
            return DiffusionResolvedOperand(tuple(path), default.value, "class_default", None, default) \
                if default is not None else None
        value = value[segment]
    operand = reader_operand(document, path, allow_aliases=False)
    return DiffusionResolvedOperand(operand.source_path, operand.value, operand.source_kind,
                                    operand.checkpoint_path) if operand.source_kind == "config_declared" else None


def validate_diffusion_reads(index, root, reads, document):
    """Check actual deciding operands, including every unselected rival."""
    from .config_registration import RegisteredConstructorDefaultValue
    from .reader_claims import reader_operand
    from .receipts import value_status_hash
    for read in reads:
        selected = read.selected
        if isinstance(selected, RegisteredConstructorDefaultValue):
            selected.__post_init__()
            registration = selected.registration
            registration.__post_init__()
            actual = registered_diffusion_default(index, root, document, read.path)
            if actual is None or selected.path != read.path \
                    or registration.owner != root.occurrence \
                    or registration.constructor != actual.registration.constructor \
                    or registration.protocol != actual.registration.protocol \
                    or selected.parameter != actual.parameter \
                    or value_status_hash(selected.value, "operand") != value_status_hash(actual.value, "operand"):
                raise ValueError("registered default requires its actual constructor and omitted operand")
            continue
        present, value, kind = selected is not None, selected, "config_declared"
        if read.guarded and isinstance(selected, tuple) and len(selected) in {2, 3}:
            present, value = selected[:2]
            kind = selected[2] if len(selected) == 3 else "config_declared"
        if not present:
            continue
        operand = declared_diffusion_operand(document, read.path, index=index, root=root)
        if operand is None:
            raise ValueError("diffusion reader operand has no exact checkpoint/constructor value")
        if not read.guarded:
            kind = operand.source_kind
        if operand.source_kind != kind or value_status_hash(value, "operand") \
                != value_status_hash(operand.value, "operand"):
            raise ValueError("diffusion reader operand differs from its supplying document")


@dataclass(frozen=True)
class DiffusionStackClaimWitness:
    index: ProgramIndex
    root: ComponentRootResolution
    inventory: DiffusionStackInventory
    registration_result: ReaderResult
    selector_reads: tuple[DiffusionOperandRead, ...]
    reader_symbol = "model_unfolder.evidence.diffusion_stack.read_diffusion_stack_inventory"

    def validate_result(self, result):
        self.inventory.__post_init__()
        if result.value is not self.inventory or result.owner != self.root.occurrence:
            raise ValueError("stack claim retains its actual root inventory result")
        for stack in self.inventory.stacks:
            stack.__post_init__()
            if self.index.class_by_symbol(stack.block_symbol) is None \
                    or self.index.class_by_symbol(stack.owner_symbol) is None:
                raise ValueError("stack claim closes its indexed owner and block")

    def validate_inputs(self, document):
        validate_diffusion_reads(self.index, self.root, self.selector_reads, document)

    def project(self, owner, key, document):
        from .reader_claims import ReaderFactProjection, reader_operand
        self.validate_inputs(document)
        matches = tuple(stack for number, stack in enumerate(self.inventory.stacks)
                        if owner == f"root.denoiser.stacks[{number}]")
        if len(matches) != 1:
            raise ValueError("stack claim needs its exact source-ordered owner")
        stack = matches[0]
        if key == "diffusion_stack_variant" and stack.selection is not None:
            selection = stack.selection
            selection.__post_init__()
            paths = tuple(path for path, kind, _value in selection.premises
                          if kind == "config_declared")
            default = bool(selection.premises) and not paths
            status = "code_and_config" if paths else "class_default" if default else "code_proven"
            # The existing fact exposes default premise addresses. They remain
            # distinct from checkpoint consumption, as in the original F3 row.
            if default:
                paths = tuple(path for path, _kind, _value in selection.premises)
            return ReaderFactProjection(owner, key, "connection", {
                "selected_branch": selection.selected_branch,
                "candidate_count": len(selection.rival.records)}, status, paths,
                required_spans=selection.spans)
        if key != "diffusion_stack_depth":
            raise ValueError("stack inventory cannot author another fact")
        expression = stack.count_expression
        if expression is None or expression.kind != "call" \
                or len(expression.children) != 2 or expression.keyword_children \
                or expression.children[0].kind != "name" \
                or expression.children[0].name != "range":
            raise ValueError("stack count needs the proven one-operand repetition")
        callable_symbol = stack.container.record.enclosing_callable
        if any(item.name == "range" for item in self.index.module_bindings_in(callable_symbol.source)) \
                or any(item.name == "range" and item.context in {"parameter", "store", "del"}
                       for item in self.index.identifiers_in(callable_symbol)):
            raise ValueError("stack repetition builtin is shadowed")
        argument = expression.children[1]
        if argument.kind not in {"name", "attribute", "subscript"}:
            from .reader_claims import ReaderClaimUnavailable
            raise ReaderClaimUnavailable("stack repetition arithmetic needs an established evaluator")
        if stack.count_config_path is not None:
            path = tuple(segment.name for segment in stack.count_config_path.segments)
            span = stack.count_config_path.span
        else:
            from .attention import exact_config_path_for_expression
            node = self.root.graph.node_for(stack.owner_occurrence)
            path = exact_config_path_for_expression(self.index, node, argument)
            registration = self.registration_result
            if path is None and registration.status == "resolved" \
                    and registration.value.owner == stack.owner_occurrence:
                from .config_registration import registered_constructor_path_for_expression
                path = registered_constructor_path_for_expression(
                    self.index, registration.value, argument)
            span = argument.span
        if not path:
            raise ValueError("stack repetition operand has no exact source address")
        operand = declared_diffusion_operand(document, path, index=self.index, root=self.root)
        if operand is None:
            raise ValueError("F3 repetition count requires exact checkpoint/constructor evidence")
        value = operand.value if type(operand.value) is int and operand.value > 0 else None
        default_spans = operand.default_evidence.spans if operand.default_evidence is not None else ()
        return ReaderFactProjection(owner, key, "value", value,
            "class_default" if default_spans else "code_and_config",
            (operand.checkpoint_path,) if operand.checkpoint_path is not None else (),
            required_spans=tuple(dict.fromkeys((span, *default_spans))))


@retained_claim_reader
def read_diffusion_stack_inventory(
        index: ProgramIndex,
        root_resolution: ComponentRootResolution,
        *, config_guard_selector=None,
        ) -> ReaderResult[DiffusionStackInventory]:
    """Inventory positively-executed repeated containers reachable from root."""
    if not isinstance(index, ProgramIndex):
        raise TypeError("read_diffusion_stack_inventory requires a ProgramIndex")
    if not isinstance(root_resolution, ComponentRootResolution):
        raise TypeError("read_diffusion_stack_inventory requires a D0 resolution")
    if not root_resolution.address_resolved:
        kind = ("parse_failure" if root_resolution.status == "failed"
                else "conflict" if root_resolution.status == "ambiguous"
                else "missing_source")
        return ReaderResult.failed(None, (ReaderFailure(
            kind, f"component root is {root_resolution.status}"),))
    root_occurrence = root_resolution.graph.root.occurrence
    if index.class_by_symbol(root_resolution.graph.root.symbol) is None:
        return ReaderResult.failed(root_occurrence, (ReaderFailure(
            "incomplete_graph", "D0 root is absent from this ProgramIndex"),))

    from .config_registration import read_registered_constructor_config
    registration_result = read_registered_constructor_config(index, root_resolution)
    selector_reads = []
    config_guard_selector = capture_diffusion_selector(
        config_guard_selector, selector_reads, guarded=True)
    rows = []
    unresolved_rows = []
    visited = set()

    def visit(owner: OwnerOccurrenceId, route: tuple[AddressedInvocation, ...]):
        if owner in visited:
            return
        visited.add(owner)
        node = root_resolution.graph.node_for(owner)
        if node is None or index.class_by_symbol(node.symbol) is None:
            return
        inventory = resolve_container_inventory(index, root_resolution, owner)
        if inventory.status == "failed":
            return
        inventory, selections = _select_guarded_rivals(
            index, node, inventory, config_guard_selector)
        invocations = resolve_addressed_invocations(
            index, root_resolution, owner, inventory)
        if invocations.status == "failed":
            return

        seen_fields = set()
        for template in invocations.templates:
            seen_fields.add(template.container.field)
            row = _stack_from_template(
                index, root_resolution, owner, node.symbol, route, template)
            if row is not None:
                if row.container.record in selections:
                    row = replace(row, selection=selections[row.container.record])
                rows.append(row)
                visit(row.block_occurrence, route + (row.executions[0],))
            else:
                unresolved_rows.append(_unresolved_candidate(
                    owner, template.container.field,
                    "template_graph_or_binding_unresolved", (template.container,)))

        for invocation in invocations.addressed:
            indexed = _stack_from_indexed(
                index, root_resolution, owner, node.symbol, route,
                inventory, invocation)
            if indexed is not None:
                if indexed.container.record in selections:
                    indexed = replace(
                        indexed, selection=selections[indexed.container.record])
                seen_fields.add(indexed.container.field)
                rows.append(indexed)
                visit(indexed.block_occurrence,
                      route + (indexed.executions[0],))
            else:
                visit(invocation.callee_owner_occurrence,
                      route + (invocation,))

        callable_symbol = invocations.callable_symbol
        relevant_unresolved = set()
        if callable_symbol is not None:
            for item in invocations.unresolved:
                field = _related_field(
                    index, callable_symbol, inventory, item)
                graph_joined = _stack_from_graph_joined_unresolved(
                    index, root_resolution, owner, node.symbol, route,
                    inventory, item)
                if graph_joined is not None:
                    if graph_joined.container.record in selections:
                        graph_joined = replace(
                            graph_joined,
                            selection=selections[graph_joined.container.record])
                    seen_fields.add(graph_joined.container.field)
                    rows.append(graph_joined)
                    visit(graph_joined.block_occurrence,
                          route + (graph_joined.executions[0],))
                    continue
                if field is None:
                    # A called graph field that could hide a nested stack is a
                    # traversal blocker even when it is not itself a container.
                    field = _self_field(item.call.callee)
                    graph_fields = {child.via_field for child in node.children} \
                        | {child.field for child in node.unresolved}
                    if field not in graph_fields:
                        continue
                relevant_unresolved.add(field)
                evidence = tuple(
                    row for row in (*inventory.containers, *inventory.rivals)
                    if row.field == field) + (item,)
                unresolved_rows.append(_unresolved_candidate(
                    owner, field, item.reason, evidence))

        for candidate in (*inventory.containers, *inventory.rivals):
            if candidate.field not in seen_fields \
                    and candidate.field not in relevant_unresolved \
                    and _has_symbolic_repetition(candidate):
                unresolved_rows.append(_unresolved_candidate(
                    owner, candidate.field, "container_execution_unobserved",
                    (candidate,)))

    visit(root_occurrence, ())
    inventory = DiffusionStackInventory(
        root_occurrence, _merge_stacks(rows),
        tuple(sorted(unresolved_rows, key=lambda item: (
            tuple(site.ordinal for site in item.owner_occurrence.sites),
            item.field, item.reason, tuple(_span_key(span)
                                           for span in item.spans)))))
    spans = tuple(dict.fromkeys((
        *(span for stack in inventory.stacks
          for execution in stack.executions for span in execution.spans),
        *(span for candidate in inventory.unresolved
          for span in candidate.spans),
    )))
    if not spans:
        # Open-world source makes an empty positive inventory unknown, never an
        # architectural assertion that the model has no repeated stack.
        return ReaderResult.failed(root_occurrence, (ReaderFailure(
            "incomplete_graph",
            "no positively addressed repeated-container execution"),))
    failures = [ReaderFailure(
        "incomplete_graph",
        "U3 supplies positive local execution relations, not whole-forward coverage")]
    if inventory.unresolved:
        failures.append(ReaderFailure(
            "incomplete_graph",
            f"{len(inventory.unresolved)} container/traversal candidates remain unresolved"))
    return replace(ReaderResult.incomplete(
        root_occurrence, inventory, failures=tuple(failures),
        provenance=(ReaderProvenance(
            "source", spans=spans,
            detail="exact D0/B2 container, graph occurrence and invocation joins"),)),
        claim_witness=DiffusionStackClaimWitness(
            index, root_resolution, inventory, registration_result, tuple(selector_reads)))


__all__ = [
    "StackExecution", "ConfigSelectedStackVariant",
    "DiffusionStackOccurrence",
    "UnresolvedStackCandidate", "DiffusionStackInventory",
    "read_diffusion_stack_inventory",
]
