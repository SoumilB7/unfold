"""Bounded exact activation-registry selection, never key normalization.

Only an imported registry's literal entry, its instantiated lookup protocol,
 and the selected callable's returned activation can establish application.
"""
from __future__ import annotations

from dataclasses import dataclass

from .activation_semantics import FUNCTIONAL_ACTIVATIONS, MODULE_ACTIVATIONS
from .construction_calls import resolve_import_reference
from .program_index import SourceSpan, SymbolId
from .reader_claims import ReaderClaimUnavailable


@dataclass(frozen=True)
class ActivationRegistryApplication:
    key: str
    mechanism: str
    dispatch: object
    registry_assignment: object
    entry: object
    lookup_callable: SymbolId
    selected_callable: SymbolId | None
    spans: tuple[SourceSpan, ...]


def _name(expression, name=None):
    return expression.kind == "name" and (name is None or expression.name == name)


def _expressions(expression):
    yield expression
    for child in expression.children:
        yield from _expressions(child)
    for _key, child in expression.keyword_children:
        yield from _expressions(child)


def _unavailable(detail):
    raise ReaderClaimUnavailable("activation registry: " + detail)


def _instantiated_lookup(index, source, factory, entry):
    """Prove the complete three-statement mapping-entry -> instance protocol."""
    if not _name(factory):
        _unavailable("registry factory is not one exact local class")
    symbol = SymbolId(source, factory.name)
    cls = index.class_by_symbol(symbol)
    if cls is None or cls.decorators or len(cls.bases) != 1:
        _unavailable("registry factory has no exact mapping base")
    base = resolve_import_reference(index, source, None, cls.bases[0])
    if base is None or base.qualified_target != "collections.OrderedDict":
        _unavailable("registry factory base is not the supported mapping protocol")
    methods = index.callables_of(symbol)
    lookup = tuple(item for item in methods if item.symbol.qualified_name == factory.name + ".__getitem__")
    if len(methods) != 1 or len(lookup) != 1 or lookup[0].decorators:
        _unavailable("registry factory has another or wrapped callable")
    method = lookup[0]
    if len(method.params) != 2:
        _unavailable("lookup does not receive one exact key")
    for builtin in ("super", "isinstance", "tuple"):
        if any(item.name == builtin for item in index.module_bindings_in(source)) or any(
                item.name == builtin and item.context in {"parameter", "store", "del"}
                for item in index.identifiers_in(method.symbol)):
            _unavailable("lookup builtin is shadowed")
    bindings = index.bindings_in(method.symbol)
    returns = index.return_observations_in(method.symbol)
    if len(bindings) != 2 or len(returns) != 1 or any(item.guard for item in (*bindings, *returns)):
        _unavailable("lookup is not a complete unconditional entry-to-instance path")
    first, second = bindings
    if len(first.targets) != 1 or not _name(first.targets[0]):
        _unavailable("lookup entry assignment is unsupported")
    content = first.targets[0].name
    read = first.value
    if read is None or read.kind != "call" or len(read.children) != 2 or read.keyword_children:
        _unavailable("lookup does not read the exact key")
    callee, key = read.children
    if callee.kind != "attribute" or callee.name != "__getitem__" or len(callee.children) != 1 \
            or not _name(key, method.params[1].name):
        _unavailable("lookup key does not reach the inherited mapping read")
    inherited = callee.children[0]
    if inherited.kind != "call" or len(inherited.children) != 1 \
            or not _name(inherited.children[0], "super") or inherited.keyword_children:
        _unavailable("mapping read is not the exact superclass lookup")
    if len(second.targets) != 1 or second.targets[0].kind not in {"tuple", "list"} \
            or len(second.targets[0].children) != 2 or any(not _name(item) for item in second.targets[0].children):
        _unavailable("lookup does not retain exact class and keyword operands")
    class_name, kwargs_name = (item.name for item in second.targets[0].children)
    choice = second.value
    if choice is None or choice.kind != "ifexp" or len(choice.children) != 3:
        _unavailable("lookup entry selection is unsupported")
    positive, condition, negative = choice.children
    if not _name(positive, content) or condition.kind != "call" or len(condition.children) != 3 \
            or condition.keyword_children or not _name(condition.children[0], "isinstance") \
            or not _name(condition.children[1], content) or not _name(condition.children[2], "tuple") \
            or negative.kind != "tuple" or len(negative.children) != 2 \
            or not _name(negative.children[0], content) or negative.children[1].kind != "dict" \
            or negative.children[1].children or negative.children[1].keyword_children:
        _unavailable("lookup does not preserve an entry or add empty constructor keywords")
    returned = returns[0].value
    if returned is None or returned.kind != "call" or len(returned.children) != 1 \
            or not _name(returned.children[0], class_name) \
            or len(returned.keyword_children) != 1 \
            or returned.keyword_children[0][0] != "**" \
            or not _name(returned.keyword_children[0][1], kwargs_name):
        _unavailable("lookup does not return the selected class instance")
    allowed_calls = {item.span for expression in (first.value, second.value, returned)
                     for item in _expressions(expression) if item.kind == "call"}
    if {item.span for item in index.calls_in(method.symbol)} != allowed_calls:
        _unavailable("lookup carries another unaccounted call")
    if entry.kind == "tuple":
        if len(entry.children) != 2 or entry.children[1].kind != "dict":
            _unavailable("selected constructor keywords are unsupported")
        selected, keywords = entry.children
        if any(value.kind != "constant" for _key, value in keywords.keyword_children):
            _unavailable("selected constructor keywords are not literal")
    else:
        selected = entry
    return selected, method.symbol, (base.binding.span, cls.span, first.span, second.span, returns[0].span)


def _returned_activation(index, source, selected):
    primitive = resolve_import_reference(index, source, None, selected)
    if primitive is not None and primitive.qualified_target in MODULE_ACTIVATIONS:
        return MODULE_ACTIVATIONS[primitive.qualified_target], None, (primitive.binding.span, selected.span)
    if not _name(selected):
        _unavailable("selected activation class is not exactly resolved")
    symbol = SymbolId(source, selected.name)
    cls = index.class_by_symbol(symbol)
    forward = index.callable_by_symbol(SymbolId(source, selected.name + ".forward"))
    if cls is None or cls.decorators or forward is None or forward.decorators or len(forward.params) != 2:
        _unavailable("selected class has no supported activation forward")
    returns = index.return_observations_in(forward.symbol)
    if len(returns) != 1 or returns[0].guard or index.bindings_in(forward.symbol):
        _unavailable("selected forward is not one exact returned activation")
    expression = returns[0].value
    if expression is None or expression.kind != "call" or len(expression.children) != 2 \
            or not _name(expression.children[1], forward.params[1].name):
        _unavailable("selected forward does not directly activate its input")
    operation = resolve_import_reference(index, source, forward.symbol, expression.children[0])
    if operation is None or operation.qualified_target not in FUNCTIONAL_ACTIVATIONS:
        _unavailable("selected forward's activation meaning is unresolved")
    if any(value.kind != "constant" for _key, value in expression.keyword_children) \
            or {call.span for call in index.calls_in(forward.symbol)} != {expression.span}:
        _unavailable("selected forward contains unaccounted computation")
    return FUNCTIONAL_ACTIVATIONS[operation.qualified_target], forward.symbol, (cls.span, returns[0].span, operation.binding.span)


def activation_registry_application(index, mechanism, raw_key):
    if not isinstance(raw_key, str) or not raw_key:
        _unavailable("dispatch key is not an exact string")
    candidates = tuple(item for item in index.config_paths
                       if item.owner == mechanism.owner_symbol and item.form in {"act2fn", "get_activation"}
                       and item.span in mechanism.spans)
    if len(candidates) != 1:
        _unavailable("one live source dispatch is not retained")
    access = candidates[0]
    expressions = tuple(expression for assignment in index.field_assigns_of(mechanism.owner_symbol)
                        for expression in _expressions(assignment.value) if expression.span == access.span)
    if len(expressions) != 1 or expressions[0].kind != "subscript":
        _unavailable("only an exact registry subscript is currently proven")
    expression = expressions[0]
    imported = resolve_import_reference(index, mechanism.owner_symbol.source,
                                        access.enclosing_callable, expression.children[0])
    if imported is None:
        _unavailable("registry import is unresolved")
    parts = imported.qualified_target.split(".")
    assignments = tuple(item for item in index.module_assignments
                        if item.symbol.qualified_name == parts[-1]
                        and item.symbol.source.component_key == mechanism.owner_symbol.source.component_key
                        and item.symbol.source.canonical_path.rsplit("/", 1)[-1] == parts[-2] + ".py")
    if len(assignments) != 1 or assignments[0].guard:
        _unavailable("exact imported registry assignment is not in the SourceBundle closure")
    assignment = assignments[0]
    construction = assignment.value
    if construction.kind != "call" or len(construction.children) != 2 \
            or construction.keyword_children or not _name(construction.children[1]):
        _unavailable("registry is not instantiated from one literal dictionary")
    source = assignment.symbol.source
    registries = tuple(item for item in index.dispatch_registries
                       if item.symbol == SymbolId(source, construction.children[1].name))
    if len(registries) != 1:
        _unavailable("registry backing dictionary is not unique")
    entries = tuple(value for key, value in registries[0].entries
                    if key.kind == "constant" and type(key.const_value) is str and key.const_value == raw_key)
    if len(entries) != 1:
        _unavailable("exact raw key is absent or ambiguous in the registry")
    selected, lookup, lookup_spans = _instantiated_lookup(index, source, construction.children[0], entries[0])
    kind, target, body_spans = _returned_activation(index, source, selected)
    spans = tuple(dict.fromkeys((access.span, imported.binding.span, assignment.span,
                                 registries[0].span, entries[0].span, *lookup_spans, *body_spans)))
    if any(not isinstance(span, SourceSpan) for span in spans):
        _unavailable("registry application lacks exact source spans")
    return ActivationRegistryApplication(raw_key, kind, access, assignment, entries[0], lookup, target, spans)
