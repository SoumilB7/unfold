"""Read-only real-model diagnostic; execute only in the root's isolated lane."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
from model_unfolder import config_to_ir
from model_unfolder.evidence.context import ParseContext

corpus = Path('tests/sable_test_corpus')
rows = []
for slug in ('bloom', 'llama-7b'):
    for variant in ('ordinary', 'omitted_mlp_bias', 'contrary_mlp_bias_false'):
        config = json.loads((corpus / (slug + '.json')).read_text())['config']
        if variant == 'omitted_mlp_bias':
            config.pop('mlp_bias', None)
        elif variant == 'contrary_mlp_bias_false':
            config['mlp_bias'] = False
        context = ParseContext.build(config)
        ir = config_to_ir(config, parse_context=context)
        fact = context.facts.typed_records().get('decoder.ffn.bias')
        values = [getattr(layer.ffn, 'bias', None) for layer in ir.layers if getattr(layer, 'ffn', None) is not None]
        assert values, (slug, variant, 'no actual FFN rows captured')
        rows.append({'model': slug, 'variant': variant,
                     'fact': None if fact is None else {'value': fact.value, 'status': fact.status,
                       'claim_kind': fact.claim_kind, 'qualified': fact.claim_evidence is not None},
                     'ir_ffn_biases': values,
                     'mismatch': fact is not None and any(value != fact.value for value in values)})
Path('/private/tmp/unfold-s9a-eighteenth-ffn-bias/result.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows, indent=2))
