"""Escaping and formatting helpers for renderer modules."""
from __future__ import annotations

from html import escape
from typing import Any


def _fmt_int(value: Any) -> str:
    if value is None:
        return "?"
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value)


def _num(value: Any) -> Any:
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def _html(value: Any) -> str:
    return escape(str(value), quote=False)


def _attr(value: Any) -> str:
    return escape(str(value), quote=True)


def facts_html(facts) -> str:
    """The one chips row every inspect card uses for its numeric/spec facts."""
    if not facts:
        return ""
    chips = "".join(f'<span class="uf-fact">{_html(f)}</span>' for f in facts if f)
    return f'<div class="uf-card-facts">{chips}</div>' if chips else ""


def _presentation_chip_html(chip) -> str:
    """One typed annotation; labels never determine kind or evidence status."""
    from ...presentation import PresentationChip
    if not isinstance(chip, PresentationChip):
        raise TypeError("chip renderer requires typed display metadata")
    label = chip.chip_kind.replace("_", " ") if chip.chip_kind == "pending_design" else chip.chip_kind
    extra = ""
    if chip.unknown_reason is not None:
        reason = chip.unknown_reason.to_dict()
        label += " · " + reason["reason_class"]
        extra = f' data-reason-class="{_attr(reason["reason_class"])}"'
    if chip.decision_ref is not None:
        label += " · " + chip.decision_ref
        extra += f' data-decision-ref="{_attr(chip.decision_ref)}"'
    return (f'<span class="uf-fact uf-chip-{chip.chip_kind}" '
            f'data-chip-kind="{chip.chip_kind}" data-chip-owner="{_attr(chip.owner)}"{extra}>'
            f'{_html(label)} · {_html(chip.text)}</span>')


def presentation_chip_html(chip) -> str:
    return _presentation_chip_html(chip)


def is_exact_chip_emission(fragment: str, chip) -> bool:
    """Bind receipts to returned bytes, including kind, owner and full text."""
    return fragment == _presentation_chip_html(chip)


def _unknown_annotation_html(annotation) -> str:
    from ...presentation import UnknownValueAnnotation
    if not isinstance(annotation, UnknownValueAnnotation):
        raise TypeError('unknown renderer requires exact typed producer annotation')
    reason = annotation.reason.to_dict()
    path = ''.join(('[' + str(part) + ']') if type(part) is int else
                   ('.' if index else '') + part
                   for index, part in enumerate(annotation.path))
    readable_class = reason['reason_class'].replace('_', ' ')
    readable_reason = reason['concrete_reason'].replace('_', ' ')
    return ('<span class="uf-fact uf-chip-unresolved uf-value-reason" '
            'data-annotation-kind="unresolved-value" '
            f'data-value-state="{_attr(annotation.value_state)}" '
            f'data-reason-class="{_attr(reason["reason_class"])}">'
            f'<code>{_html(path)}</code> · unresolved · {_html(readable_class)}: '
            f'{_html(readable_reason)}</span>')


def unknown_annotation_html(annotation) -> str:
    return _unknown_annotation_html(annotation)


def append_unknown_value_report(fragment: str, ir: dict) -> str:
    """Add a collapsed exact-value strip to the shared family card shell."""
    from ...presentation import unknown_annotations_from_ir
    from .render_context import current_render_context
    annotations = unknown_annotations_from_ir(ir)
    if not annotations:
        return fragment
    marker = '<div class="uf-card">'
    if fragment.count(marker) != 1:
        raise ValueError('unknown report requires the exact single family card shell')
    emissions = [(annotation, unknown_annotation_html(annotation)) for annotation in annotations]
    shown = [(annotation, markup) for annotation, markup in emissions if markup]
    report = ('<details class="uf-unknown-values"><summary>Unresolved values · '
              + str(len(annotations)) + ' · reasons and exact locations</summary>'
              '<div class="uf-unknown-value-list">'
              + ''.join(markup for _, markup in shown) + '</div></details>')
    output = fragment.replace(marker, marker + report, 1)
    context = current_render_context()
    if context is not None:
        for annotation, markup in shown:
            if markup == _unknown_annotation_html(annotation):
                context.record_unknown_value(annotation)
    return output
